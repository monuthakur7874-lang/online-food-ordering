<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickBite | Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root { --primary-red: #ff4757; --dark-bg: #2f3542; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f1f2f6; }
        
        .hero-banner {
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=2070');
            background-size: cover; background-position: center;
            height: 400px; display: flex; align-items: center; justify-content: center; color: white;
            border-bottom: 5px solid var(--primary-red);
        }

        /* --- Landing Hero Animation --- */
        .premium-title {
            font-size: 5rem;
            text-transform: uppercase;
            letter-spacing: 5px;
            background: linear-gradient(to right, #fff 20%, var(--primary-red) 40%, var(--primary-red) 60%, #fff 80%);
            background-size: 200% auto;
            color: #000;
            background-clip: text;
            text-fill-color: transparent;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: shine 3s linear infinite, spaceIn 1.5s ease-out forwards;
            font-weight: 900;
        }

        @keyframes shine {
            to { background-position: 200% center; }
        }

        @keyframes spaceIn {
            from { letter-spacing: 20px; opacity: 0; filter: blur(10px); }
            to { letter-spacing: 5px; opacity: 1; filter: blur(0); }
        }

        .sub-text {
            animation: fadeInUp 1s ease-out 0.5s both;
            border-top: 1px solid rgba(255,255,255,0.2);
            padding-top: 10px;
            display: inline-block;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        /* ----------------------------------------- */

        .portal-card {
            border: none; border-radius: 20px; transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            text-align: center; padding: 40px 20px; background: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05); height: 100%;
        }

        .portal-card:hover { transform: translateY(-15px); box-shadow: 0 20px 40px rgba(255, 71, 87, 0.15); }

        .icon-circle {
            width: 80px; height: 80px; background: #fff5f6; color: var(--primary-red);
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 32px; margin: 0 auto 20px; transition: 0.3s;
        }

        .portal-card:hover .icon-circle { background: var(--primary-red); color: white; transform: rotateY(360deg); }

        .btn-access {
            background: var(--primary-red); color: white; border: none;
            border-radius: 10px; padding: 10px 25px; font-weight: 600; width: 100%;
            transition: 0.3s;
        }
        .btn-access:hover { background: #2f3542; color: white; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
    </style>
</head>
<body>

<div class="hero-banner text-center">
    <div>
        <h1 class="premium-title">QuickBite</h1>
        <p class="lead fw-light sub-text">Online Food Ordering System</p>
    </div>
</div>

<div class="container" style="margin-top: -60px; margin-bottom: 50px;">
    <div class="row g-4 justify-content-center">
        
        <div class="col-md-4 col-sm-6">
            <div class="card portal-card">
                <div class="icon-circle"><i class="fas fa-shopping-bag"></i></div>
                <h4 class="fw-bold">Customer Portal</h4>
                <p class="text-muted small px-3">Order delicious meals, track your food in real-time, and manage your profile.</p>
                <a href="user/" class="btn btn-access mt-3">Open Customer Panel</a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6">
            <div class="card portal-card">
                <div class="icon-circle"><i class="fas fa-motorcycle"></i></div>
                <h4 class="fw-bold">Delivery Partner</h4>
                <p class="text-muted small px-3">Accept new delivery requests, navigate to locations, and track your daily earnings.</p>
                <a href="delivery/" class="btn btn-access mt-3">Open Delivery Panel</a>
            </div>
        </div>

        <div class="col-md-4 col-sm-6">
            <div class="card portal-card">
                <div class="icon-circle"><i class="fas fa-user-shield"></i></div>
                <h4 class="fw-bold">Admin Control</h4>
                <p class="text-muted small px-3">Manage menus, restaurants, verify riders, and view detailed sales reports.</p>
                <a href="admin/" class="btn btn-access mt-3">Open Admin Panel</a>
            </div>
        </div>

    </div>
</div>

<footer class="text-center text-muted pb-4">
    <small>&copy; 2026 QuickBite | All Rights Reserved</small>
</footer>

</body>
</html>
