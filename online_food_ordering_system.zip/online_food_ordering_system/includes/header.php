<?php
/**
 * QuickBite - Public Header (root pages like about.php/help.php)
 * File: includes/header.php
 */
require_once(__DIR__ . '/../config/db.php');

$is_logged_in = isset($_SESSION['user_id']);
$user_name = $_SESSION['user_name'] ?? ($_SESSION['name'] ?? '');
$current_public_page = basename($_SERVER['PHP_SELF'] ?? 'index.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickBite</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --qb-red: #ff4757; --qb-dark: #2f3542; }
        body {
            background: linear-gradient(180deg, #fff7f5 0%, #ffffff 220px);
        }
        .navbar {
            background: transparent;
            box-shadow: none;
            padding: 18px 0 8px;
        }
        .qb-public-shell {
            background: rgba(255,255,255,0.96);
            border: 1px solid rgba(255, 71, 87, 0.12);
            border-radius: 30px;
            padding: 16px 20px;
            box-shadow: 0 20px 40px rgba(47,53,66,0.06);
        }
        .navbar-brand {
            font-weight: 800;
            color: var(--qb-dark) !important;
            display: inline-flex;
            align-items: center;
            gap: 14px;
            margin-right: 0;
        }
        .qb-brand-icon {
            width: 54px;
            height: 54px;
            border-radius: 18px;
            background: linear-gradient(135deg, #ff4757, #ff5d6c);
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            box-shadow: 0 12px 24px rgba(255,71,87,0.28);
        }
        .qb-brand-copy {
            line-height: 1.05;
        }
        .qb-brand-title {
            display: block;
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -0.03em;
        }
        .qb-brand-subtitle {
            display: block;
            margin-top: 4px;
            font-size: 13px;
            font-weight: 700;
            color: #a46363;
            text-transform: uppercase;
            letter-spacing: 0.08em;
        }
        .navbar-nav {
            background: #f8f8f8;
            border: 1px solid rgba(47,53,66,0.10);
            border-radius: 999px;
            padding: 6px;
            gap: 4px;
        }
        .nav-link {
            font-weight: 700;
            color: #556070 !important;
            border-radius: 999px;
            padding: 12px 36px !important;
            transition: 0.2s ease;
        }
        .nav-link:hover,
        .nav-link.active {
            color: #111827 !important;
            background: rgba(255, 71, 87, 0.10);
        }
        .qb-public-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .qb-auth-btn {
            min-width: 142px;
            border-radius: 999px;
            padding: 12px 24px;
            font-weight: 700;
        }
        .qb-auth-btn.btn-outline-danger {
            border-color: rgba(255,71,87,0.8);
            color: var(--qb-red);
        }
        .qb-auth-btn.btn-danger {
            background: linear-gradient(135deg, #ff4757, #e23243);
            border-color: transparent;
        }
        .qb-user-pill {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            border-radius: 999px;
            background: #fff5f5;
            color: var(--qb-dark);
            font-weight: 700;
            border: 1px solid rgba(255,71,87,0.12);
        }
        .qb-user-pill i {
            color: var(--qb-red);
        }
        @media (max-width: 991.98px) {
            .qb-public-shell {
                padding: 14px 16px;
            }
            .navbar-nav {
                margin: 18px 0;
                border-radius: 24px;
            }
            .qb-public-actions {
                flex-wrap: wrap;
                width: 100%;
            }
            .qb-auth-btn,
            .qb-user-pill {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <div class="qb-public-shell w-100">
            <a class="navbar-brand" href="<?php echo SITEURL; ?>user/">
                <span class="qb-brand-icon"><i class="fas fa-basket-shopping"></i></span>
                <span class="qb-brand-copy">
                    <span class="qb-brand-title">Food Monu</span>
                    <span class="qb-brand-subtitle">Premium Food Delivery</span>
                </span>
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse align-items-center" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_public_page === 'index.php') ? 'active' : ''; ?>" href="<?php echo SITEURL; ?>user/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_public_page === 'about.php') ? 'active' : ''; ?>" href="<?php echo SITEURL; ?>about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo ($current_public_page === 'help.php') ? 'active' : ''; ?>" href="<?php echo SITEURL; ?>help.php">Help</a>
                    </li>
                </ul>

                <div class="qb-public-actions">
                    <?php if ($is_logged_in): ?>
                        <a class="qb-user-pill text-decoration-none" href="<?php echo SITEURL; ?>user/profile.php">
                            <i class="fas fa-circle-user"></i>
                            <?php echo htmlspecialchars($user_name ?: 'User'); ?>
                        </a>
                        <a class="btn btn-danger qb-auth-btn" href="<?php echo SITEURL; ?>user/auth/logout.php">Logout</a>
                    <?php else: ?>
                        <a class="btn btn-outline-danger qb-auth-btn" href="<?php echo SITEURL; ?>user/auth/login.php">Login</a>
                        <a class="btn btn-danger qb-auth-btn" href="<?php echo SITEURL; ?>user/auth/register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="main-wrapper">
