<?php
/**
 * QuickBite - Public Footer (root pages like about.php/help.php)
 * File: includes/footer.php
 */
?>
</div>

<footer class="text-center text-muted py-4 border-top mt-5 bg-white">
    <small>&copy; <?php echo date('Y'); ?> QuickBite Food Service. All Rights Reserved.</small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

