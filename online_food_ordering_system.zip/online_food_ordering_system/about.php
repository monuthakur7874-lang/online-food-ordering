<?php
include('includes/header.php');

$support_phone = '7874042063';
$support_email = 'monu.help@gmail.com';
?>

<style>
    :root { --qb-red: #ff4757; --qb-dark: #2f3542; }
    .qb-hero {
        background: radial-gradient(1200px 600px at 20% 10%, rgba(255, 71, 87, 0.18), transparent 55%),
                    radial-gradient(900px 450px at 85% 25%, rgba(47, 53, 66, 0.12), transparent 55%),
                    linear-gradient(135deg, #ffffff 0%, #fff8f8 45%, #ffffff 100%);
        border-bottom: 1px solid rgba(0,0,0,0.06);
    }
    .qb-chip {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        border-radius: 999px;
        border: 1px solid rgba(0,0,0,0.08);
        background: rgba(255,255,255,0.75);
        backdrop-filter: blur(8px);
        font-weight: 700;
    }
    .qb-chip i { color: var(--qb-red); }
    .qb-card {
        border: 1px solid rgba(0,0,0,0.06);
        box-shadow: 0 10px 30px rgba(0,0,0,0.06);
        border-radius: 18px;
        background: #fff;
    }
    .qb-icon {
        width: 54px; height: 54px;
        display: inline-flex; align-items: center; justify-content: center;
        border-radius: 14px;
        background: rgba(255, 71, 87, 0.10);
        color: var(--qb-red);
    }
    .qb-soft { color: rgba(47, 53, 66, 0.78); }
    .qb-kpi {
        border-radius: 16px;
        border: 1px solid rgba(0,0,0,0.06);
        background: #fff;
    }
</style>

<section class="qb-hero py-5">
    <div class="container">
        <div class="row align-items-center g-4">
            <div class="col-lg-6">
                <div class="d-flex flex-wrap gap-2 mb-3">
                    <span class="qb-chip"><i class="fas fa-bolt"></i> Fast ordering</span>
                    <span class="qb-chip"><i class="fas fa-location-dot"></i> Live updates</span>
                    <span class="qb-chip"><i class="fas fa-shield-halved"></i> Secure flow</span>
                </div>
                <h1 class="display-5 fw-bold mb-3">About QuickBite</h1>
                <p class="lead qb-soft mb-4">
                    QuickBite is a modern food ordering experience designed to keep things simple: browse the menu, add items to cart,
                    checkout in seconds, and track your order with clear updates &mdash; with Cash on Delivery or Online Payment.
                </p>

                <div class="d-flex flex-wrap gap-2">
                    <a class="btn btn-danger rounded-pill px-4 fw-bold" href="<?php echo SITEURL; ?>user/index.php#menu">Explore Menu</a>
                    <a class="btn btn-outline-dark rounded-pill px-4 fw-bold" href="<?php echo SITEURL; ?>help.php">Contact Support</a>
                </div>

                <div class="row g-3 mt-4">
                    <div class="col-6">
                        <div class="qb-kpi p-3">
                            <div class="fw-bold">Transparent status</div>
                            <div class="small qb-soft">Confirmed &rarr; On the way &rarr; Delivered</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="qb-kpi p-3">
                            <div class="fw-bold">Multiple payments</div>
                            <div class="small qb-soft">COD + Online methods</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="qb-card p-3 p-md-4">
                    <div class="row g-3 align-items-center">
                        <div class="col-md-6">
                            <img
                                src="<?php echo SITEURL; ?>images/food/Food_Item_3028.jpg"
                                class="img-fluid rounded-4"
                                alt="QuickBite"
                                style="object-fit: cover; width: 100%; height: 290px;"
                            >
                        </div>
                        <div class="col-md-6">
                            <h5 class="fw-bold mb-2">Our Promise</h5>
                            <p class="qb-soft mb-3">
                                A consistent, professional experience &mdash; from menu browsing to payment to delivery.
                            </p>
                            <div class="d-flex flex-column gap-2 small">
                                <div class="d-flex align-items-center gap-2">
                                    <span class="qb-icon"><i class="fas fa-cart-shopping"></i></span>
                                    <span><b>Easy Checkout</b> &mdash; minimal steps</span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="qb-icon"><i class="fas fa-route"></i></span>
                                    <span><b>Order Tracking</b> &mdash; clear updates</span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="qb-icon"><i class="fas fa-lock"></i></span>
                                    <span><b>Account Safety</b> &mdash; secure sessions</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-5">
                <h2 class="fw-bold mb-3">What We Do</h2>
                <p class="qb-soft mb-3">
                    QuickBite connects customers with food options in one place and manages the order lifecycle end-to-end:
                    checkout, payment selection, order confirmation, delivery updates, and support.
                </p>
                <div class="qb-card p-4">
                    <div class="d-flex align-items-start gap-3">
                        <span class="qb-icon"><i class="fas fa-circle-check"></i></span>
                        <div>
                            <div class="fw-bold">Simple Ordering</div>
                            <div class="small qb-soft">Add items to cart and place the order quickly.</div>
                        </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex align-items-start gap-3">
                        <span class="qb-icon"><i class="fas fa-circle-check"></i></span>
                        <div>
                            <div class="fw-bold">Clear Status</div>
                            <div class="small qb-soft">Know what&apos;s happening with your order at each step.</div>
                        </div>
                    </div>
                    <hr class="my-3">
                    <div class="d-flex align-items-start gap-3">
                        <span class="qb-icon"><i class="fas fa-circle-check"></i></span>
                        <div>
                            <div class="fw-bold">Support Ready</div>
                            <div class="small qb-soft">Help page + ticket submission for faster resolution.</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="qb-card p-4 h-100">
                            <div class="qb-icon mb-3"><i class="fas fa-burger"></i></div>
                            <h5 class="fw-bold">Browse Menu</h5>
                            <p class="qb-soft mb-0">Explore categories and items with a clean user experience.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="qb-card p-4 h-100">
                            <div class="qb-icon mb-3"><i class="fas fa-basket-shopping"></i></div>
                            <h5 class="fw-bold">Cart Management</h5>
                            <p class="qb-soft mb-0">Update quantity, remove items, and review totals before ordering.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="qb-card p-4 h-100">
                            <div class="qb-icon mb-3"><i class="fas fa-credit-card"></i></div>
                            <h5 class="fw-bold">Payment Options</h5>
                            <p class="qb-soft mb-0">Choose COD or online payment methods (UPI / Wallet / Card).</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="qb-card p-4 h-100">
                            <div class="qb-icon mb-3"><i class="fas fa-map-location-dot"></i></div>
                            <h5 class="fw-bold">Tracking</h5>
                            <p class="qb-soft mb-0">Track order status and view delivery progress when available.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="bg-light py-5">
    <div class="container">
        <div class="text-center mb-4">
            <h2 class="fw-bold mb-2">Quality, Safety &amp; Security</h2>
            <p class="qb-soft mb-0">Professional experience with focus on reliability and safety.</p>
        </div>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="qb-card p-4 h-100">
                    <div class="qb-icon mb-3"><i class="fas fa-stopwatch"></i></div>
                    <h5 class="fw-bold">Fast &amp; Reliable</h5>
                    <p class="qb-soft mb-0">Optimized flow for ordering, confirmation, and delivery updates.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="qb-card p-4 h-100">
                    <div class="qb-icon mb-3"><i class="fas fa-receipt"></i></div>
                    <h5 class="fw-bold">Clear Payments</h5>
                    <p class="qb-soft mb-0">COD and online payments with transaction reference on success.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="qb-card p-4 h-100">
                    <div class="qb-icon mb-3"><i class="fas fa-user-shield"></i></div>
                    <h5 class="fw-bold">Account Protection</h5>
                    <p class="qb-soft mb-0">Safer sessions and form protection to reduce misuse.</p>
                </div>
            </div>
        </div>

        <div class="qb-card p-4 p-md-5 mt-4">
            <div class="row align-items-center g-3">
                <div class="col-lg-8">
                    <h4 class="fw-bold mb-2">Need assistance?</h4>
                    <p class="qb-soft mb-0">
                        Visit the Help page to raise a ticket, or contact us directly via phone/email.
                    </p>
                    <div class="small qb-soft mt-2">
                        <span class="me-3"><i class="fas fa-phone me-1 text-danger"></i> <?php echo htmlspecialchars($support_phone); ?></span>
                        <span><i class="fas fa-envelope me-1 text-danger"></i> <?php echo htmlspecialchars($support_email); ?></span>
                    </div>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <a class="btn btn-danger rounded-pill px-4 fw-bold" href="<?php echo SITEURL; ?>help.php">Go to Help</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
include('includes/footer.php');
?>

