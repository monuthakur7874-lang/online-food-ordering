<?php
require_once('includes/db-connect.php');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$csrf_token = function_exists('qb_csrf_token') ? qb_csrf_token() : ($_SESSION['csrf_token'] ?? '');
$profile_notice = '';
$profile_error = '';

if (isset($_GET['msg']) && $_GET['msg'] === 'updated') {
    $profile_notice = 'Profile updated successfully.';
}

if (isset($_POST['update_profile'])) {
    qb_require_csrf();

    $name = trim((string)($_POST['name'] ?? ''));
    $phone = trim((string)($_POST['phone'] ?? ''));
    $address = trim((string)($_POST['address'] ?? ''));
    $vehicle_no = trim((string)($_POST['vehicle_no'] ?? ''));

    if ($name === '' || $phone === '') {
        $profile_error = 'Name and phone number are required.';
    } else {
        $name_safe = mysqli_real_escape_string($conn, $name);
        $phone_safe = mysqli_real_escape_string($conn, $phone);
        $address_safe = mysqli_real_escape_string($conn, $address);
        $vehicle_safe = mysqli_real_escape_string($conn, $vehicle_no);

        $update_sql = "UPDATE users
                       SET name='{$name_safe}',
                           phone='{$phone_safe}',
                           address='{$address_safe}',
                           vehicle_no='{$vehicle_safe}'
                       WHERE id='{$rider_id}' AND role='delivery'";

        if (mysqli_query($conn, $update_sql)) {
            $_SESSION['user_name'] = $name;
            header('Location: my-profile.php?msg=updated');
            exit();
        }

        $profile_error = 'Profile update failed. Please try again.';
    }
}

$user_sql = "SELECT * FROM users WHERE id = {$rider_id} AND role = 'delivery' LIMIT 1";
$user_res = mysqli_query($conn, $user_sql);
$user = $user_res ? mysqli_fetch_assoc($user_res) : null;

$delivery_page_title = 'My Profile - Rider Panel';
include('includes/header.php');

if (!$user) {
    echo "<div class='container py-5'><div class='alert alert-danger border-0 rounded-4 shadow-sm'>Rider profile not found.</div></div>";
    include('includes/footer.php');
    exit();
}

$stats = [
    'delivered_count' => 0,
    'cancelled_count' => 0,
    'confirmed_count' => 0,
    'on_way_count' => 0,
];

$stats_sql = "
    SELECT
        SUM(CASE WHEN order_status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_count,
        SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_count,
        SUM(CASE WHEN order_status = 'Confirmed' THEN 1 ELSE 0 END) AS confirmed_count,
        SUM(CASE WHEN order_status = 'On the Way' THEN 1 ELSE 0 END) AS on_way_count
    FROM orders
    WHERE rider_id = {$rider_id}";
$stats_res = mysqli_query($conn, $stats_sql);
if ($stats_res && ($stats_row = mysqli_fetch_assoc($stats_res))) {
    $stats['delivered_count'] = (int)($stats_row['delivered_count'] ?? 0);
    $stats['cancelled_count'] = (int)($stats_row['cancelled_count'] ?? 0);
    $stats['confirmed_count'] = (int)($stats_row['confirmed_count'] ?? 0);
    $stats['on_way_count'] = (int)($stats_row['on_way_count'] ?? 0);
}

$wallet_balance = (float)($user['wallet_balance'] ?? 0);
$is_online = ((string)($user['is_online'] ?? 'No') === 'Yes');
$is_active = ((string)($user['status'] ?? 'Inactive') === 'Active');
$initials = strtoupper(substr((string)($user['name'] ?? 'R'), 0, 1));
$member_since = !empty($user['created_at']) ? date('d M Y', strtotime((string)$user['created_at'])) : 'Recently joined';
$last_seen = !empty($user['last_seen']) ? date('d M, h:i A', strtotime((string)$user['last_seen'])) : 'No sync yet';
$vehicle_no = trim((string)($user['vehicle_no'] ?? ''));
$delivery_capacity = $stats['confirmed_count'] + $stats['on_way_count'];
$closed_total = $stats['delivered_count'] + $stats['cancelled_count'];
$completion_rate = $closed_total > 0 ? (int)round(($stats['delivered_count'] / $closed_total) * 100) : 100;
$dispatch_mode = $is_online ? 'Live Dispatch On' : 'Standby Mode';
?>

<style>
  .profile-shell {
    max-width: 1320px;
    margin: 0 auto;
  }

  .profile-hero {
    position: relative;
    overflow: hidden;
    padding: 2rem;
    margin-bottom: 1.35rem;
    border-radius: 34px;
    background:
      radial-gradient(circle at top left, rgba(255,255,255,0.22), transparent 36%),
      radial-gradient(circle at 84% 14%, rgba(255,193,148,0.2), transparent 24%),
      linear-gradient(135deg, #341319 0%, #a31f39 38%, #e23744 70%, #ff8a98 100%);
    color: #fff;
    box-shadow: 0 28px 62px rgba(226,55,68,0.22);
  }

  .profile-hero::after {
    content: '';
    position: absolute;
    right: -70px;
    bottom: -92px;
    width: 250px;
    height: 250px;
    border-radius: 50%;
    background: rgba(255,255,255,0.12);
  }

  .profile-hero-grid {
    position: relative;
    z-index: 1;
    display: grid;
    grid-template-columns: minmax(0, 1.35fr) minmax(320px, 0.9fr);
    gap: 1.25rem;
    align-items: stretch;
  }

  .profile-kicker {
    display: inline-flex;
    align-items: center;
    gap: 0.55rem;
    padding: 0.55rem 0.9rem;
    border-radius: 999px;
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.18);
    font-size: 0.78rem;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .profile-hero h1 {
    margin: 1rem 0 0.45rem;
    font-size: clamp(2rem, 3vw, 3.15rem);
    line-height: 1.02;
    font-weight: 800;
  }

  .profile-hero p {
    max-width: 680px;
    margin: 0;
    color: rgba(255,255,255,0.84);
    font-size: 0.98rem;
  }

  .profile-hero-strip {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 0.85rem;
    margin-top: 1.35rem;
  }

  .profile-hero-chip {
    padding: 0.95rem 1rem;
    border-radius: 20px;
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.18);
    backdrop-filter: blur(12px);
  }

  .profile-hero-chip span {
    display: block;
    font-size: 0.72rem;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.72);
  }

  .profile-hero-chip strong {
    display: block;
    margin-top: 0.35rem;
    font-size: 1.28rem;
    line-height: 1.05;
    color: #fff;
  }

  .profile-hero-chip small {
    display: block;
    margin-top: 0.3rem;
    color: rgba(255,255,255,0.8);
  }

  .profile-hero-side {
    display: grid;
    gap: 0.9rem;
  }

  .profile-hero-card {
    padding: 1.1rem 1.15rem;
    border-radius: 24px;
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.18);
    backdrop-filter: blur(12px);
  }

  .profile-hero-card .k {
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: rgba(255,255,255,0.72);
  }

  .profile-hero-card .v {
    margin-top: 0.42rem;
    font-size: 1.85rem;
    line-height: 1;
    font-weight: 800;
    color: #fff;
  }

  .profile-hero-card .t {
    margin-top: 0.32rem;
    color: rgba(255,255,255,0.82);
    font-size: 0.88rem;
  }

  .profile-layout {
    display: grid;
    grid-template-columns: minmax(330px, 0.88fr) minmax(0, 1.12fr);
    gap: 1.2rem;
    align-items: start;
  }

  .profile-panel {
    background: rgba(255,255,255,0.98);
    border: 1px solid rgba(226,55,68,0.08);
    border-radius: 30px;
    box-shadow: 0 18px 40px rgba(15,23,42,0.06);
    overflow: hidden;
  }

  [data-theme='dark'] .profile-panel {
    background: linear-gradient(180deg, rgba(37,23,28,0.96), rgba(24,20,28,0.94));
    border-color: rgba(255,255,255,0.08);
  }

  .profile-panel-body {
    padding: 1.35rem;
  }

  .profile-id-card {
    position: relative;
    overflow: hidden;
    padding: 1.4rem;
    border-radius: 28px;
    background:
      radial-gradient(circle at top right, rgba(255,255,255,0.2), transparent 30%),
      linear-gradient(145deg, rgba(226,55,68,0.12), rgba(255,138,152,0.12));
    border: 1px solid rgba(226,55,68,0.12);
  }

  [data-theme='dark'] .profile-id-card {
    background:
      radial-gradient(circle at top right, rgba(255,255,255,0.06), transparent 30%),
      linear-gradient(145deg, rgba(226,55,68,0.12), rgba(255,138,152,0.08));
  }

  .profile-topline {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 1rem;
  }

  .profile-avatar {
    width: 96px;
    height: 96px;
    border-radius: 28px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    font-weight: 800;
    color: #fff;
    background: linear-gradient(135deg, #e23744, #ff7e8b);
    box-shadow: 0 18px 34px rgba(226,55,68,0.2);
  }

  .profile-badges {
    display: flex;
    flex-wrap: wrap;
    gap: 0.6rem;
    margin-top: 0.95rem;
  }

  .profile-badge-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.42rem;
    padding: 0.48rem 0.8rem;
    border-radius: 999px;
    font-size: 0.76rem;
    font-weight: 800;
  }

  .badge-online {
    background: rgba(16,185,129,0.12);
    color: #047857;
  }

  .badge-offline {
    background: rgba(239,68,68,0.12);
    color: #b91c1c;
  }

  .badge-active {
    background: rgba(37,99,235,0.12);
    color: #1d4ed8;
  }

  .badge-inactive {
    background: rgba(71,85,105,0.12);
    color: #475569;
  }

  .profile-meta-grid {
    display: grid;
    gap: 0.9rem;
    margin-top: 1.15rem;
  }

  .profile-meta-item {
    display: flex;
    gap: 0.85rem;
    align-items: flex-start;
    padding: 0.95rem 1rem;
    border-radius: 20px;
    background: rgba(226,55,68,0.05);
  }

  [data-theme='dark'] .profile-meta-item {
    background: rgba(255,255,255,0.05);
  }

  .profile-meta-item i,
  .shortcut-icon {
    width: 42px;
    height: 42px;
    border-radius: 16px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    background: linear-gradient(135deg, rgba(226,55,68,0.16), rgba(251,146,60,0.18));
    color: #e23744;
  }

  .profile-meta-item .k {
    font-size: 0.74rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--muted);
    font-weight: 800;
  }

  .profile-meta-item .v {
    margin-top: 0.18rem;
    font-weight: 700;
  }

  .profile-subsection {
    margin-top: 1.15rem;
  }

  .profile-subsection h6,
  .profile-form-head h5 {
    margin: 0;
    font-weight: 800;
  }

  .profile-subsection p,
  .profile-form-head p {
    margin: 0.2rem 0 0;
    color: var(--muted);
    font-size: 0.92rem;
  }

  .shortcut-grid,
  .overview-grid {
    display: grid;
    gap: 0.9rem;
    margin-top: 1rem;
  }

  .shortcut-card {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.9rem;
    padding: 1rem;
    text-decoration: none;
    color: var(--text-color);
    border-radius: 22px;
    background: rgba(255,255,255,0.72);
    border: 1px solid rgba(226,55,68,0.08);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
  }

  [data-theme='dark'] .shortcut-card {
    background: rgba(255,255,255,0.04);
    border-color: rgba(255,255,255,0.08);
  }

  .shortcut-copy {
    min-width: 0;
  }

  .shortcut-title {
    font-size: 0.98rem;
    font-weight: 800;
    color: var(--text-color);
    line-height: 1.2;
  }

  .shortcut-desc {
    margin-top: 0.2rem;
    font-size: 0.86rem;
    line-height: 1.45;
    color: var(--muted);
  }

  .shortcut-arrow {
    width: 44px;
    height: 44px;
    border-radius: 16px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex: 0 0 auto;
    background: rgba(226,55,68,0.14);
    color: #e23744;
  }

  [data-theme='dark'] .shortcut-title {
    color: rgba(255,255,255,0.96);
  }

  [data-theme='dark'] .shortcut-desc {
    color: rgba(229,231,235,0.74);
  }

  .shortcut-card.text-danger .shortcut-title {
    color: #ef4444;
  }

  .shortcut-card.text-danger .shortcut-desc {
    color: rgba(239,68,68,0.8);
  }

  .shortcut-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 14px 28px rgba(15,23,42,0.08);
    color: var(--text-color);
  }

  .overview-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .overview-card {
    padding: 1rem;
    border-radius: 22px;
    background: rgba(226,55,68,0.04);
    border: 1px solid rgba(226,55,68,0.08);
  }

  [data-theme='dark'] .overview-card {
    background: rgba(255,255,255,0.04);
    border-color: rgba(255,255,255,0.08);
  }

  .overview-card span {
    display: block;
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: var(--muted);
    font-weight: 800;
  }

  .overview-card strong {
    display: block;
    margin-top: 0.4rem;
    font-size: 1.7rem;
    line-height: 1;
    font-weight: 800;
  }

  .overview-card small {
    display: block;
    margin-top: 0.3rem;
    color: var(--muted);
  }

  .form-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
    margin-bottom: 1.2rem;
  }

  .editable-pill {
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    padding: 0.45rem 0.8rem;
    border-radius: 999px;
    background: rgba(226,55,68,0.08);
    color: #b91c1c;
    font-size: 0.74rem;
    font-weight: 800;
  }

  .profile-form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1rem;
  }

  .profile-form .form-label {
    font-size: 0.76rem;
    font-weight: 800;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: var(--muted);
  }

  .profile-form .form-control {
    border-radius: 18px;
    border: 1px solid rgba(226,55,68,0.12);
    padding: 0.88rem 1rem;
    box-shadow: none;
    background: rgba(255,255,255,0.92);
  }

  [data-theme='dark'] .profile-form .form-control {
    background: rgba(255,255,255,0.04);
    color: var(--text-color);
  }

  .profile-form .form-control:focus {
    border-color: rgba(226,55,68,0.35);
    box-shadow: 0 0 0 4px rgba(226,55,68,0.08);
  }

  .profile-readonly-note {
    margin-top: 0.42rem;
    font-size: 0.82rem;
    color: var(--muted);
  }

  .profile-cta {
    border: none;
    border-radius: 20px;
    padding: 0.95rem 1rem;
    font-weight: 800;
    background: linear-gradient(135deg, #e23744, #ff7e8b);
    box-shadow: 0 16px 30px rgba(226,55,68,0.18);
  }

  .profile-helper {
    margin-top: 1rem;
    padding: 1rem 1.05rem;
    border-radius: 20px;
    background: linear-gradient(135deg, rgba(226,55,68,0.06), rgba(255,138,152,0.08));
    border: 1px solid rgba(226,55,68,0.08);
    color: var(--muted);
    font-size: 0.92rem;
  }

  .profile-helper strong {
    color: var(--text-color);
  }

  .profile-alert {
    border-radius: 20px;
    border: none;
    padding: 0.95rem 1rem;
    margin-bottom: 1rem;
    box-shadow: 0 14px 26px rgba(15,23,42,0.05);
  }

  @media (max-width: 992px) {
    .profile-hero-grid,
    .profile-layout,
    .profile-form-grid,
    .profile-hero-strip,
    .overview-grid {
      grid-template-columns: 1fr;
    }
  }
</style>

<div class="profile-shell">
  <div class="profile-hero">
    <div class="profile-hero-grid">
      <div>
        <span class="profile-kicker"><i class="fas fa-id-badge"></i> Rider Profile Workspace</span>
        <h1><?= htmlspecialchars((string)$user['name'], ENT_QUOTES, 'UTF-8'); ?></h1>
        <p>Keep your rider identity sharp, dispatch contact details current, and your delivery presence ready for every fresh assignment.</p>

        <div class="profile-hero-strip">
          <div class="profile-hero-chip">
            <span>Dispatch Mode</span>
            <strong><?= htmlspecialchars($dispatch_mode, ENT_QUOTES, 'UTF-8'); ?></strong>
            <small><?= $is_online ? 'Your live location and duty state are ready for assignment sync.' : 'Switch online from the top bar when you want to receive live work.'; ?></small>
          </div>
          <div class="profile-hero-chip">
            <span>Wallet</span>
            <strong>Rs <?= number_format($wallet_balance, 2); ?></strong>
            <small>Running balance from completed delivery payouts.</small>
          </div>
          <div class="profile-hero-chip">
            <span>Completion Rate</span>
            <strong><?= $completion_rate; ?>%</strong>
            <small><?= $stats['delivered_count']; ?> delivered against <?= $closed_total; ?> closed assignments.</small>
          </div>
        </div>
      </div>

      <div class="profile-hero-side">
        <div class="profile-hero-card">
          <div class="k">Active Queue</div>
          <div class="v"><?= $delivery_capacity; ?></div>
          <div class="t"><?= $stats['confirmed_count']; ?> pickup pending and <?= $stats['on_way_count']; ?> currently on the route.</div>
        </div>
        <div class="profile-hero-card">
          <div class="k">Member Since</div>
          <div class="v" style="font-size:1.45rem;"><?= htmlspecialchars($member_since, ENT_QUOTES, 'UTF-8'); ?></div>
          <div class="t">Rider account tenure visible for dispatch and support verification.</div>
        </div>
      </div>
    </div>
  </div>

  <?php if ($profile_notice !== ''): ?>
    <div class="alert alert-success profile-alert">
      <i class="fas fa-circle-check me-2"></i><?= htmlspecialchars($profile_notice, ENT_QUOTES, 'UTF-8'); ?>
    </div>
  <?php endif; ?>

  <?php if ($profile_error !== ''): ?>
    <div class="alert alert-danger profile-alert">
      <i class="fas fa-triangle-exclamation me-2"></i><?= htmlspecialchars($profile_error, ENT_QUOTES, 'UTF-8'); ?>
    </div>
  <?php endif; ?>

  <div class="profile-layout">
    <div class="profile-panel">
      <div class="profile-panel-body">
        <div class="profile-id-card">
          <div class="profile-topline">
            <div class="profile-avatar"><?= htmlspecialchars($initials, ENT_QUOTES, 'UTF-8'); ?></div>
            <div class="text-end">
              <div class="small text-uppercase fw-bold" style="letter-spacing:.08em; color:var(--muted);">Partner ID</div>
              <div class="fw-bold fs-5">QB-R-<?= (int)$user['id']; ?></div>
            </div>
          </div>

          <div class="mt-3">
            <h4 class="fw-bold mb-1"><?= htmlspecialchars((string)$user['name'], ENT_QUOTES, 'UTF-8'); ?></h4>
            <div class="text-muted small"><?= htmlspecialchars((string)$user['email'], ENT_QUOTES, 'UTF-8'); ?></div>
          </div>

          <div class="profile-badges">
            <span class="profile-badge-pill <?= $is_online ? 'badge-online' : 'badge-offline'; ?>">
              <i class="fas <?= $is_online ? 'fa-broadcast-tower' : 'fa-power-off'; ?>"></i>
              <?= $is_online ? 'Available for Dispatch' : 'Currently Offline'; ?>
            </span>
            <span class="profile-badge-pill <?= $is_active ? 'badge-active' : 'badge-inactive'; ?>">
              <i class="fas fa-shield-halved"></i>
              <?= $is_active ? 'Account Active' : 'Account Inactive'; ?>
            </span>
          </div>
        </div>

        <div class="profile-meta-grid">
          <div class="profile-meta-item">
            <i class="fas fa-phone"></i>
            <div>
              <div class="k">Phone Number</div>
              <div class="v"><?= htmlspecialchars((string)($user['phone'] ?: 'Not updated'), ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
          </div>
          <div class="profile-meta-item">
            <i class="fas fa-motorcycle"></i>
            <div>
              <div class="k">Vehicle Number</div>
              <div class="v"><?= htmlspecialchars($vehicle_no !== '' ? $vehicle_no : 'Not added yet', ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
          </div>
          <div class="profile-meta-item">
            <i class="fas fa-location-dot"></i>
            <div>
              <div class="k">Address</div>
              <div class="v"><?= htmlspecialchars((string)(trim((string)($user['address'] ?? '')) !== '' ? $user['address'] : 'No address added yet'), ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
          </div>
          <div class="profile-meta-item">
            <i class="fas fa-clock-rotate-left"></i>
            <div>
              <div class="k">Last Seen Sync</div>
              <div class="v"><?= htmlspecialchars($last_seen, ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
          </div>
        </div>

        <div class="profile-subsection">
          <h6>Quick Links</h6>
          <p>Jump straight into the rider workflows you use most often.</p>
          <div class="shortcut-grid">
            <a href="dashboard.php" class="shortcut-card">
              <div class="d-flex align-items-center gap-3">
                <span class="shortcut-icon"><i class="fas fa-house"></i></span>
                <div class="shortcut-copy">
                  <div class="shortcut-title">Open Dashboard</div>
                  <div class="shortcut-desc">Check queue, status, and live dispatch cards.</div>
                </div>
              </div>
              <span class="shortcut-arrow"><i class="fas fa-chevron-right small"></i></span>
            </a>
            <a href="earnings.php" class="shortcut-card">
              <div class="d-flex align-items-center gap-3">
                <span class="shortcut-icon"><i class="fas fa-wallet"></i></span>
                <div class="shortcut-copy">
                  <div class="shortcut-title">View Earnings</div>
                  <div class="shortcut-desc">Track wallet balance, trip income and payout readiness.</div>
                </div>
              </div>
              <span class="shortcut-arrow"><i class="fas fa-chevron-right small"></i></span>
            </a>
            <a href="order-history.php" class="shortcut-card">
              <div class="d-flex align-items-center gap-3">
                <span class="shortcut-icon"><i class="fas fa-clock-rotate-left"></i></span>
                <div class="shortcut-copy">
                  <div class="shortcut-title">Ride History</div>
                  <div class="shortcut-desc">Review completed and cancelled orders from one place.</div>
                </div>
              </div>
              <span class="shortcut-arrow"><i class="fas fa-chevron-right small"></i></span>
            </a>
            <a href="auth/logout.php" class="shortcut-card text-danger">
              <div class="d-flex align-items-center gap-3">
                <span class="shortcut-icon"><i class="fas fa-right-from-bracket"></i></span>
                <div class="shortcut-copy">
                  <div class="shortcut-title">Logout Session</div>
                  <div class="shortcut-desc">Sign out from this device when your shift is done.</div>
                </div>
              </div>
              <span class="shortcut-arrow"><i class="fas fa-chevron-right small"></i></span>
            </a>
          </div>
        </div>
      </div>
    </div>

    <div class="profile-panel">
      <div class="profile-panel-body">
        <div class="form-toolbar">
          <div class="profile-form-head">
            <h5>Profile Details & Dispatch Readiness</h5>
            <p>Update the information support, dispatch, and customers rely on during active deliveries.</p>
          </div>
          <span class="editable-pill"><i class="fas fa-pen"></i> Editable</span>
        </div>

        <div class="overview-grid">
          <div class="overview-card">
            <span>Delivered Orders</span>
            <strong><?= $stats['delivered_count']; ?></strong>
            <small>Total successful handoffs recorded in your rider history.</small>
          </div>
          <div class="overview-card">
            <span>Cancelled Orders</span>
            <strong><?= $stats['cancelled_count']; ?></strong>
            <small>Assignments that did not close successfully.</small>
          </div>
          <div class="overview-card">
            <span>Pickup Pending</span>
            <strong><?= $stats['confirmed_count']; ?></strong>
            <small>Fresh assignments waiting to be started.</small>
          </div>
          <div class="overview-card">
            <span>On Route</span>
            <strong><?= $stats['on_way_count']; ?></strong>
            <small>Deliveries currently moving toward customers.</small>
          </div>
        </div>

        <form action="" method="POST" class="profile-form mt-4">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">

          <div class="profile-form-grid">
            <div class="mb-3">
              <label class="form-label">Full Name</label>
              <input type="text" name="name" class="form-control" value="<?= htmlspecialchars((string)$user['name'], ENT_QUOTES, 'UTF-8'); ?>" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Phone Number</label>
              <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars((string)($user['phone'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" required>
            </div>

            <div class="mb-3">
              <label class="form-label">Email Address</label>
              <input type="email" class="form-control" value="<?= htmlspecialchars((string)$user['email'], ENT_QUOTES, 'UTF-8'); ?>" readonly>
              <div class="profile-readonly-note">Registered email stays locked from the rider panel.</div>
            </div>

            <div class="mb-3">
              <label class="form-label">Vehicle Number</label>
              <input type="text" name="vehicle_no" class="form-control" value="<?= htmlspecialchars($vehicle_no, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Enter your bike or scooter number">
            </div>
          </div>

          <div class="mb-4">
            <label class="form-label">Address</label>
            <textarea name="address" class="form-control" rows="5" placeholder="Add your current home or standby address"><?= htmlspecialchars((string)($user['address'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></textarea>
          </div>

          <button type="submit" name="update_profile" class="btn btn-primary w-100 profile-cta">
            <i class="fas fa-floppy-disk me-2"></i> Save Rider Profile
          </button>
        </form>

        <div class="profile-helper">
          <strong class="d-block mb-1">Profile Tip</strong>
          Clear phone, vehicle, and address details help dispatch teams coordinate faster whenever a route changes or support needs to contact you during a live order.
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>
