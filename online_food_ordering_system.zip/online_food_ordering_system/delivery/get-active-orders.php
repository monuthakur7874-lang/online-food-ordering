<?php
/**
 * Delivery Panel - Active Orders for Map
 * File: delivery/get-active-orders.php
 */
include('includes/db-connect.php');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
if ($rider_id <= 0) {
    http_response_code(403);
    echo json_encode([]);
    exit();
}

// Note: orders table doesn't store coordinates; we return customer lat/lng if available (users.lat/lng)
$orders = [];
$stmt = mysqli_prepare(
    $conn,
    "SELECT o.id, o.order_status, o.total_amount, o.payment_status, o.delivery_address, u.name AS c_name, u.lat, u.lng
     FROM orders o
     JOIN users u ON o.user_id = u.id
     WHERE o.rider_id=? AND o.order_status IN ('Confirmed','On the Way')
     ORDER BY o.id DESC
     LIMIT 50"
);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $rider_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            $orders[] = $row;
        }
    }
    mysqli_stmt_close($stmt);
}

echo json_encode($orders);
exit();
