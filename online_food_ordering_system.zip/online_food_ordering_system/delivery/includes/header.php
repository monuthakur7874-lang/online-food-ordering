<?php 
// db-connect.php ko include karein (Isme db config aur auth-check pehle se hai)
require_once(__DIR__ . '/db-connect.php'); 

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$current_delivery_page = basename((string)($_SERVER['PHP_SELF'] ?? ''));
$rider_is_online = 'No';
if ($rider_id > 0) {
    $res = mysqli_query($conn, "SELECT is_online FROM users WHERE id={$rider_id} AND role='delivery' LIMIT 1");
    if ($res) {
        $row = mysqli_fetch_assoc($res);
        $rider_is_online = (string)($row['is_online'] ?? 'No');
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($delivery_page_title ?? 'Rider Panel - Food Delivery', ENT_QUOTES, 'UTF-8'); ?></title>
    <meta name="csrf-token" content="<?php echo htmlspecialchars(qb_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
    
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/delivery.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        window.csrfToken = <?php echo json_encode(qb_csrf_token()); ?>;
        window.deliveryInitialDutyStatus = <?php echo json_encode(($rider_is_online === 'Yes') ? 'Online' : 'Offline'); ?>;
    </script>
    <?php if (!empty($delivery_head_extra)) { echo $delivery_head_extra; } ?>
    
    <style>
        :root {
            --rider-theme: #e23744;
            --rider-theme-soft: #ff7e8b;
            --dark-bg: #231f20;
        }
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .navbar-custom {
            background: linear-gradient(135deg, #1f1b1c 0%, #311e22 50%, #51222b 100%);
            box-shadow: 0 10px 28px rgba(0,0,0,0.16);
            border-bottom: 1px solid rgba(255,255,255,0.06);
        }
        .navbar-brand {
            letter-spacing: 0.04em;
        }
        .nav-link {
            color: rgba(255,255,255,0.82) !important;
            font-weight: 600;
            border-radius: 999px;
            padding: 0.55rem 0.9rem !important;
            transition: background-color 0.2s ease, color 0.2s ease, transform 0.2s ease;
        }
        .nav-link:hover,
        .nav-link:focus {
            color: #fff !important;
            background: rgba(226,55,68,0.18);
            transform: translateY(-1px);
        }
        .active-nav { background: rgba(226,55,68,0.2); color: white !important; }
        .status-badge { font-size: 0.75rem; padding: 3px 10px; border-radius: 20px; }
        .form-check-input:checked {
            background-color: var(--rider-theme);
            border-color: var(--rider-theme);
        }
        .dropdown-menu {
            border-radius: 18px;
        }
        /* Mobile Bottom Nav (Optional but Cool) */
        @media (max-width: 768px) {
            .navbar-brand { font-size: 1.1rem; }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark navbar-custom sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="dashboard.php">
            <i class="fa-solid fa-motorcycle me-2" style="color:#ffb3be;"></i> FOOD MONU<span style="color:#ffb3be;"> RIDER</span>
        </a>
        
        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#riderNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="riderNavbar">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item px-2">
                    <a class="nav-link <?php echo ($current_delivery_page === 'dashboard.php') ? 'active-nav' : ''; ?>" href="dashboard.php"><i class="fa fa-home me-1"></i> Dashboard</a>
                </li>
                <li class="nav-item px-2">
                    <a class="nav-link <?php echo in_array($current_delivery_page, ['order-history.php', 'order-details.php'], true) ? 'active-nav' : ''; ?>" href="order-history.php"><i class="fa fa-list-check me-1"></i> My Orders</a>
                </li>
                <li class="nav-item px-2">
                    <a class="nav-link <?php echo in_array($current_delivery_page, ['earnings.php', 'daily-summary.php', 'payout-history.php'], true) ? 'active-nav' : ''; ?>" href="earnings.php"><i class="fa fa-wallet me-1"></i> Earnings</a>
                </li>
                
                <li class="nav-item px-3">
                    <div class="form-check form-switch mt-1">
                        <input class="form-check-input" type="checkbox" id="dutyToggle" <?php echo ($rider_is_online === 'Yes') ? 'checked' : ''; ?>>
                        <label class="form-check-label text-white small" for="dutyToggle"><?php echo ($rider_is_online === 'Yes') ? 'Online' : 'Offline'; ?></label>
                    </div>
                </li>

                <li class="nav-item dropdown px-2">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="profileDrop" role="button" data-bs-toggle="dropdown">
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name']); ?>&background=e23744&color=fff" class="rounded-circle me-2" width="30" height="30">
                        <?php echo explode(' ', $_SESSION['user_name'])[0]; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                        <li><a class="dropdown-item" href="my-profile.php"><i class="fa fa-user-edit me-2"></i> My Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="auth/logout.php"><i class="fa fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
