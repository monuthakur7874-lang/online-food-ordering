<?php
/**
 * Delivery Panel - Database Bridge & Security Check
 */

// 1. Main Database Config File ko include karein
// Hum __DIR__ use kar rahe hain taaki path sahi rahe chahe file kahin se bhi call ho
require_once(__DIR__ . '/../../config/db.php');

// 2. Session check karein (session_start() db.php mein hona chahiye)
// Agar user logged in nahi hai ya uska role 'delivery' nahi hai
if (!isset($_SESSION['delivery_id']) || $_SESSION['delivery_role'] !== 'delivery') {
    
    unset($_SESSION['user_id'], $_SESSION['admin_id']);
    header("Location: auth/login.php");
    exit();
}

// Compatibility
$_SESSION['user_id'] = $_SESSION['delivery_id'];
$_SESSION['user_role'] = $_SESSION['delivery_role'];

if (function_exists('qb_backfill_delivered_cod_payments')) {
    qb_backfill_delivered_cod_payments($conn, ['rider_id' => (int)$_SESSION['delivery_id']]);
}

// CSRF token bootstrap (for delivery actions/AJAX)
if (empty($_SESSION['csrf_token'])) {
    try {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } catch (Throwable $e) {
        $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
    }
}

if (!function_exists('qb_csrf_token')) {
    function qb_csrf_token(): string {
        return (string)($_SESSION['csrf_token'] ?? '');
    }
}

if (!function_exists('qb_verify_csrf_token')) {
    function qb_verify_csrf_token($token): bool {
        $sessionToken = (string)($_SESSION['csrf_token'] ?? '');
        if (!is_string($token) || $token === '' || $sessionToken === '') return false;
        return hash_equals($sessionToken, $token);
    }
}

if (!function_exists('qb_require_csrf')) {
    function qb_require_csrf(?string $token = null): void {
        $t = $token ?? ($_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? ''));
        if (!qb_verify_csrf_token($t)) {
            http_response_code(403);
            die('Invalid CSRF token.');
        }
    }
}

// 3. (Optional) Database Connection Variable Check
// Ye ensure karega ki $conn variable available hai
if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

/** * Ab aap is file ko header.php mein include karenge, 
 * jiske wajah se poora panel secure ho jayega.
 */
?>
