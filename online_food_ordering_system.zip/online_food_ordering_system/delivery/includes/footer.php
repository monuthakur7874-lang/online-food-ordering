</div> <div class="py-5"></div>

<footer class="mt-auto" style="padding-bottom: 2rem;">
    <div class="container">
        <div class="text-center text-md-start d-md-flex justify-content-between align-items-center gap-3 px-4 py-3" style="background:linear-gradient(135deg,#1f1b1c 0%,#321f24 48%,#5b2230 100%); border-radius:24px; box-shadow:0 18px 40px rgba(15,23,42,0.12);">
            <p class="small mb-2 mb-md-0" style="color:rgba(255,255,255,0.76);">
                &copy; <?php echo date('Y'); ?> <span class="fw-bold" style="color:#fff;">FOOD MONU RIDER</span>. Built for faster dispatch and smoother delivery flow.
            </p>
            <div class="small" style="color:rgba(255,255,255,0.68);">
                Live queue, route tracking, earnings and payout workflow in one place.
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php if (!empty($delivery_footer_before_realtime)) { echo $delivery_footer_before_realtime; } ?>
<?php $realtime_js_ver = @filemtime(__DIR__ . '/../assets/js/realtime.js') ?: time(); ?>
<script src="assets/js/realtime.js?v=<?php echo (int)$realtime_js_ver; ?>"></script>

</body>
</html>
