<?php
include('includes/db-connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id'])) {
    qb_require_csrf();
    $order_id = (int)($_POST['order_id'] ?? 0);
    $rider_id = (int)($_SESSION['user_id'] ?? 0);

    if ($order_id <= 0 || $rider_id <= 0) {
        header("Location: dashboard.php?error=Invalid+request");
        exit();
    }

    // Start delivery: Confirmed -> On the Way
    $query = "UPDATE orders SET order_status = 'On the Way' WHERE id = {$order_id} AND rider_id = {$rider_id} AND order_status = 'Confirmed'";
    
    $ok = mysqli_query($conn, $query);
    if ($ok && mysqli_affected_rows($conn) > 0) {
        header("Location: dashboard.php?msg=Delivery+started");
    } else {
        header("Location: dashboard.php?error=Failed+to+start");
    }
    exit();
}
?>
