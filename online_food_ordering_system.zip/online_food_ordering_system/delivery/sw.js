// Minimal Service Worker (optional). Keeps registration from 404'ing.
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// No caching by default.
