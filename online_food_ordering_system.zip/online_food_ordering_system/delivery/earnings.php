<?php
include('../config/db.php');
include('auth/auth-check.php');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$commission_per_delivery = 40;
$monthly_goal = 10000;

function qb_fetch_earnings_payload(mysqli $conn, int $rider_id, int $commission_per_delivery, int $monthly_goal): array {
    $today = date('Y-m-d');
    $month_start = date('Y-m-01');

    $payload = [
        'wallet_balance' => 0.0,
        'today_orders' => 0,
        'today_money' => 0,
        'month_orders' => 0,
        'month_money' => 0,
        'lifetime_orders' => 0,
        'lifetime_money' => 0,
        'avg_daily' => 0,
        'goal_progress' => 0,
        'recent_earnings' => [],
        'generated_at' => date('h:i A'),
    ];

    $user_q = mysqli_query($conn, "SELECT wallet_balance FROM users WHERE id = {$rider_id} LIMIT 1");
    if ($user_q && ($user_row = mysqli_fetch_assoc($user_q))) {
        $payload['wallet_balance'] = (float)($user_row['wallet_balance'] ?? 0);
    }

    $stats_sql = "
        SELECT
            SUM(CASE WHEN order_status = 'Delivered' AND DATE(order_date) = '{$today}' THEN 1 ELSE 0 END) AS today_orders,
            SUM(CASE WHEN order_status = 'Delivered' AND order_date >= '{$month_start}' THEN 1 ELSE 0 END) AS month_orders,
            SUM(CASE WHEN order_status = 'Delivered' THEN 1 ELSE 0 END) AS lifetime_orders
        FROM orders
        WHERE rider_id = {$rider_id}";
    $stats_res = mysqli_query($conn, $stats_sql);
    if ($stats_res && ($stats_row = mysqli_fetch_assoc($stats_res))) {
        $payload['today_orders'] = (int)($stats_row['today_orders'] ?? 0);
        $payload['month_orders'] = (int)($stats_row['month_orders'] ?? 0);
        $payload['lifetime_orders'] = (int)($stats_row['lifetime_orders'] ?? 0);
    }

    $payload['today_money'] = $payload['today_orders'] * $commission_per_delivery;
    $payload['month_money'] = $payload['month_orders'] * $commission_per_delivery;
    $payload['lifetime_money'] = $payload['lifetime_orders'] * $commission_per_delivery;
    $days_elapsed = max(1, (int)date('j'));
    $payload['avg_daily'] = (int)round($payload['month_money'] / $days_elapsed);
    $payload['goal_progress'] = min(100, (int)round(($payload['month_money'] / max(1, $monthly_goal)) * 100));

    $history_q = mysqli_query(
        $conn,
        "SELECT id, total_amount, payment_mode, payment_status, order_date
         FROM orders
         WHERE rider_id = {$rider_id} AND order_status = 'Delivered'
         ORDER BY order_date DESC, id DESC
         LIMIT 6"
    );
    if ($history_q) {
        while ($row = mysqli_fetch_assoc($history_q)) {
            $payload['recent_earnings'][] = [
                'id' => (int)$row['id'],
                'order_date' => (string)($row['order_date'] ?? ''),
                'total_amount' => (float)($row['total_amount'] ?? 0),
                'payment_mode' => (string)($row['payment_mode'] ?? ''),
                'payment_status' => (string)($row['payment_status'] ?? ''),
                'earning_amount' => $commission_per_delivery,
            ];
        }
    }

    return $payload;
}

$payload = qb_fetch_earnings_payload($conn, $rider_id, $commission_per_delivery, $monthly_goal);

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit();
}

$delivery_page_title = 'Earnings - Rider Panel';
include('includes/header.php');
?>

<style>
    .earnings-shell {
        max-width: 1420px;
        margin: 0 auto;
    }

    .earnings-hero {
        position: relative;
        overflow: hidden;
        margin-bottom: 1.5rem;
        padding: 1.8rem;
        border-radius: 28px;
        background:
            radial-gradient(circle at top left, rgba(255,255,255,0.16), transparent 34%),
            linear-gradient(135deg, #0f172a 0%, #1d3557 42%, #c2410c 100%);
        color: #fff;
        box-shadow: 0 24px 58px rgba(15,23,42,0.22);
    }

    .earnings-hero::after {
        content: '';
        position: absolute;
        right: -90px;
        bottom: -130px;
        width: 290px;
        height: 290px;
        border-radius: 50%;
        background: rgba(255,255,255,0.08);
    }

    .earnings-hero-grid {
        position: relative;
        z-index: 1;
        display: grid;
        grid-template-columns: minmax(0, 1.45fr) minmax(320px, 0.95fr);
        gap: 1.15rem;
        align-items: center;
    }

    .earnings-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.55rem;
        padding: 0.45rem 0.85rem;
        border-radius: 999px;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.16);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
    }

    .earnings-hero h1 {
        margin: 0.95rem 0 0.55rem;
        font-size: clamp(1.9rem, 3vw, 2.8rem);
        font-weight: 800;
        line-height: 1.06;
    }

    .earnings-hero p {
        margin: 0;
        max-width: 700px;
        color: rgba(255,255,255,0.8);
        font-size: 0.98rem;
    }

    .earnings-actions {
        display: flex;
        gap: 0.85rem;
        flex-wrap: wrap;
        margin-top: 1.25rem;
    }

    .earnings-actions .btn {
        border-radius: 14px;
        padding: 0.82rem 1rem;
        font-weight: 700;
    }

    .wallet-side {
        display: grid;
        gap: 0.85rem;
    }

    .wallet-panel {
        padding: 1rem 1.1rem;
        border-radius: 22px;
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.16);
        backdrop-filter: blur(12px);
    }

    .wallet-panel .k {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: rgba(255,255,255,0.66);
    }

    .wallet-panel .v {
        margin-top: 0.45rem;
        font-size: 1.85rem;
        font-weight: 800;
        line-height: 1;
    }

    .wallet-panel .t {
        margin-top: 0.36rem;
        color: rgba(255,255,255,0.76);
        font-size: 0.88rem;
    }

    .earnings-kpis {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 1rem;
        margin-bottom: 1.35rem;
    }

    .earnings-kpi {
        background: rgba(255,255,255,0.96);
        border: 1px solid rgba(15,23,42,0.08);
        border-radius: 22px;
        padding: 1.1rem 1.15rem;
        box-shadow: 0 16px 34px rgba(15,23,42,0.08);
    }

    [data-theme='dark'] .earnings-kpi,
    [data-theme='dark'] .earnings-panel,
    [data-theme='dark'] .insight-box {
        background: rgba(15,23,42,0.74);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 18px 40px rgba(0,0,0,0.34);
    }

    .earnings-kpi-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.9rem;
    }

    .earnings-kpi-icon {
        width: 46px;
        height: 46px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
        color: #fff;
    }

    .icon-wallet { background: linear-gradient(135deg, #f59e0b, #ea580c); }
    .icon-today { background: linear-gradient(135deg, #11998e, #38ef7d); }
    .icon-month { background: linear-gradient(135deg, #2563eb, #1d4ed8); }
    .icon-avg { background: linear-gradient(135deg, #8b5cf6, #6366f1); }

    .earnings-kpi-chip {
        padding: 0.38rem 0.68rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        color: #475569;
        font-size: 0.74rem;
        font-weight: 700;
    }

    [data-theme='dark'] .earnings-kpi-chip {
        background: rgba(255,255,255,0.08);
        color: rgba(255,255,255,0.76);
    }

    .earnings-kpi-value {
        font-size: 1.82rem;
        font-weight: 800;
        color: var(--text-color);
        line-height: 1;
    }

    .earnings-kpi-note {
        margin-top: 0.35rem;
        font-size: 0.9rem;
        color: var(--muted);
    }

    .earnings-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 320px;
        gap: 1rem;
        align-items: start;
    }

    .earnings-panel,
    .insight-box {
        background: rgba(255,255,255,0.96);
        border: 1px solid rgba(15,23,42,0.08);
        border-radius: 24px;
        padding: 1.15rem;
        box-shadow: 0 16px 34px rgba(15,23,42,0.08);
    }

    .panel-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
        margin-bottom: 1rem;
    }

    .panel-head h5,
    .insight-head h6 {
        margin: 0;
        font-weight: 800;
        color: var(--text-color);
    }

    .panel-head p,
    .insight-head p {
        margin: 0.25rem 0 0;
        color: var(--muted);
        font-size: 0.9rem;
    }

    .earnings-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.52rem 0.8rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        border: 1px solid rgba(15,23,42,0.08);
        color: #475569;
        font-size: 0.8rem;
        font-weight: 700;
    }

    [data-theme='dark'] .earnings-pill {
        background: rgba(255,255,255,0.06);
        border-color: rgba(255,255,255,0.1);
        color: rgba(255,255,255,0.76);
    }

    .goal-wrap {
        padding: 1rem 1.05rem;
        border-radius: 20px;
        background: linear-gradient(135deg, rgba(249,115,22,0.1), rgba(14,165,233,0.1));
        border: 1px solid rgba(249,115,22,0.14);
        margin-bottom: 1rem;
    }

    .goal-wrap-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        margin-bottom: 0.7rem;
    }

    .goal-wrap-top strong {
        color: var(--text-color);
        font-size: 0.95rem;
        font-weight: 800;
    }

    .goal-wrap-top span {
        color: var(--muted);
        font-size: 0.86rem;
        font-weight: 700;
    }

    .goal-progress {
        height: 10px;
        border-radius: 999px;
        background: rgba(15,23,42,0.08);
        overflow: hidden;
    }

    .goal-progress > div {
        height: 100%;
        border-radius: 999px;
        background: linear-gradient(90deg, #f59e0b, #f97316);
    }

    .transactions-list {
        display: grid;
        gap: 0.9rem;
    }

    .txn-card {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        border-radius: 20px;
        background: rgba(255,255,255,0.9);
        border: 1px solid rgba(15,23,42,0.08);
        box-shadow: 0 12px 24px rgba(15,23,42,0.06);
    }

    [data-theme='dark'] .txn-card {
        background: rgba(15,23,42,0.62);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 14px 28px rgba(0,0,0,0.28);
    }

    .txn-left {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        min-width: 0;
    }

    .txn-icon {
        width: 46px;
        height: 46px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(34,197,94,0.14), rgba(16,185,129,0.14));
        color: #16a34a;
        flex: 0 0 auto;
    }

    .txn-copy strong {
        display: block;
        color: var(--text-color);
        font-size: 0.95rem;
        font-weight: 800;
    }

    .txn-copy span {
        display: block;
        margin-top: 0.2rem;
        color: var(--muted);
        font-size: 0.84rem;
    }

    .txn-right {
        text-align: right;
    }

    .txn-right strong {
        display: block;
        font-size: 1.05rem;
        font-weight: 800;
        color: #16a34a;
    }

    .txn-right span {
        display: block;
        margin-top: 0.2rem;
        color: var(--muted);
        font-size: 0.78rem;
        font-weight: 700;
    }

    .insight-stack {
        display: grid;
        gap: 1rem;
    }

    .insight-head {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.9rem;
    }

    .insight-icon {
        width: 44px;
        height: 44px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(37,99,235,0.14), rgba(15,118,110,0.18));
        color: #0f766e;
        font-size: 1rem;
    }

    .mini-stat {
        padding: 0.92rem 0.95rem;
        border-radius: 18px;
        background: rgba(15,23,42,0.04);
        margin-bottom: 0.75rem;
    }

    [data-theme='dark'] .mini-stat {
        background: rgba(255,255,255,0.06);
    }

    .mini-stat:last-child {
        margin-bottom: 0;
    }

    .mini-stat .k {
        font-size: 0.72rem;
        font-weight: 800;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--muted);
    }

    .mini-stat .v {
        margin-top: 0.25rem;
        font-size: 1.35rem;
        font-weight: 800;
        color: var(--text-color);
        line-height: 1.1;
    }

    .mini-stat .t {
        margin-top: 0.2rem;
        font-size: 0.83rem;
        color: var(--muted);
    }

    .empty-state {
        padding: 2.3rem 1.2rem;
        border-radius: 22px;
        border: 1px dashed rgba(148,163,184,0.35);
        background: rgba(148,163,184,0.06);
        text-align: center;
    }

    [data-theme='dark'] .empty-state {
        background: rgba(255,255,255,0.04);
        border-color: rgba(255,255,255,0.12);
    }

    @media (max-width: 1200px) {
        .earnings-hero-grid,
        .earnings-kpis,
        .earnings-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .earnings-hero {
            padding: 1.25rem;
            border-radius: 24px;
        }

        .panel-head,
        .goal-wrap-top,
        .earnings-actions,
        .txn-card {
            flex-direction: column;
            align-items: stretch;
        }

        .txn-right {
            text-align: left;
        }
    }
</style>

<div class="earnings-shell">
    <div class="earnings-hero">
        <div class="earnings-hero-grid">
            <div>
                <span class="earnings-eyebrow"><i class="fas fa-wallet"></i> Rider Earnings Center</span>
                <h1>Track wallet balance, daily payouts, and monthly income in one cleaner financial dashboard.</h1>
                <p>Monitor your earning flow, review credited deliveries, and stay on top of your monthly goal with live synced rider stats.</p>
                <div class="earnings-actions">
                    <a href="payout-history.php" class="btn btn-light text-dark"><i class="fas fa-building-columns"></i> Payout History</a>
                    <a href="daily-summary.php" class="btn btn-outline-light"><i class="fas fa-calendar-day"></i> Daily Summary</a>
                </div>
            </div>
            <div class="wallet-side">
                <div class="wallet-panel">
                    <div class="k">Available Wallet</div>
                    <div class="v" id="walletBalanceHero">Rs <?= number_format((float)$payload['wallet_balance'], 2); ?></div>
                    <div class="t">Current withdrawable amount sitting in your rider wallet.</div>
                </div>
                <div class="wallet-panel">
                    <div class="k">This Month</div>
                    <div class="v" id="monthHeroValue">Rs <?= number_format((float)$payload['month_money'], 0); ?></div>
                    <div class="t"><?= (int)$payload['month_orders']; ?> delivered orders credited in the current month.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="earnings-kpis">
        <div class="earnings-kpi">
            <div class="earnings-kpi-top">
                <span class="earnings-kpi-icon icon-wallet"><i class="fas fa-wallet"></i></span>
                <span class="earnings-kpi-chip">Wallet</span>
            </div>
            <div class="earnings-kpi-value" id="walletBalance">Rs <?= number_format((float)$payload['wallet_balance'], 2); ?></div>
            <div class="earnings-kpi-note">Current balance available for future payout requests.</div>
        </div>

        <div class="earnings-kpi">
            <div class="earnings-kpi-top">
                <span class="earnings-kpi-icon icon-today"><i class="fas fa-bolt"></i></span>
                <span class="earnings-kpi-chip">Today</span>
            </div>
            <div class="earnings-kpi-value" id="todayMoney">Rs <?= number_format((float)$payload['today_money'], 0); ?></div>
            <div class="earnings-kpi-note" id="todayOrdersNote"><?= (int)$payload['today_orders']; ?> delivered orders credited today.</div>
        </div>

        <div class="earnings-kpi">
            <div class="earnings-kpi-top">
                <span class="earnings-kpi-icon icon-month"><i class="fas fa-chart-column"></i></span>
                <span class="earnings-kpi-chip">Month</span>
            </div>
            <div class="earnings-kpi-value" id="monthMoney">Rs <?= number_format((float)$payload['month_money'], 0); ?></div>
            <div class="earnings-kpi-note" id="monthOrdersNote"><?= (int)$payload['month_orders']; ?> completed trips in this month.</div>
        </div>

        <div class="earnings-kpi">
            <div class="earnings-kpi-top">
                <span class="earnings-kpi-icon icon-avg"><i class="fas fa-wave-square"></i></span>
                <span class="earnings-kpi-chip">Average</span>
            </div>
            <div class="earnings-kpi-value" id="avgDaily">Rs <?= number_format((float)$payload['avg_daily'], 0); ?></div>
            <div class="earnings-kpi-note">Average per day based on current month earnings pace.</div>
        </div>
    </div>

    <div class="earnings-layout">
        <div class="earnings-panel">
            <div class="panel-head">
                <div>
                    <h5><i class="fas fa-coins me-2 text-warning"></i>Recent Earnings Feed</h5>
                    <p>Latest delivered orders that generated rider income credits.</p>
                </div>
                <div class="earnings-pill" id="lastUpdated">
                    <i class="far fa-clock"></i>
                    Last updated: <?= htmlspecialchars($payload['generated_at'], ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>

            <div class="goal-wrap">
                <div class="goal-wrap-top">
                    <strong>Monthly Goal: Rs <?= number_format($monthly_goal, 0); ?></strong>
                    <span id="goalProgressLabel"><?= (int)$payload['goal_progress']; ?>% complete</span>
                </div>
                <div class="goal-progress">
                    <div id="goalProgressBar" style="width: <?= (int)$payload['goal_progress']; ?>%;"></div>
                </div>
            </div>

            <div id="recentEarningsList" class="transactions-list">
                <?php if (!empty($payload['recent_earnings'])): ?>
                    <?php foreach ($payload['recent_earnings'] as $row): ?>
                        <?php $date_value = strtotime($row['order_date']); ?>
                        <article class="txn-card">
                            <div class="txn-left">
                                <span class="txn-icon"><i class="fas fa-circle-check"></i></span>
                                <div class="txn-copy">
                                    <strong>Order #<?= qb_order_display_id((int)$row['id']); ?></strong>
                                    <span>
                                        <?= $date_value ? date('d M, h:i A', $date_value) : '-'; ?>
                                        &middot;
                                        <?= htmlspecialchars(trim(($row['payment_mode'] ?: 'Payment') . ' / ' . ($row['payment_status'] ?: 'Unknown')), ENT_QUOTES, 'UTF-8'); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="txn-right">
                                <strong>+Rs <?= number_format((float)$row['earning_amount'], 2); ?></strong>
                                <span>Order value Rs <?= number_format((float)$row['total_amount'], 0); ?></span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-wallet fa-3x mb-3 text-muted"></i>
                        <h5 class="text-muted mb-2">No earnings recorded yet.</h5>
                        <p class="text-muted small mb-0">Delivered orders will start appearing here automatically.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <aside class="insight-stack">
            <div class="insight-box">
                <div class="insight-head">
                    <span class="insight-icon"><i class="fas fa-bullseye"></i></span>
                    <div>
                        <h6>Financial Snapshot</h6>
                        <p>Quick dashboard-style money summary.</p>
                    </div>
                </div>
                <div class="mini-stat">
                    <div class="k">Lifetime Deliveries</div>
                    <div class="v" id="lifetimeOrders"><?= (int)$payload['lifetime_orders']; ?></div>
                    <div class="t">Total delivered orders that created rider commissions.</div>
                </div>
                <div class="mini-stat">
                    <div class="k">Lifetime Earnings</div>
                    <div class="v" id="lifetimeMoney">Rs <?= number_format((float)$payload['lifetime_money'], 0); ?></div>
                    <div class="t">Calculated at Rs <?= $commission_per_delivery; ?> per completed order.</div>
                </div>
            </div>

            <div class="insight-box">
                <div class="insight-head">
                    <span class="insight-icon"><i class="fas fa-lightbulb"></i></span>
                    <div>
                        <h6>Current Focus</h6>
                        <p>What this page is helping you watch right now.</p>
                    </div>
                </div>
                <div class="mini-stat">
                    <div class="k">Payout Readiness</div>
                    <div class="v" id="payoutReadiness"><?= $payload['wallet_balance'] > 0 ? 'Ready' : 'Low'; ?></div>
                    <div class="t">Wallet balance grows as delivered orders are credited.</div>
                </div>
                <div class="mini-stat">
                    <div class="k">Live Sync</div>
                    <div class="v">30s</div>
                    <div class="t">This page silently refreshes its earnings numbers every 30 seconds.</div>
                </div>
            </div>
        </aside>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const formatCurrency = (value, decimals = 0) => `Rs ${Number(value || 0).toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  })}`;

  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const walletBalanceHeroEl = document.getElementById('walletBalanceHero');
  const monthHeroValueEl = document.getElementById('monthHeroValue');
  const walletBalanceEl = document.getElementById('walletBalance');
  const todayMoneyEl = document.getElementById('todayMoney');
  const todayOrdersNoteEl = document.getElementById('todayOrdersNote');
  const monthMoneyEl = document.getElementById('monthMoney');
  const monthOrdersNoteEl = document.getElementById('monthOrdersNote');
  const avgDailyEl = document.getElementById('avgDaily');
  const goalProgressLabelEl = document.getElementById('goalProgressLabel');
  const goalProgressBarEl = document.getElementById('goalProgressBar');
  const recentEarningsListEl = document.getElementById('recentEarningsList');
  const lifetimeOrdersEl = document.getElementById('lifetimeOrders');
  const lifetimeMoneyEl = document.getElementById('lifetimeMoney');
  const payoutReadinessEl = document.getElementById('payoutReadiness');
  const lastUpdatedEl = document.getElementById('lastUpdated');

  const renderRecentEarnings = (entries) => {
    if (!Array.isArray(entries) || entries.length === 0) {
      return `
        <div class="empty-state">
          <i class="fas fa-wallet fa-3x mb-3 text-muted"></i>
          <h5 class="text-muted mb-2">No earnings recorded yet.</h5>
          <p class="text-muted small mb-0">Delivered orders will start appearing here automatically.</p>
        </div>`;
    }

    return entries.map((entry) => {
      const date = entry.order_date ? new Date(entry.order_date.replace(' ', 'T')) : null;
      const dateText = date && !Number.isNaN(date.getTime())
        ? date.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: true })
        : '-';
      const paymentText = `${entry.payment_mode || 'Payment'} / ${entry.payment_status || 'Unknown'}`;

      const rawId = Number(entry.id || 0);
      const displayId = 1000 + (((rawId * 7919) + 4173) % 9000);
      return `
        <article class="txn-card">
          <div class="txn-left">
            <span class="txn-icon"><i class="fas fa-circle-check"></i></span>
            <div class="txn-copy">
              <strong>Order #${displayId}</strong>
              <span>${escapeHtml(dateText)} &middot; ${escapeHtml(paymentText)}</span>
            </div>
          </div>
          <div class="txn-right">
            <strong>+${formatCurrency(entry.earning_amount, 2)}</strong>
            <span>Order value ${formatCurrency(entry.total_amount, 0)}</span>
          </div>
        </article>`;
    }).join('');
  };

  const applyPayload = (payload) => {
    if (!payload) return;

    if (walletBalanceHeroEl) walletBalanceHeroEl.textContent = formatCurrency(payload.wallet_balance, 2);
    if (monthHeroValueEl) monthHeroValueEl.textContent = formatCurrency(payload.month_money, 0);
    if (walletBalanceEl) walletBalanceEl.textContent = formatCurrency(payload.wallet_balance, 2);
    if (todayMoneyEl) todayMoneyEl.textContent = formatCurrency(payload.today_money, 0);
    if (todayOrdersNoteEl) todayOrdersNoteEl.textContent = `${Number(payload.today_orders || 0).toLocaleString('en-IN')} delivered orders credited today.`;
    if (monthMoneyEl) monthMoneyEl.textContent = formatCurrency(payload.month_money, 0);
    if (monthOrdersNoteEl) monthOrdersNoteEl.textContent = `${Number(payload.month_orders || 0).toLocaleString('en-IN')} completed trips in this month.`;
    if (avgDailyEl) avgDailyEl.textContent = formatCurrency(payload.avg_daily, 0);
    if (goalProgressLabelEl) goalProgressLabelEl.textContent = `${Number(payload.goal_progress || 0).toLocaleString('en-IN')}% complete`;
    if (goalProgressBarEl) goalProgressBarEl.style.width = `${Math.min(100, Number(payload.goal_progress || 0))}%`;
    if (recentEarningsListEl) recentEarningsListEl.innerHTML = renderRecentEarnings(payload.recent_earnings || []);
    if (lifetimeOrdersEl) lifetimeOrdersEl.textContent = Number(payload.lifetime_orders || 0).toLocaleString('en-IN');
    if (lifetimeMoneyEl) lifetimeMoneyEl.textContent = formatCurrency(payload.lifetime_money, 0);
    if (payoutReadinessEl) payoutReadinessEl.textContent = Number(payload.wallet_balance || 0) > 0 ? 'Ready' : 'Low';
    if (lastUpdatedEl) lastUpdatedEl.innerHTML = `<i class="far fa-clock"></i> Last updated: ${escapeHtml(payload.generated_at || '')}`;
  };

  const refreshEarnings = () => {
    fetch('earnings.php?ajax=1', { cache: 'no-store' })
      .then((response) => response.ok ? response.json() : null)
      .then((payload) => {
        if (payload) applyPayload(payload);
      })
      .catch(() => {});
  };

  setInterval(refreshEarnings, 30000);
});
</script>

<?php include('includes/footer.php'); ?>
