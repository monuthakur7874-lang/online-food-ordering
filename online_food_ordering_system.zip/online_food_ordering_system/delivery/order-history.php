<?php
include('../config/db.php');
include('auth/auth-check.php');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$allowed_statuses = ['Delivered', 'Cancelled'];
$status_filter = isset($_GET['status']) ? (string)$_GET['status'] : 'Delivered';
$status_filter = in_array($status_filter, $allowed_statuses, true) ? $status_filter : 'Delivered';
$commission_per_delivery = 40;

function qb_fetch_history_payload(mysqli $conn, int $rider_id, string $status_filter, int $commission_per_delivery): array {
    $totals = [
        'delivered_count' => 0,
        'cancelled_count' => 0,
        'today_deliveries' => 0,
        'today_earnings' => 0,
        'lifetime_earnings' => 0,
        'completion_rate' => 100,
    ];

    $stats_sql = "
        SELECT
            SUM(CASE WHEN order_status = 'Delivered' THEN 1 ELSE 0 END) AS delivered_count,
            SUM(CASE WHEN order_status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_count,
            SUM(CASE WHEN order_status = 'Delivered' AND DATE(order_date) = CURDATE() THEN 1 ELSE 0 END) AS today_deliveries
        FROM orders
        WHERE rider_id = {$rider_id}";
    $stats_res = mysqli_query($conn, $stats_sql);
    if ($stats_res && ($stats_row = mysqli_fetch_assoc($stats_res))) {
        $totals['delivered_count'] = (int)($stats_row['delivered_count'] ?? 0);
        $totals['cancelled_count'] = (int)($stats_row['cancelled_count'] ?? 0);
        $totals['today_deliveries'] = (int)($stats_row['today_deliveries'] ?? 0);
    }

    $totals['today_earnings'] = $totals['today_deliveries'] * $commission_per_delivery;
    $totals['lifetime_earnings'] = $totals['delivered_count'] * $commission_per_delivery;
    $closed_total = $totals['delivered_count'] + $totals['cancelled_count'];
    $totals['completion_rate'] = $closed_total > 0 ? (int)round(($totals['delivered_count'] / $closed_total) * 100) : 100;

    $status_safe = mysqli_real_escape_string($conn, $status_filter);
    $history_sql = "
        SELECT o.id, o.total_amount, o.payment_mode, o.payment_status, o.delivery_address, o.order_date, o.order_status, u.name AS c_name
        FROM orders o
        JOIN users u ON o.user_id = u.id
        WHERE o.rider_id = {$rider_id} AND o.order_status = '{$status_safe}'
        ORDER BY o.order_date DESC, o.id DESC";
    $history_res = mysqli_query($conn, $history_sql);

    $orders = [];
    if ($history_res) {
        while ($row = mysqli_fetch_assoc($history_res)) {
            $orders[] = [
                'id' => (int)$row['id'],
                'customer_name' => (string)($row['c_name'] ?? 'Customer'),
                'delivery_address' => (string)($row['delivery_address'] ?? ''),
                'order_date' => (string)($row['order_date'] ?? ''),
                'order_status' => (string)($row['order_status'] ?? ''),
                'payment_mode' => (string)($row['payment_mode'] ?? ''),
                'payment_status' => (string)($row['payment_status'] ?? ''),
                'total_amount' => (float)($row['total_amount'] ?? 0),
                'earning_amount' => ((string)($row['order_status'] ?? '') === 'Delivered') ? $commission_per_delivery : 0,
            ];
        }
    }

    return [
        'status_filter' => $status_filter,
        'totals' => $totals,
        'orders' => $orders,
        'selected_count' => count($orders),
        'generated_at' => date('h:i A'),
    ];
}

$payload = qb_fetch_history_payload($conn, $rider_id, $status_filter, $commission_per_delivery);

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit();
}

$delivery_page_title = 'Order History - Rider Panel';
include('includes/header.php');
?>

<style>
    .history-shell {
        max-width: 1420px;
        margin: 0 auto;
    }

    .history-hero {
        position: relative;
        overflow: hidden;
        margin-bottom: 1.5rem;
        padding: 1.75rem;
        border-radius: 28px;
        background:
            radial-gradient(circle at top left, rgba(255,255,255,0.14), transparent 34%),
            linear-gradient(135deg, #0f172a 0%, #1d3557 42%, #0f766e 100%);
        color: #fff;
        box-shadow: 0 24px 56px rgba(15, 23, 42, 0.2);
    }

    .history-hero::after {
        content: '';
        position: absolute;
        right: -90px;
        bottom: -120px;
        width: 300px;
        height: 300px;
        border-radius: 50%;
        background: rgba(255,255,255,0.08);
    }

    .history-hero-grid {
        position: relative;
        z-index: 1;
        display: grid;
        grid-template-columns: minmax(0, 1.45fr) minmax(300px, 0.95fr);
        gap: 1.2rem;
        align-items: center;
    }

    .history-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.55rem;
        padding: 0.45rem 0.85rem;
        border-radius: 999px;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.16);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
    }

    .history-hero h1 {
        margin: 0.95rem 0 0.55rem;
        font-size: clamp(1.85rem, 3vw, 2.7rem);
        font-weight: 800;
        line-height: 1.06;
    }

    .history-hero p {
        margin: 0;
        max-width: 680px;
        color: rgba(255,255,255,0.8);
        font-size: 0.98rem;
    }

    .history-actions {
        display: flex;
        gap: 0.85rem;
        flex-wrap: wrap;
        margin-top: 1.3rem;
    }

    .history-actions .btn {
        border-radius: 14px;
        padding: 0.82rem 1rem;
        font-weight: 700;
    }

    .hero-side {
        display: grid;
        gap: 0.85rem;
    }

    .hero-stat {
        padding: 1rem 1.1rem;
        border-radius: 22px;
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.16);
        backdrop-filter: blur(12px);
    }

    .hero-stat-label {
        font-size: 0.76rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: rgba(255,255,255,0.66);
    }

    .hero-stat-value {
        margin-top: 0.45rem;
        font-size: 1.8rem;
        font-weight: 800;
        line-height: 1;
    }

    .hero-stat-note {
        margin-top: 0.4rem;
        font-size: 0.88rem;
        color: rgba(255,255,255,0.74);
    }

    .history-kpis {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 1rem;
        margin-bottom: 1.35rem;
    }

    .history-kpi {
        background: rgba(255,255,255,0.95);
        border: 1px solid rgba(15,23,42,0.08);
        border-radius: 22px;
        padding: 1.1rem 1.15rem;
        box-shadow: 0 16px 34px rgba(15,23,42,0.08);
    }

    [data-theme='dark'] .history-kpi {
        background: rgba(15,23,42,0.72);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 16px 34px rgba(0,0,0,0.35);
    }

    .history-kpi-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.9rem;
    }

    .history-kpi-icon {
        width: 46px;
        height: 46px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
        color: #fff;
    }

    .icon-delivered { background: linear-gradient(135deg, #11998e, #38ef7d); }
    .icon-cancelled { background: linear-gradient(135deg, #ef4444, #f97316); }
    .icon-today { background: linear-gradient(135deg, #2563eb, #1d4ed8); }
    .icon-wallet { background: linear-gradient(135deg, #f59e0b, #ea580c); }

    .history-kpi-chip {
        padding: 0.38rem 0.68rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        color: #475569;
        font-size: 0.74rem;
        font-weight: 700;
    }

    [data-theme='dark'] .history-kpi-chip {
        background: rgba(255,255,255,0.08);
        color: rgba(255,255,255,0.76);
    }

    .history-kpi-value {
        font-size: 1.85rem;
        font-weight: 800;
        color: var(--text-color);
        line-height: 1;
    }

    .history-kpi-note {
        margin-top: 0.35rem;
        font-size: 0.9rem;
        color: var(--muted);
    }

    .history-panel {
        background: rgba(255,255,255,0.96);
        border: 1px solid rgba(15,23,42,0.08);
        border-radius: 24px;
        padding: 1.2rem;
        box-shadow: 0 16px 34px rgba(15,23,42,0.08);
    }

    [data-theme='dark'] .history-panel {
        background: rgba(15,23,42,0.74);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 18px 40px rgba(0,0,0,0.34);
    }

    .history-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 320px;
        gap: 1rem;
        align-items: start;
    }

    .history-panel-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
        margin-bottom: 1rem;
    }

    .history-panel-title h5 {
        margin: 0;
        font-weight: 800;
        color: var(--text-color);
    }

    .history-panel-title p {
        margin: 0.25rem 0 0;
        color: var(--muted);
        font-size: 0.9rem;
    }

    .history-tabs {
        display: inline-flex;
        gap: 0.5rem;
        padding: 0.45rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        border: 1px solid rgba(15,23,42,0.08);
    }

    [data-theme='dark'] .history-tabs {
        background: rgba(255,255,255,0.06);
        border-color: rgba(255,255,255,0.1);
    }

    .history-tab {
        padding: 0.72rem 1rem;
        border-radius: 999px;
        font-size: 0.9rem;
        font-weight: 800;
        color: #475569;
        text-decoration: none;
        transition: all .2s ease;
    }

    .history-tab.active {
        background: linear-gradient(135deg, #ff7a18, #f97316);
        color: #fff;
        box-shadow: 0 10px 22px rgba(249,115,22,0.22);
    }

    .history-statusbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
        margin-bottom: 1rem;
    }

    .history-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.52rem 0.8rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        border: 1px solid rgba(15,23,42,0.08);
        color: #475569;
        font-size: 0.8rem;
        font-weight: 700;
    }

    [data-theme='dark'] .history-pill {
        background: rgba(255,255,255,0.06);
        border-color: rgba(255,255,255,0.1);
        color: rgba(255,255,255,0.76);
    }

    .history-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 1rem;
    }

    .history-sidebar {
        display: grid;
        gap: 1rem;
    }

    .insight-card {
        background: rgba(255,255,255,0.96);
        border: 1px solid rgba(15,23,42,0.08);
        border-radius: 24px;
        padding: 1.1rem;
        box-shadow: 0 16px 34px rgba(15,23,42,0.08);
    }

    [data-theme='dark'] .insight-card {
        background: rgba(15,23,42,0.74);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 18px 40px rgba(0,0,0,0.34);
    }

    .insight-head {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.9rem;
    }

    .insight-icon {
        width: 44px;
        height: 44px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(37,99,235,0.14), rgba(15,118,110,0.18));
        color: #0f766e;
        font-size: 1rem;
    }

    .insight-head h6 {
        margin: 0;
        font-weight: 800;
        color: var(--text-color);
    }

    .insight-head p {
        margin: 0.18rem 0 0;
        font-size: 0.84rem;
        color: var(--muted);
    }

    .insight-metric {
        padding: 0.9rem 0.95rem;
        border-radius: 18px;
        background: rgba(15,23,42,0.04);
        margin-bottom: 0.75rem;
    }

    [data-theme='dark'] .insight-metric {
        background: rgba(255,255,255,0.06);
    }

    .insight-metric:last-child {
        margin-bottom: 0;
    }

    .insight-metric .k {
        font-size: 0.72rem;
        font-weight: 800;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--muted);
    }

    .insight-metric .v {
        margin-top: 0.25rem;
        font-size: 1.35rem;
        font-weight: 800;
        color: var(--text-color);
        line-height: 1.1;
    }

    .insight-metric .t {
        margin-top: 0.2rem;
        font-size: 0.83rem;
        color: var(--muted);
    }

    .focus-banner {
        padding: 1rem 1.05rem;
        border-radius: 20px;
        background: linear-gradient(135deg, rgba(14,165,233,0.1), rgba(249,115,22,0.1));
        border: 1px solid rgba(14,165,233,0.14);
    }

    .focus-banner strong {
        display: block;
        color: var(--text-color);
        font-size: 0.95rem;
        font-weight: 800;
    }

    .focus-banner span {
        display: block;
        margin-top: 0.28rem;
        color: var(--muted);
        font-size: 0.84rem;
    }

    .history-card {
        position: relative;
        overflow: hidden;
        background: rgba(255,255,255,0.92);
        border: 1px solid rgba(15,23,42,0.08);
        border-radius: 22px;
        padding: 1.15rem;
        box-shadow: 0 14px 28px rgba(15,23,42,0.08);
    }

    .history-card::before {
        content: '';
        position: absolute;
        inset: 0 auto 0 0;
        width: 5px;
        background: linear-gradient(180deg, #10b981, #22c55e);
    }

    .history-card.cancelled::before {
        background: linear-gradient(180deg, #ef4444, #f97316);
    }

    [data-theme='dark'] .history-card {
        background: rgba(15,23,42,0.66);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 16px 32px rgba(0,0,0,0.32);
    }

    .history-card-top {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 0.75rem;
        margin-bottom: 0.95rem;
    }

    .order-chip {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.35rem 0.65rem;
        border-radius: 12px;
        background: rgba(15,23,42,0.06);
        color: #0f172a;
        font-size: 0.75rem;
        font-weight: 800;
    }

    [data-theme='dark'] .order-chip {
        background: rgba(255,255,255,0.08);
        color: rgba(229,231,235,0.92);
    }

    .history-amount {
        text-align: right;
    }

    .history-amount strong {
        display: block;
        font-size: 1.2rem;
        font-weight: 800;
        color: var(--text-color);
    }

    .history-amount span {
        display: block;
        margin-top: 0.15rem;
        font-size: 0.76rem;
        color: var(--muted);
        font-weight: 700;
    }

    .history-customer {
        margin-bottom: 0.8rem;
    }

    .history-customer h6 {
        margin: 0 0 0.25rem;
        font-weight: 800;
        color: var(--text-color);
    }

    .history-address {
        margin: 0;
        color: var(--muted);
        font-size: 0.88rem;
        min-height: 48px;
    }

    .history-meta {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.7rem;
        margin-top: 0.95rem;
        padding-top: 0.95rem;
        border-top: 1px solid rgba(15,23,42,0.08);
    }

    [data-theme='dark'] .history-meta {
        border-top-color: rgba(255,255,255,0.1);
    }

    .history-meta-item {
        padding: 0.72rem 0.82rem;
        border-radius: 16px;
        background: rgba(15,23,42,0.04);
    }

    [data-theme='dark'] .history-meta-item {
        background: rgba(255,255,255,0.06);
    }

    .history-meta-item .k {
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: var(--muted);
        font-weight: 800;
    }

    .history-meta-item .v {
        margin-top: 0.22rem;
        font-size: 0.88rem;
        color: var(--text-color);
        font-weight: 700;
    }

    .history-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 0.75rem;
        flex-wrap: wrap;
        margin-top: 0.95rem;
    }

    .status-tag {
        padding: 0.44rem 0.75rem;
        border-radius: 999px;
        font-size: 0.74rem;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .status-delivered {
        background: rgba(34,197,94,0.14);
        color: #15803d;
        border: 1px solid rgba(34,197,94,0.18);
    }

    .status-cancelled {
        background: rgba(239,68,68,0.12);
        color: #b91c1c;
        border: 1px solid rgba(239,68,68,0.18);
    }

    .earning-pill {
        color: #16a34a;
        font-size: 0.82rem;
        font-weight: 800;
    }

    .history-empty {
        padding: 2.5rem 1.25rem;
        border-radius: 22px;
        border: 1px dashed rgba(148,163,184,0.35);
        background: rgba(148,163,184,0.06);
        text-align: center;
    }

    [data-theme='dark'] .history-empty {
        background: rgba(255,255,255,0.04);
        border-color: rgba(255,255,255,0.12);
    }

    .history-empty i {
        font-size: 2.8rem;
        color: #94a3b8;
        margin-bottom: 0.8rem;
    }

    @media (max-width: 1200px) {
        .history-hero-grid,
        .history-kpis,
        .history-grid,
        .history-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .history-hero {
            padding: 1.25rem;
            border-radius: 24px;
        }

        .history-panel-head,
        .history-statusbar,
        .history-actions {
            flex-direction: column;
            align-items: stretch;
        }

        .history-tabs {
            display: grid;
        }

        .history-meta {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="history-shell">
    <div class="history-hero">
        <div class="history-hero-grid">
            <div>
                <span class="history-eyebrow"><i class="fas fa-clock-rotate-left"></i> Professional Order Archive</span>
                <h1>Review completed trips, cancellations, and rider earnings in one clean live view.</h1>
                <p>Track your full delivery history with better clarity, refreshed summaries, and faster access to past customer drop-offs.</p>
                <div class="history-actions">
                    <a href="dashboard.php" class="btn btn-light text-dark"><i class="fas fa-house"></i> Dashboard</a>
                    <a href="earnings.php" class="btn btn-outline-light"><i class="fas fa-wallet"></i> Earnings</a>
                </div>
            </div>
            <div class="hero-side">
                <div class="hero-stat">
                    <div class="hero-stat-label">Selected View</div>
                    <div class="hero-stat-value" id="heroFilterLabel"><?= htmlspecialchars($payload['status_filter'], ENT_QUOTES, 'UTF-8'); ?></div>
                    <div class="hero-stat-note">Live history updates keep this panel synced with your latest completed work.</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-label">Lifetime Earnings</div>
                    <div class="hero-stat-value" id="heroLifetimeValue">Rs <?= number_format((float)$payload['totals']['lifetime_earnings'], 0); ?></div>
                    <div class="hero-stat-note">Calculated from delivered orders at Rs <?= $commission_per_delivery; ?> per completed trip.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="history-kpis">
        <div class="history-kpi">
            <div class="history-kpi-top">
                <span class="history-kpi-icon icon-delivered"><i class="fas fa-circle-check"></i></span>
                <span class="history-kpi-chip">Completed</span>
            </div>
            <div class="history-kpi-value" id="deliveredCount"><?= (int)$payload['totals']['delivered_count']; ?></div>
            <div class="history-kpi-note">Successfully delivered orders across your rider history.</div>
        </div>

        <div class="history-kpi">
            <div class="history-kpi-top">
                <span class="history-kpi-icon icon-cancelled"><i class="fas fa-ban"></i></span>
                <span class="history-kpi-chip">Cancelled</span>
            </div>
            <div class="history-kpi-value" id="cancelledCount"><?= (int)$payload['totals']['cancelled_count']; ?></div>
            <div class="history-kpi-note">Orders that were assigned but did not complete delivery.</div>
        </div>

        <div class="history-kpi">
            <div class="history-kpi-top">
                <span class="history-kpi-icon icon-today"><i class="fas fa-bolt"></i></span>
                <span class="history-kpi-chip">Today</span>
            </div>
            <div class="history-kpi-value" id="todayDeliveries"><?= (int)$payload['totals']['today_deliveries']; ?></div>
            <div class="history-kpi-note">Completed deliveries recorded for today.</div>
        </div>

        <div class="history-kpi">
            <div class="history-kpi-top">
                <span class="history-kpi-icon icon-wallet"><i class="fas fa-wallet"></i></span>
                <span class="history-kpi-chip">Earnings</span>
            </div>
            <div class="history-kpi-value" id="todayEarnings">Rs <?= number_format((float)$payload['totals']['today_earnings'], 0); ?></div>
            <div class="history-kpi-note">Estimated earnings from today&apos;s delivered trips.</div>
        </div>
    </div>

    <div class="history-layout">
        <div class="history-panel">
            <div class="history-panel-head">
                <div class="history-panel-title">
                    <h5><i class="fas fa-layer-group me-2 text-warning"></i>Rider History Feed</h5>
                    <p>Browse your latest delivered and cancelled orders in a more premium archive layout.</p>
                </div>
                <div class="history-tabs">
                    <a class="history-tab <?= $status_filter === 'Delivered' ? 'active' : ''; ?>" href="?status=Delivered" data-status-tab="Delivered">
                        <i class="fas fa-check-circle me-1"></i> Delivered
                    </a>
                    <a class="history-tab <?= $status_filter === 'Cancelled' ? 'active' : ''; ?>" href="?status=Cancelled" data-status-tab="Cancelled">
                        <i class="fas fa-times-circle me-1"></i> Cancelled
                    </a>
                </div>
            </div>

            <div class="history-statusbar">
                <div class="history-pill">
                    <i class="fas fa-signal"></i>
                    Auto-refresh every 30s
                </div>
                <div class="history-pill" id="historyLastUpdated">
                    <i class="far fa-clock"></i>
                    Last updated: <?= htmlspecialchars($payload['generated_at'], ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>

            <div id="historyList" class="history-grid" data-selected-status="<?= htmlspecialchars($status_filter, ENT_QUOTES, 'UTF-8'); ?>">
                <?php if (!empty($payload['orders'])): ?>
                    <?php foreach ($payload['orders'] as $order): ?>
                        <?php
                            $is_delivered = $order['order_status'] === 'Delivered';
                            $date_value = strtotime($order['order_date']);
                            $address = (string)$order['delivery_address'];
                            $short_address = mb_strimwidth($address, 0, 68, '...');
                            $payment_label = trim(($order['payment_mode'] ?: 'Payment') . ' / ' . ($order['payment_status'] ?: 'Unknown'));
                        ?>
                        <article class="history-card <?= $is_delivered ? 'delivered' : 'cancelled'; ?>">
                            <div class="history-card-top">
                                <span class="order-chip"><i class="fas fa-hashtag"></i> #<?= qb_order_display_id((int)$order['id']); ?></span>
                                <div class="history-amount">
                                    <strong>Rs <?= number_format((float)$order['total_amount'], 0); ?></strong>
                                    <span>Order value</span>
                                </div>
                            </div>

                            <div class="history-customer">
                                <h6><?= htmlspecialchars($order['customer_name'], ENT_QUOTES, 'UTF-8'); ?></h6>
                                <p class="history-address"><i class="fas fa-location-dot text-danger me-1"></i><?= htmlspecialchars($short_address, ENT_QUOTES, 'UTF-8'); ?></p>
                            </div>

                            <div class="history-meta">
                                <div class="history-meta-item">
                                    <div class="k">Date</div>
                                    <div class="v"><?= $date_value ? date('d M, Y', $date_value) : '-'; ?></div>
                                </div>
                                <div class="history-meta-item">
                                    <div class="k">Time</div>
                                    <div class="v"><?= $date_value ? date('h:i A', $date_value) : '-'; ?></div>
                                </div>
                                <div class="history-meta-item">
                                    <div class="k">Payment</div>
                                    <div class="v"><?= htmlspecialchars($payment_label, ENT_QUOTES, 'UTF-8'); ?></div>
                                </div>
                                <div class="history-meta-item">
                                    <div class="k">Status</div>
                                    <div class="v"><?= htmlspecialchars($order['order_status'], ENT_QUOTES, 'UTF-8'); ?></div>
                                </div>
                            </div>

                            <div class="history-footer">
                                <span class="status-tag <?= $is_delivered ? 'status-delivered' : 'status-cancelled'; ?>">
                                    <?= htmlspecialchars($order['order_status'], ENT_QUOTES, 'UTF-8'); ?>
                                </span>
                                <?php if ($is_delivered): ?>
                                    <span class="earning-pill"><i class="fas fa-coins me-1"></i>+Rs <?= number_format((float)$order['earning_amount'], 0); ?> earned</span>
                                <?php else: ?>
                                    <span class="text-danger small fw-bold"><i class="fas fa-triangle-exclamation me-1"></i>No payout</span>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="history-empty" style="grid-column: 1 / -1;">
                        <i class="fas fa-box-open"></i>
                        <h5 class="mb-2 text-muted">No <?= strtolower(htmlspecialchars($status_filter, ENT_QUOTES, 'UTF-8')); ?> records yet.</h5>
                        <p class="mb-0 text-muted small">New history will appear here automatically as your delivery work updates.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <aside class="history-sidebar">
            <div class="insight-card">
                <div class="insight-head">
                    <span class="insight-icon"><i class="fas fa-wave-square"></i></span>
                    <div>
                        <h6>Performance Snapshot</h6>
                        <p>Dashboard-style quick read on your history.</p>
                    </div>
                </div>
                <div class="insight-metric">
                    <div class="k">Completion Rate</div>
                    <div class="v" id="completionRate"><?= (int)$payload['totals']['completion_rate']; ?>%</div>
                    <div class="t">Delivered orders as a share of all closed assignments.</div>
                </div>
                <div class="insight-metric">
                    <div class="k">Visible Records</div>
                    <div class="v" id="selectedCount"><?= (int)$payload['selected_count']; ?></div>
                    <div class="t">Orders currently shown in the selected filter.</div>
                </div>
            </div>

            <div class="insight-card">
                <div class="insight-head">
                    <span class="insight-icon"><i class="fas fa-compass"></i></span>
                    <div>
                        <h6>Current Focus</h6>
                        <p>Context for the active history view.</p>
                    </div>
                </div>
                <div class="focus-banner">
                    <strong id="focusTitle"><?= $status_filter === 'Delivered' ? 'Delivered orders are highlighted now.' : 'Cancelled orders are highlighted now.'; ?></strong>
                    <span id="focusText"><?= $status_filter === 'Delivered'
                        ? 'Use this to review completed trips, earnings, and successful customer drop-offs.'
                        : 'Use this to inspect dropped assignments and understand where delivery attempts did not close.'; ?></span>
                </div>
            </div>
        </aside>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const historyList = document.getElementById('historyList');
  if (!historyList) return;

  const deliveredCountEl = document.getElementById('deliveredCount');
  const cancelledCountEl = document.getElementById('cancelledCount');
  const todayDeliveriesEl = document.getElementById('todayDeliveries');
  const todayEarningsEl = document.getElementById('todayEarnings');
  const heroFilterLabelEl = document.getElementById('heroFilterLabel');
  const heroLifetimeValueEl = document.getElementById('heroLifetimeValue');
  const historyLastUpdatedEl = document.getElementById('historyLastUpdated');
  const completionRateEl = document.getElementById('completionRate');
  const selectedCountEl = document.getElementById('selectedCount');
  const focusTitleEl = document.getElementById('focusTitle');
  const focusTextEl = document.getElementById('focusText');

  const formatNumber = (value) => Number(value || 0).toLocaleString('en-IN');
  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const truncate = (value, maxLength) => {
    const text = String(value || '');
    return text.length > maxLength ? `${text.slice(0, maxLength - 3)}...` : text;
  };

  const renderOrders = (orders, selectedStatus) => {
    if (!Array.isArray(orders) || orders.length === 0) {
      return `
        <div class="history-empty" style="grid-column: 1 / -1;">
          <i class="fas fa-box-open"></i>
          <h5 class="mb-2 text-muted">No ${escapeHtml(String(selectedStatus || '').toLowerCase())} records yet.</h5>
          <p class="mb-0 text-muted small">New history will appear here automatically as your delivery work updates.</p>
        </div>`;
    }

    return orders.map((order) => {
      const isDelivered = order.order_status === 'Delivered';
      const date = order.order_date ? new Date(order.order_date.replace(' ', 'T')) : null;
      const dateText = date && !Number.isNaN(date.getTime())
        ? date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
        : '-';
      const timeText = date && !Number.isNaN(date.getTime())
        ? date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
        : '-';
      const paymentLabel = `${order.payment_mode || 'Payment'} / ${order.payment_status || 'Unknown'}`;

      const rawId = Number(order.id || 0);
      const displayId = 1000 + (((rawId * 7919) + 4173) % 9000);
      return `
        <article class="history-card ${isDelivered ? 'delivered' : 'cancelled'}">
          <div class="history-card-top">
            <span class="order-chip"><i class="fas fa-hashtag"></i> #${displayId}</span>
            <div class="history-amount">
              <strong>Rs ${formatNumber(order.total_amount)}</strong>
              <span>Order value</span>
            </div>
          </div>

          <div class="history-customer">
            <h6>${escapeHtml(order.customer_name || 'Customer')}</h6>
            <p class="history-address"><i class="fas fa-location-dot text-danger me-1"></i>${escapeHtml(truncate(order.delivery_address || '', 68))}</p>
          </div>

          <div class="history-meta">
            <div class="history-meta-item">
              <div class="k">Date</div>
              <div class="v">${escapeHtml(dateText)}</div>
            </div>
            <div class="history-meta-item">
              <div class="k">Time</div>
              <div class="v">${escapeHtml(timeText)}</div>
            </div>
            <div class="history-meta-item">
              <div class="k">Payment</div>
              <div class="v">${escapeHtml(paymentLabel)}</div>
            </div>
            <div class="history-meta-item">
              <div class="k">Status</div>
              <div class="v">${escapeHtml(order.order_status || '')}</div>
            </div>
          </div>

          <div class="history-footer">
            <span class="status-tag ${isDelivered ? 'status-delivered' : 'status-cancelled'}">${escapeHtml(order.order_status || '')}</span>
            ${isDelivered
              ? `<span class="earning-pill"><i class="fas fa-coins me-1"></i>+Rs ${formatNumber(order.earning_amount || 0)} earned</span>`
              : '<span class="text-danger small fw-bold"><i class="fas fa-triangle-exclamation me-1"></i>No payout</span>'}
          </div>
        </article>`;
    }).join('');
  };

  const applyPayload = (payload) => {
    if (!payload || !payload.totals) return;

    historyList.dataset.selectedStatus = payload.status_filter || 'Delivered';
    historyList.innerHTML = renderOrders(payload.orders || [], payload.status_filter || 'Delivered');

    if (deliveredCountEl) deliveredCountEl.textContent = formatNumber(payload.totals.delivered_count);
    if (cancelledCountEl) cancelledCountEl.textContent = formatNumber(payload.totals.cancelled_count);
    if (todayDeliveriesEl) todayDeliveriesEl.textContent = formatNumber(payload.totals.today_deliveries);
    if (todayEarningsEl) todayEarningsEl.textContent = `Rs ${formatNumber(payload.totals.today_earnings)}`;
    if (heroFilterLabelEl) heroFilterLabelEl.textContent = payload.status_filter || 'Delivered';
    if (heroLifetimeValueEl) heroLifetimeValueEl.textContent = `Rs ${formatNumber(payload.totals.lifetime_earnings)}`;
    if (historyLastUpdatedEl) historyLastUpdatedEl.innerHTML = `<i class="far fa-clock"></i> Last updated: ${escapeHtml(payload.generated_at || '')}`;
    if (completionRateEl) completionRateEl.textContent = `${formatNumber(payload.totals.completion_rate)}%`;
    if (selectedCountEl) selectedCountEl.textContent = formatNumber(payload.selected_count || 0);
    if (focusTitleEl) {
      focusTitleEl.textContent = payload.status_filter === 'Delivered'
        ? 'Delivered orders are highlighted now.'
        : 'Cancelled orders are highlighted now.';
    }
    if (focusTextEl) {
      focusTextEl.textContent = payload.status_filter === 'Delivered'
        ? 'Use this to review completed trips, earnings, and successful customer drop-offs.'
        : 'Use this to inspect dropped assignments and understand where delivery attempts did not close.';
    }
  };

  const refreshHistory = () => {
    const selectedStatus = historyList.dataset.selectedStatus || 'Delivered';
    fetch(`order-history.php?ajax=1&status=${encodeURIComponent(selectedStatus)}`, { cache: 'no-store' })
      .then((response) => response.ok ? response.json() : null)
      .then((payload) => {
        if (payload) applyPayload(payload);
      })
      .catch(() => {});
  };

  setInterval(refreshHistory, 30000);
});
</script>

<?php include('includes/footer.php'); ?>
