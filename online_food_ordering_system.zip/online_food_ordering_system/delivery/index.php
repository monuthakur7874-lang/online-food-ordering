<?php
require_once(__DIR__ . '/includes/db-connect.php');
header('Location: dashboard.php');
exit();
