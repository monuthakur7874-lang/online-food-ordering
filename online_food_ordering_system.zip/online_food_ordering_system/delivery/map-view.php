<?php
require_once(__DIR__ . '/includes/db-connect.php');

$delivery_page_title = 'Live Tracking Map - Rider Panel';
$delivery_head_extra = '<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />';

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$r_lat = 20.5937; // India center
$r_lng = 78.9629;

if ($rider_id > 0) {
    $res = mysqli_query($conn, "SELECT lat, lng FROM users WHERE id={$rider_id} AND role='delivery' LIMIT 1");
    if ($res) {
        $row = mysqli_fetch_assoc($res);
        $lat_raw = $row['lat'] ?? null;
        $lng_raw = $row['lng'] ?? null;
        if (is_numeric($lat_raw) && is_numeric($lng_raw)) {
            $r_lat = (float)$lat_raw;
            $r_lng = (float)$lng_raw;
        }
    }
}

include(__DIR__ . '/includes/header.php');
?>

<style>
  .map-shell {
    max-width: 1400px;
    margin: 0 auto;
  }

  .map-hero {
    position: relative;
    overflow: hidden;
    margin-bottom: 1rem;
    padding: 1.4rem 1.5rem;
    border-radius: 28px;
    background:
      radial-gradient(circle at top left, rgba(255,255,255,0.22), transparent 34%),
      linear-gradient(135deg, #cb1b45 0%, #e23744 48%, #ff7e8b 100%);
    color: #fff;
    box-shadow: 0 24px 50px rgba(226,55,68,0.18);
  }

  .map-hero::after {
    content: '';
    position: absolute;
    right: -60px;
    bottom: -80px;
    width: 180px;
    height: 180px;
    border-radius: 50%;
    background: rgba(255,255,255,0.12);
  }

  .map-panel {
    background: rgba(255,255,255,0.98);
    border: 1px solid rgba(226,55,68,0.08);
    border-radius: 24px;
    box-shadow: 0 18px 38px rgba(15,23,42,0.06);
  }

  [data-theme='dark'] .map-panel {
    background: linear-gradient(180deg, rgba(37,23,28,0.96), rgba(24,20,28,0.94));
    border-color: rgba(255,255,255,0.08);
  }

  #fullscreenMap {
    border-radius: 24px !important;
    border: 1px solid rgba(226,55,68,0.08);
  }

  .map-status-bar {
    position: absolute;
    top: 18px;
    left: 18px;
    right: 18px;
    z-index: 900;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    flex-wrap: wrap;
    pointer-events: none;
  }

  .map-status-pill,
  .map-action-btn {
    pointer-events: auto;
  }

  .map-status-pill {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 12px 16px;
    border-radius: 999px;
    background: rgba(255,255,255,0.95);
    border: 1px solid rgba(226,55,68,0.10);
    box-shadow: 0 18px 35px rgba(15,23,42,0.10);
    color: #1f2937;
    font-size: 0.92rem;
    font-weight: 600;
  }

  .map-status-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #9ca3af;
    box-shadow: 0 0 0 6px rgba(156,163,175,0.15);
    transition: all 0.2s ease;
  }

  .map-status-pill.is-live .map-status-dot {
    background: #22c55e;
    box-shadow: 0 0 0 6px rgba(34,197,94,0.16);
  }

  .map-status-pill.is-warn .map-status-dot {
    background: #f59e0b;
    box-shadow: 0 0 0 6px rgba(245,158,11,0.16);
  }

  .map-status-pill.is-error .map-status-dot {
    background: #ef4444;
    box-shadow: 0 0 0 6px rgba(239,68,68,0.16);
  }

  .map-action-btn {
    border: 0;
    border-radius: 999px;
    padding: 12px 18px;
    background: linear-gradient(135deg, #e23744, #ff7e8b);
    color: #fff;
    font-weight: 700;
    box-shadow: 0 18px 35px rgba(226,55,68,0.22);
  }

  .map-action-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    box-shadow: none;
  }

  @media (max-width: 768px) {
    .map-status-bar {
      top: 12px;
      left: 12px;
      right: 12px;
    }

    .map-status-pill,
    .map-action-btn {
      width: 100%;
      justify-content: center;
    }
  }
</style>

<div class="map-shell">
    <div class="map-hero">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 position-relative" style="z-index:1;">
            <div>
                <h1 class="h4 mb-1 fw-bold"><i class="fas fa-map me-2"></i>Live Tracking Map</h1>
                <small class="opacity-75">Real-time order locations and your live position</small>
            </div>
            <a href="dashboard.php" class="btn btn-light rounded-pill px-3"><i class="fas fa-arrow-left me-2"></i>Back</a>
        </div>
    </div>

    <div class="position-relative">
        <div id="fullscreenMap" style="height: 80vh; width: 100%; border-radius: 16px; overflow: hidden;"></div>
        <div class="map-status-bar">
            <div id="mapStatusPill" class="map-status-pill">
                <span class="map-status-dot"></span>
                <span id="mapStatusText">Turn on Online to start live location.</span>
            </div>
            <button id="mapLocateBtn" type="button" class="map-action-btn">
                <i class="fas fa-location-crosshairs me-2"></i>Use My Live Location
            </button>
        </div>
        <div id="fullMapPlaceholder" class="live-map-placeholder" style="border-radius: 16px;">
            <div class="text-center px-3">
                <div class="h5 fw-bold mb-2"><i class="fas fa-signal me-2 text-warning"></i>Go Online to view live map</div>
                <div class="text-muted small">Turn on <b>Online</b> to share your live location.</div>
            </div>
        </div>
    </div>

    <div class="position-fixed bottom-0 end-0 m-4" style="z-index: 1000;">
        <div class="map-panel p-3" style="max-width: 360px;">
            <h6 class="mb-2">Active Orders</h6>
            <div id="mapOrdersList" class="orders-list small"></div>
        </div>
    </div>
</div>

<script>
  window.riderId = <?= (int)$rider_id ?>;
</script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
  const dutyToggle = document.getElementById('dutyToggle');
  const placeholder = document.getElementById('fullMapPlaceholder');
  const mapEl = document.getElementById('fullscreenMap');
  const mapStatusPill = document.getElementById('mapStatusPill');
  const mapStatusText = document.getElementById('mapStatusText');
  const mapLocateBtn = document.getElementById('mapLocateBtn');
  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const isOnline = () => (!dutyToggle ? true : !!dutyToggle.checked);
  let watcherId = null;
  let hasCenteredOnLiveLocation = false;

  const setStatus = (message, state = 'idle') => {
    if (mapStatusText) mapStatusText.textContent = message;
    if (mapStatusPill) {
      mapStatusPill.classList.remove('is-live', 'is-warn', 'is-error');
      if (state === 'live') mapStatusPill.classList.add('is-live');
      if (state === 'warn') mapStatusPill.classList.add('is-warn');
      if (state === 'error') mapStatusPill.classList.add('is-error');
    }
  };

  const setVisible = () => {
    const on = isOnline();
    if (mapEl) mapEl.style.visibility = on ? 'visible' : 'hidden';
    if (placeholder) placeholder.style.display = on ? 'none' : 'flex';
    if (mapLocateBtn) mapLocateBtn.disabled = !on;
    if (!on) setStatus('Turn on Online to start live location.');
  };

  setVisible();
  const map = L.map('fullscreenMap').setView([<?= (float)$r_lat ?>, <?= (float)$r_lng ?>], <?= ($r_lat === 20.5937 && $r_lng === 78.9629) ? 5 : 13 ?>);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: 'OpenStreetMap'
  }).addTo(map);

  const riderIcon = L.divIcon({
    className: 'rider-marker',
    html: '<div style="background:#2563eb;width:30px;height:30px;border-radius:50%;border:4px solid #fff;box-shadow:0 2px 10px rgba(0,0,0,0.25);"></div>',
    iconSize: [30, 30]
  });

  const riderMarker = L.marker([<?= (float)$r_lat ?>, <?= (float)$r_lng ?>], { icon: riderIcon }).addTo(map);
  riderMarker.bindPopup('<b>You</b>');

  const orderMarkers = {};

  function loadOrders() {
    fetch('get-active-orders.php?rider_id=' + window.riderId)
      .then(res => res.json())
      .then(orders => {
        const list = document.getElementById('mapOrdersList');
        const visibleKeys = new Set();
        if (list) list.innerHTML = '';

        orders.forEach(order => {
          if (order.lat && order.lng) {
            const key = String(order.id);
            const pos = [order.lat, order.lng];
            visibleKeys.add(key);
            const safeId = Number(order.id) || 0;
            const safeName = escapeHtml(order.c_name || 'Customer');
            const safeStatus = escapeHtml(order.order_status || '');
            const safePayment = escapeHtml(order.payment_status || '');
            const badgeClass = order.order_status === 'Confirmed' ? 'warning' : 'info';

            if (!orderMarkers[key]) {
              orderMarkers[key] = L.marker(pos).addTo(map).bindPopup(`
                <b>Order #${1000 + (((Number(safeId || 0) * 7919) + 4173) % 9000)}</b><br>
                ${safeName}<br>
                Status: ${safeStatus}<br>
                <a href="order-details.php?id=${safeId}" class="btn btn-primary btn-sm mt-2">View</a>
              `);
            } else {
              orderMarkers[key].setLatLng(pos);
              orderMarkers[key].setPopupContent(`
                <b>Order #${1000 + (((Number(safeId || 0) * 7919) + 4173) % 9000)}</b><br>
                ${safeName}<br>
                Status: ${safeStatus}<br>
                <a href="order-details.php?id=${safeId}" class="btn btn-primary btn-sm mt-2">View</a>
              `);
            }

            if (list) list.innerHTML += `
              <div class="order-item p-2 border-bottom small">
                <div>#${safeId} <span class="float-end badge bg-${badgeClass}">${safeStatus}</span></div>
                <div>${safeName}</div>
                <small>${safePayment}</small>
              </div>
            `;
          }
        });

        Object.keys(orderMarkers).forEach((key) => {
          if (!visibleKeys.has(key)) {
            map.removeLayer(orderMarkers[key]);
            delete orderMarkers[key];
          }
        });
      });
  }

  setInterval(loadOrders, 15000);
  loadOrders();

  function setDutyToggleState(online) {
    if (!dutyToggle || dutyToggle.checked === online) return;
    dutyToggle.checked = online;
    dutyToggle.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function pushLocation(coords, shouldCenter = false) {
    const newPos = [coords.latitude, coords.longitude];
    riderMarker.setLatLng(newPos);

    if (shouldCenter || !hasCenteredOnLiveLocation) {
      map.setView(newPos, 16);
      hasCenteredOnLiveLocation = true;
    }

    const stamp = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    setStatus(`Live location updated at ${stamp}.`, 'live');

    fetch('live-location.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': (window.csrfToken || '') },
      body: JSON.stringify({ lat: coords.latitude, lng: coords.longitude })
    }).catch(() => {
      setStatus('Map updated, but server sync failed. Trying again...', 'warn');
    });
  }

  function stopWatching() {
    if (watcherId !== null && navigator.geolocation) {
      navigator.geolocation.clearWatch(watcherId);
      watcherId = null;
    }
  }

  function handleLocationError(error, fromToggle = false) {
    let message = 'Unable to fetch live location right now.';
    if (error && error.code === 1) {
      message = 'Location permission denied. Browser se location allow karo.';
    } else if (error && error.code === 2) {
      message = 'Location unavailable. GPS ya network check karo.';
    } else if (error && error.code === 3) {
      message = 'Location request timed out. Dobara try karo.';
    }

    setStatus(message, 'error');

    if (fromToggle && error && error.code === 1) {
      setDutyToggleState(false);
    }
  }

  function requestCurrentLocation(shouldCenter = true, fromToggle = false) {
    if (!navigator.geolocation) {
      setStatus('Browser geolocation support available nahi hai.', 'error');
      return;
    }
    if (!isOnline()) {
      setStatus('Turn on Online to start live location.');
      return;
    }

    setStatus('Fetching your live location...', 'warn');
    navigator.geolocation.getCurrentPosition(
      (pos) => pushLocation(pos.coords, shouldCenter),
      (error) => handleLocationError(error, fromToggle),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  }

  function startWatching() {
    if (!navigator.geolocation) {
      setStatus('Browser geolocation support available nahi hai.', 'error');
      return;
    }
    if (!isOnline()) return;

    stopWatching();
    requestCurrentLocation(true, true);

    watcherId = navigator.geolocation.watchPosition(
      (pos) => {
        if (!isOnline()) return;
        pushLocation(pos.coords, false);
      },
      (error) => handleLocationError(error, false),
      {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 5000
      }
    );
  }

  function syncMapWithDuty() {
    setVisible();
    if (isOnline()) {
      setTimeout(() => map.invalidateSize(true), 60);
      startWatching();
    } else {
      stopWatching();
      hasCenteredOnLiveLocation = false;
    }
  }

  if (dutyToggle) {
    dutyToggle.addEventListener('change', syncMapWithDuty);
  }

  document.addEventListener('delivery-duty-updated', syncMapWithDuty);
  mapLocateBtn?.addEventListener('click', () => requestCurrentLocation(true, false));

  if (isOnline()) {
    startWatching();
  } else {
    setStatus('Turn on Online to start live location.');
  }
</script>

<?php include(__DIR__ . '/includes/footer.php'); ?>
