<?php
require_once(__DIR__ . '/includes/db-connect.php');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

$delivery_page_title = 'Dashboard - Rider Panel';

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$csrf_token = function_exists('qb_csrf_token') ? qb_csrf_token() : (string)($_SESSION['csrf_token'] ?? '');
$today = date('Y-m-d');
$greeting = date('H') < 12 ? 'Morning' : (date('H') < 17 ? 'Afternoon' : 'Evening');
$rider_name = trim((string)($_SESSION['user_name'] ?? 'Rider'));
$rider_first_name = strtok($rider_name, ' ') ?: 'Rider';
$rider_duty_status = 'Offline';
if ($rider_id > 0) {
    $status_q = mysqli_query($conn, "SELECT is_online FROM users WHERE id={$rider_id} AND role='delivery' LIMIT 1");
    if ($status_q) {
        $status_row = mysqli_fetch_assoc($status_q);
        $rider_duty_status = (($status_row['is_online'] ?? 'No') === 'Yes') ? 'Online' : 'Offline';
    }
}

// Ensure dashboard scripts load before realtime.js (included in footer.php)
$delivery_footer_before_realtime =
    '<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>' .
    '<script>window.riderId=' . (int)$rider_id . ';window.deliveryPage="dashboard";</script>';

$delivery_head_extra = <<<'HTML'
<style>
    .dashboard-shell {
        max-width: 1420px;
        margin: 0 auto;
    }

    .dashboard-hero {
        position: relative;
        overflow: hidden;
        margin-bottom: 1.5rem;
        padding: 1.75rem;
        border-radius: 28px;
        background:
            radial-gradient(circle at top left, rgba(255,255,255,0.16), transparent 34%),
            linear-gradient(135deg, #0f172a 0%, #1d3557 40%, #0f766e 100%);
        color: #fff;
        box-shadow: 0 22px 52px rgba(15, 23, 42, 0.22);
    }

    .dashboard-hero::after {
        content: '';
        position: absolute;
        right: -80px;
        bottom: -140px;
        width: 280px;
        height: 280px;
        border-radius: 50%;
        background: rgba(255,255,255,0.08);
    }

    .hero-grid {
        position: relative;
        z-index: 1;
        display: grid;
        grid-template-columns: minmax(0, 1.5fr) minmax(320px, 0.9fr);
        gap: 1.25rem;
        align-items: center;
    }

    .hero-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.55rem;
        padding: 0.42rem 0.82rem;
        border-radius: 999px;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.16);
        font-size: 0.82rem;
        letter-spacing: 0.05em;
        text-transform: uppercase;
    }

    .dashboard-hero h1 {
        margin: 1rem 0 0.65rem;
        font-size: clamp(1.9rem, 3vw, 2.8rem);
        font-weight: 800;
        line-height: 1.08;
    }

    .dashboard-hero p {
        margin: 0;
        max-width: 640px;
        color: rgba(255,255,255,0.78);
        font-size: 1rem;
    }

    .hero-actions {
        display: flex;
        gap: 0.85rem;
        flex-wrap: wrap;
        margin-top: 1.35rem;
    }

    .hero-actions .btn {
        border-radius: 14px;
        padding: 0.82rem 1rem;
        font-weight: 700;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.14);
    }

    .hero-side {
        position: relative;
        z-index: 1;
        display: grid;
        gap: 0.9rem;
    }

    .hero-panel {
        padding: 1.1rem 1.15rem;
        border-radius: 22px;
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.16);
        backdrop-filter: blur(12px);
    }

    .hero-panel-label {
        margin-bottom: 0.45rem;
        font-size: 0.78rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: rgba(255,255,255,0.66);
    }

    .hero-panel-value {
        font-size: 1.75rem;
        font-weight: 800;
        line-height: 1;
    }

    .hero-panel-note {
        margin-top: 0.45rem;
        color: rgba(255,255,255,0.72);
        font-size: 0.9rem;
    }

    .dashboard-stat-row {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 1rem;
        margin-bottom: 1.25rem;
    }

    .dashboard-stat-card {
        position: relative;
        overflow: hidden;
        padding: 1.2rem;
        border-radius: 22px;
        background: rgba(255,255,255,0.95);
        border: 1px solid rgba(15,23,42,0.08);
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.09);
    }

    [data-theme='dark'] .dashboard-stat-card {
        background: rgba(15,23,42,0.72);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 18px 40px rgba(0, 0, 0, 0.3);
    }

    .dashboard-stat-card::before {
        content: '';
        position: absolute;
        inset: 0 auto auto 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(90deg, #f97316, #0f766e);
    }

    .stat-topline {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.8rem;
        margin-bottom: 1rem;
    }

    .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
        color: #fff;
    }

    .stat-icon.orders { background: linear-gradient(135deg, #2563eb, #1d4ed8); }
    .stat-icon.done { background: linear-gradient(135deg, #059669, #0f766e); }
    .stat-icon.cash { background: linear-gradient(135deg, #ea580c, #f59e0b); }

    .stat-chip {
        padding: 0.38rem 0.7rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        color: #475569;
        font-size: 0.72rem;
        font-weight: 700;
    }

    [data-theme='dark'] .stat-chip {
        background: rgba(255,255,255,0.08);
        color: rgba(255,255,255,0.76);
    }

    .dashboard-stat-card h3 {
        margin: 0;
        font-size: 2rem;
        font-weight: 800;
        color: var(--text-color);
    }

    .dashboard-stat-card p {
        margin: 0.35rem 0 0;
        color: var(--muted);
        font-size: 0.92rem;
    }

    .dashboard-grid.dashboard-grid-pro {
        grid-template-columns: minmax(0, 1fr) 340px;
        gap: 1.5rem;
        padding: 0;
        max-width: none;
    }

    .section-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        margin-bottom: 1rem;
    }

    .section-title {
        display: flex;
        align-items: center;
        gap: 0.85rem;
    }

    .section-title-badge {
        width: 46px;
        height: 46px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(37,99,235,0.14), rgba(15,118,110,0.18));
        color: #0f766e;
        font-size: 1.05rem;
    }

    .section-title h5,
    .section-title h6 {
        margin: 0;
        font-weight: 800;
    }

    .section-title p {
        margin: 0.2rem 0 0;
        color: var(--muted);
        font-size: 0.9rem;
    }

    .glass-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.45rem;
        padding: 0.5rem 0.78rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.04);
        border: 1px solid rgba(15,23,42,0.08);
        color: #475569;
        font-size: 0.8rem;
        font-weight: 700;
    }

    [data-theme='dark'] .glass-pill {
        background: rgba(255,255,255,0.06);
        border-color: rgba(255,255,255,0.1);
        color: rgba(255,255,255,0.76);
    }

    .map-card .btn-location {
        border-radius: 14px;
        padding: 0.8rem 1rem;
        box-shadow: 0 14px 30px rgba(66, 133, 244, 0.24);
    }

    .performance-strip {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 1rem;
        margin-bottom: 1.25rem;
    }

    .performance-card {
        padding: 1rem 1.1rem;
        border-radius: 20px;
        background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(248,250,252,0.94));
        border: 1px solid rgba(15,23,42,0.08);
        box-shadow: 0 16px 32px rgba(15, 23, 42, 0.08);
    }

    [data-theme='dark'] .performance-card {
        background: linear-gradient(180deg, rgba(15,23,42,0.82), rgba(15,23,42,0.68));
        border-color: rgba(255,255,255,0.1);
    }

    .performance-label {
        color: var(--muted);
        font-size: 0.76rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }

    .performance-value {
        margin-top: 0.35rem;
        font-size: 1.45rem;
        font-weight: 800;
        color: var(--text-color);
    }

    .performance-note {
        margin-top: 0.25rem;
        font-size: 0.86rem;
        color: var(--muted);
    }

    .ops-banner {
        display: grid;
        grid-template-columns: minmax(0, 1.1fr) minmax(220px, 0.9fr);
        gap: 1rem;
        margin-bottom: 1.25rem;
    }

    .ops-banner-card {
        padding: 1rem 1.1rem;
        border-radius: 20px;
        background: linear-gradient(135deg, rgba(14,165,233,0.10), rgba(249,115,22,0.10));
        border: 1px solid rgba(14,165,233,0.14);
        box-shadow: 0 14px 30px rgba(15, 23, 42, 0.06);
    }

    [data-theme='dark'] .ops-banner-card {
        background: linear-gradient(135deg, rgba(14,165,233,0.16), rgba(249,115,22,0.10));
        border-color: rgba(255,255,255,0.09);
    }

    .ops-banner-title {
        font-size: 1rem;
        font-weight: 800;
        color: var(--text-color);
    }

    .ops-banner-copy {
        margin-top: 0.35rem;
        color: var(--muted);
        font-size: 0.9rem;
    }

    .orders-section-title {
        margin: 0 0 1rem;
        font-size: 1rem;
        font-weight: 800;
        color: var(--text-color);
    }

    .empty-state {
        padding: 2rem 1rem;
        border-radius: 18px;
        border: 1px dashed rgba(148,163,184,0.35);
        background: rgba(148,163,184,0.06);
        text-align: center;
        color: var(--muted);
    }

    [data-theme='dark'] .empty-state {
        background: rgba(255,255,255,0.04);
        border-color: rgba(255,255,255,0.12);
    }

    .order-progress {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 0.55rem;
        margin-top: 0.95rem;
    }

    .order-progress-step {
        height: 7px;
        border-radius: 999px;
        background: rgba(148,163,184,0.22);
        overflow: hidden;
        position: relative;
    }

    .order-progress-step.is-active {
        background: linear-gradient(90deg, #0ea5e9, #0f766e);
        box-shadow: 0 6px 16px rgba(14, 165, 233, 0.22);
    }

    .order-progress-labels {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 0.55rem;
        margin-top: 0.45rem;
    }

    .order-progress-labels span {
        font-size: 0.72rem;
        color: var(--muted);
        font-weight: 700;
    }

    .sidebar-stack {
        display: grid;
        gap: 1.25rem;
    }

    .sidebar-list {
        display: grid;
        gap: 0.85rem;
    }

    .sidebar-list-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.75rem;
        padding: 0.9rem 1rem;
        border-radius: 16px;
        background: rgba(15,23,42,0.04);
    }

    [data-theme='dark'] .sidebar-list-item {
        background: rgba(255,255,255,0.06);
    }

    .sidebar-list-item strong {
        display: block;
        font-size: 0.95rem;
    }

    .sidebar-list-item span {
        display: block;
        color: var(--muted);
        font-size: 0.82rem;
    }

    .sidebar-list-item i {
        width: 42px;
        height: 42px;
        border-radius: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(37,99,235,0.16), rgba(15,118,110,0.16));
        color: #1d4ed8;
    }

    .timeline {
        position: relative;
        display: grid;
        gap: 1rem;
    }

    .timeline::before {
        content: '';
        position: absolute;
        left: 18px;
        top: 10px;
        bottom: 10px;
        width: 2px;
        background: linear-gradient(180deg, rgba(14,165,233,0.35), rgba(15,118,110,0.35));
    }

    .timeline-item {
        position: relative;
        display: grid;
        grid-template-columns: 48px minmax(0, 1fr);
        gap: 0.9rem;
        align-items: start;
    }

    .timeline-dot {
        width: 38px;
        height: 38px;
        border-radius: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #0ea5e9, #0f766e);
        color: #fff;
        position: relative;
        z-index: 1;
        box-shadow: 0 10px 22px rgba(14, 165, 233, 0.22);
    }

    .timeline-card {
        padding: 0.95rem 1rem;
        border-radius: 16px;
        background: rgba(15,23,42,0.04);
    }

    [data-theme='dark'] .timeline-card {
        background: rgba(255,255,255,0.06);
    }

    .timeline-card strong {
        display: block;
        font-size: 0.95rem;
        color: var(--text-color);
    }

    .timeline-card span {
        display: block;
        margin-top: 0.2rem;
        font-size: 0.85rem;
        color: var(--muted);
    }

    .activity-list {
        display: grid;
        gap: 0.9rem;
    }

    .activity-item {
        display: flex;
        align-items: flex-start;
        gap: 0.85rem;
        padding: 0.95rem 1rem;
        border-radius: 16px;
        background: rgba(15,23,42,0.04);
    }

    [data-theme='dark'] .activity-item {
        background: rgba(255,255,255,0.06);
    }

    .activity-dot {
        width: 12px;
        height: 12px;
        margin-top: 0.3rem;
        border-radius: 999px;
        flex: 0 0 auto;
        background: linear-gradient(135deg, #f97316, #0f766e);
        box-shadow: 0 0 0 6px rgba(249,115,22,0.12);
    }

    .activity-item strong {
        display: block;
        font-size: 0.93rem;
        color: var(--text-color);
    }

    .activity-item span {
        display: block;
        margin-top: 0.2rem;
        font-size: 0.84rem;
        color: var(--muted);
    }

    .action-buttons.action-buttons-pro {
        display: grid;
        gap: 0.8rem;
        margin-top: 0;
    }

    .action-buttons-pro .btn {
        justify-content: flex-start;
        padding: 0.9rem 1rem;
        border-radius: 16px;
        font-weight: 700;
    }

    /* Zomato-inspired dashboard overrides */
    .dashboard-shell {
        max-width: 1480px;
        padding-bottom: 1.5rem;
    }

    .dashboard-hero {
        padding: 2rem;
        border-radius: 34px;
        background:
            radial-gradient(circle at top left, rgba(255,255,255,0.24), transparent 34%),
            radial-gradient(circle at 85% 15%, rgba(255,190,152,0.26), transparent 24%),
            linear-gradient(135deg, #cb1b45 0%, #e23744 46%, #ff7e8b 100%);
        box-shadow: 0 28px 60px rgba(226, 55, 68, 0.24);
    }

    .dashboard-hero::before {
        content: '';
        position: absolute;
        left: -84px;
        bottom: -84px;
        width: 230px;
        height: 230px;
        border-radius: 50%;
        background: rgba(255,255,255,0.12);
    }

    .dashboard-hero::after {
        right: -78px;
        bottom: -128px;
        width: 300px;
        height: 300px;
        background: rgba(255,255,255,0.12);
    }

    .hero-grid {
        grid-template-columns: minmax(0, 1.35fr) minmax(320px, 0.95fr);
        align-items: stretch;
    }

    .hero-eyebrow {
        padding: 0.55rem 0.95rem;
        background: rgba(255,255,255,0.14);
        border-color: rgba(255,255,255,0.2);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.08em;
    }

    .hero-heading-row {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1rem;
        margin-top: 1rem;
    }

    .dashboard-hero h1 {
        margin: 0;
        max-width: 720px;
        font-size: clamp(2rem, 3.2vw, 3.2rem);
        line-height: 1.06;
    }

    .dashboard-hero p {
        margin-top: 0.8rem;
        max-width: 640px;
        color: rgba(255,255,255,0.84);
    }

    .hero-duty {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.72rem 1rem;
        border-radius: 999px;
        border: 1px solid rgba(255,255,255,0.18);
        font-size: 0.82rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        white-space: nowrap;
        background: rgba(255,255,255,0.12);
    }

    .hero-duty::before {
        content: '';
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: currentColor;
        box-shadow: 0 0 0 6px rgba(255,255,255,0.08);
    }

    .hero-duty-live {
        color: #ecfdf5;
        background: rgba(15,118,110,0.26);
    }

    .hero-duty-idle {
        color: #fff7ed;
        background: rgba(127,29,29,0.24);
    }

    .hero-highlights {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 0.9rem;
        margin-top: 1.3rem;
    }

    .hero-highlight {
        padding: 1rem 1.05rem;
        border-radius: 22px;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.18);
        backdrop-filter: blur(14px);
    }

    .hero-highlight span,
    .delivery-stat span {
        display: block;
        font-size: 0.74rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }

    .hero-highlight span {
        color: rgba(255,255,255,0.74);
    }

    .hero-highlight strong {
        display: block;
        margin-top: 0.35rem;
        font-size: 1.45rem;
        font-weight: 800;
        color: #fff;
    }

    .hero-highlight small {
        display: block;
        margin-top: 0.28rem;
        color: rgba(255,255,255,0.8);
        font-size: 0.82rem;
        line-height: 1.45;
    }

    .hero-actions .btn {
        padding: 0.9rem 1.08rem;
        border-radius: 16px;
        border: none;
        box-shadow: 0 14px 32px rgba(136, 19, 55, 0.18);
    }

    .hero-actions .btn-light {
        color: #b91c1c !important;
    }

    .hero-actions .btn-outline-light {
        border: 1px solid rgba(255,255,255,0.34);
        background: rgba(255,255,255,0.08);
    }

    .hero-panel {
        padding: 1.2rem 1.25rem;
        border-radius: 26px;
        background: rgba(255,255,255,0.12);
        border-color: rgba(255,255,255,0.18);
        backdrop-filter: blur(16px);
    }

    .hero-panel-label {
        font-size: 0.74rem;
        font-weight: 700;
    }

    .hero-panel-value {
        font-size: 2rem;
    }

    .hero-panel-note {
        color: rgba(255,255,255,0.8);
    }

    .hero-panel-list {
        display: grid;
        gap: 0.85rem;
        margin-top: 1rem;
    }

    .hero-panel-list-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: 0.92rem 1rem;
        border-radius: 18px;
        background: rgba(129,24,50,0.22);
        border: 1px solid rgba(255,255,255,0.12);
    }

    .hero-panel-list-item span {
        display: block;
        font-size: 0.8rem;
        color: rgba(255,255,255,0.7);
    }

    .hero-panel-list-item strong {
        display: block;
        margin-top: 0.18rem;
        font-size: 1rem;
        color: #fff;
    }

    .hero-panel-list-item b {
        font-size: 1.2rem;
        font-weight: 800;
        color: #fff;
    }

    .dashboard-stat-card,
    .performance-card,
    .ops-banner-card,
    .queue-card,
    .dispatch-map-card,
    .activity-card,
    .sidebar .order-card {
        border-radius: 26px;
    }

    .dashboard-stat-card {
        background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,245,246,0.98));
        border-color: rgba(226,55,68,0.08);
        box-shadow: 0 18px 44px rgba(15,23,42,0.07);
    }

    .dashboard-stat-card::before {
        height: 5px;
        background: linear-gradient(90deg, #e23744, #ff7e8b);
    }

    .stat-icon.orders { background: linear-gradient(135deg, #e23744, #fb7185); }
    .stat-icon.done { background: linear-gradient(135deg, #0f766e, #14b8a6); }
    .stat-icon.cash { background: linear-gradient(135deg, #ea580c, #fb923c); }

    .stat-chip,
    .glass-pill,
    .queue-count {
        border-radius: 999px;
        font-weight: 700;
    }

    .stat-chip,
    .glass-pill {
        background: rgba(226,55,68,0.08);
        color: #9f1239;
        border-color: rgba(226,55,68,0.12);
    }

    .performance-card {
        border-radius: 24px;
        background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,248,248,0.98));
        border-color: rgba(226,55,68,0.08);
        box-shadow: 0 16px 32px rgba(15,23,42,0.06);
    }

    .ops-banner-card {
        border-radius: 24px;
        background: linear-gradient(135deg, rgba(255,237,238,0.92), rgba(255,247,237,0.92));
        border-color: rgba(226,55,68,0.12);
        box-shadow: 0 14px 30px rgba(15,23,42,0.04);
    }

    .dashboard-grid.dashboard-grid-pro {
        gap: 1.35rem;
    }

    .main-stack {
        display: grid;
        gap: 1.2rem;
    }

    .map-card .btn-location {
        border-radius: 16px;
        background: linear-gradient(135deg, #e23744, #fb7185);
        border: none;
        box-shadow: 0 16px 32px rgba(226,55,68,0.2);
    }

    .queue-card .badge.bg-success {
        background: rgba(16,185,129,0.16) !important;
        color: #047857 !important;
        border: 1px solid rgba(16,185,129,0.22);
    }

    .queue-columns {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 1rem;
    }

    .queue-column-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        margin-bottom: 1rem;
    }

    .queue-count {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 40px;
        height: 40px;
        padding: 0 0.8rem;
        background: rgba(226,55,68,0.08);
        color: #be123c;
    }

    .orders-section-title {
        margin: 0;
    }

    .empty-state {
        border-radius: 22px;
        border-color: rgba(226,55,68,0.2);
        background: rgba(255,245,246,0.9);
    }

    .order-progress-step.is-active {
        background: linear-gradient(90deg, #e23744, #fb7185);
        box-shadow: 0 6px 16px rgba(226,55,68,0.2);
    }

    .sidebar-list-item,
    .timeline-card,
    .activity-item,
    .delivery-stat {
        background: rgba(226,55,68,0.05);
    }

    .sidebar-list-item i {
        background: linear-gradient(135deg, rgba(226,55,68,0.16), rgba(251,146,60,0.18));
        color: #e23744;
    }

    .timeline::before {
        background: linear-gradient(180deg, rgba(226,55,68,0.34), rgba(251,146,60,0.28));
    }

    .timeline-dot {
        background: linear-gradient(135deg, #e23744, #fb7185);
        box-shadow: 0 10px 22px rgba(226,55,68,0.22);
    }

    .activity-dot {
        background: linear-gradient(135deg, #e23744, #fb7185);
        box-shadow: 0 0 0 6px rgba(226,55,68,0.12);
    }

    .chart-note {
        margin-top: 0.85rem;
        color: var(--muted);
        font-size: 0.84rem;
    }

    .delivery-order-tile {
        position: relative;
        overflow: hidden;
        padding: 1.1rem;
        border-radius: 24px;
        background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(255,248,248,0.96));
        border: 1px solid rgba(226,55,68,0.1);
        box-shadow: 0 16px 36px rgba(15,23,42,0.06);
    }

    .delivery-order-tile::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 4px;
        background: linear-gradient(180deg, #e23744, #fb7185);
    }

    .delivery-order-tile[data-state='confirmed']::before {
        background: linear-gradient(180deg, #f97316, #fb7185);
    }

    .delivery-order-topbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        margin-bottom: 0.9rem;
    }

    .delivery-order-code {
        font-size: 0.78rem;
        font-weight: 800;
        color: #9f1239;
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }

    .delivery-order-customer {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1rem;
    }

    .delivery-order-title {
        font-size: 1.02rem;
        line-height: 1.3;
    }

    .delivery-order-sub {
        margin-top: 0.32rem;
        font-size: 0.85rem;
        line-height: 1.45;
    }

    .delivery-order-total {
        flex: 0 0 auto;
        padding: 0.62rem 0.85rem;
        border-radius: 18px;
        background: rgba(226,55,68,0.08);
        color: #be123c;
        font-size: 1.05rem;
        font-weight: 800;
        line-height: 1;
    }

    .delivery-order-stats {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.75rem;
        margin-top: 0.95rem;
    }

    .delivery-stat {
        padding: 0.8rem 0.9rem;
        border-radius: 18px;
        border: 1px solid rgba(226,55,68,0.08);
    }

    .delivery-stat strong {
        display: block;
        margin-top: 0.3rem;
        font-size: 0.95rem;
        color: var(--text-color);
    }

    .delivery-chip {
        font-size: 0.72rem;
        font-weight: 800;
        padding: 0.48rem 0.8rem;
    }

    .chip-new {
        background: rgba(249,115,22,0.12);
        color: #c2410c;
        border-color: rgba(249,115,22,0.2);
    }

    .chip-way {
        background: rgba(226,55,68,0.1);
        color: #be123c;
        border-color: rgba(226,55,68,0.16);
    }

    .delivery-actions .btn {
        border-radius: 16px;
        min-width: 126px;
        border: none;
    }

    .delivery-actions-compact .btn:not(.delivery-detail-btn) {
        min-width: 138px;
    }

    .delivery-icon-btn {
        min-width: 138px !important;
        height: 44px;
        box-shadow: 0 14px 30px rgba(15,23,42,0.12);
    }

    .delivery-detail-btn {
        min-width: 132px !important;
        background: linear-gradient(135deg, #e23744, #fb7185) !important;
        box-shadow: 0 14px 28px rgba(226,55,68,0.2);
    }

    @media (max-width: 1100px) {
        .hero-grid,
        .dashboard-grid.dashboard-grid-pro,
        .dashboard-stat-row,
        .performance-strip,
        .ops-banner,
        .queue-columns,
        .hero-highlights {
            grid-template-columns: 1fr;
        }

        .sidebar {
            position: static;
        }
    }

    @media (max-width: 768px) {
        .dashboard-hero {
            padding: 1.25rem;
            border-radius: 24px;
        }

        .hero-actions,
        .section-head,
        .hero-heading-row,
        .queue-column-head,
        .delivery-order-customer {
            flex-direction: column;
            align-items: stretch;
        }

        .map-card .btn-location {
            position: static !important;
            margin-top: 1rem;
        }

        .delivery-order-stats {
            grid-template-columns: 1fr;
        }
    }
</style>
HTML;

// Quick stats
$active_orders = 0;
$today_deliveries = 0;
$confirmed_orders = 0;
$on_way_orders = 0;
if ($rider_id > 0) {
    $q1 = mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE rider_id={$rider_id} AND order_status IN ('Confirmed','On the Way')");
    $active_orders = (int)(mysqli_fetch_assoc($q1)['count'] ?? 0);

    $q2 = mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE rider_id={$rider_id} AND order_status='Delivered' AND DATE(order_date)='{$today}'");
    $today_deliveries = (int)(mysqli_fetch_assoc($q2)['count'] ?? 0);

    $q3 = mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE rider_id={$rider_id} AND order_status='Confirmed'");
    $confirmed_orders = (int)(mysqli_fetch_assoc($q3)['count'] ?? 0);

    $q4 = mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE rider_id={$rider_id} AND order_status='On the Way'");
    $on_way_orders = (int)(mysqli_fetch_assoc($q4)['count'] ?? 0);
}
$today_earnings = $today_deliveries * 40; // Rs 40 per delivery
$completion_rate = $active_orders + $today_deliveries > 0 ? (int)round(($today_deliveries / ($active_orders + $today_deliveries)) * 100) : 100;
$response_time = $confirmed_orders > 0 ? '2-4 min' : 'Instant';
$service_status = $on_way_orders > 0 ? 'On Route' : ($confirmed_orders > 0 ? 'Ready to Start' : 'Available');
$ops_message = $confirmed_orders > 0
    ? $confirmed_orders . ' new order' . ($confirmed_orders > 1 ? 's are' : ' is') . ' waiting for action.'
    : 'No new queue pressure right now. You are ready for the next assignment.';
$ops_focus = $on_way_orders > 0
    ? $on_way_orders . ' deliveries are currently moving toward customers.'
    : 'No orders are in transit at the moment.';
$pickup_focus = $confirmed_orders > 0
    ? $confirmed_orders . ' pickup' . ($confirmed_orders > 1 ? 's are' : ' is') . ' ready to start from your queue.'
    : 'No fresh pickup is waiting right now.';

$recent_activity = [];
if ($rider_id > 0) {
    $activity_q = mysqli_query(
        $conn,
        "SELECT o.id, o.order_status, o.order_date, u.name AS c_name
         FROM orders o
         JOIN users u ON o.user_id = u.id
         WHERE o.rider_id={$rider_id}
         ORDER BY o.id DESC
         LIMIT 4"
    );

    if ($activity_q) {
        while ($activity_row = mysqli_fetch_assoc($activity_q)) {
            $recent_activity[] = $activity_row;
        }
    }
}

include(__DIR__ . '/includes/header.php');
?>

<div class="dashboard-shell">
    <div class="dashboard-hero">
        <div class="hero-grid">
            <div>
                <span class="hero-eyebrow"><i class="fas fa-bolt"></i> Zomato-Style Dispatch View</span>
                <div class="hero-heading-row">
                    <h1>Good <?= htmlspecialchars($greeting, ENT_QUOTES, 'UTF-8'); ?>, <?= htmlspecialchars($rider_first_name, ENT_QUOTES, 'UTF-8'); ?></h1>
                    <span class="hero-duty <?= $rider_duty_status === 'Online' ? 'hero-duty-live' : 'hero-duty-idle'; ?>">
                        <?= htmlspecialchars($rider_duty_status, ENT_QUOTES, 'UTF-8'); ?>
                    </span>
                </div>
                <p>See pickups, live drops, earnings, and route movement from one fast dispatch screen built for delivery flow.</p>
                <div class="hero-highlights">
                    <div class="hero-highlight">
                        <span>Pickup Pending</span>
                        <strong><?= (int)$confirmed_orders ?></strong>
                        <small><?= htmlspecialchars($pickup_focus, ENT_QUOTES, 'UTF-8'); ?></small>
                    </div>
                    <div class="hero-highlight">
                        <span>On Route</span>
                        <strong><?= (int)$on_way_orders ?></strong>
                        <small><?= htmlspecialchars($ops_focus, ENT_QUOTES, 'UTF-8'); ?></small>
                    </div>
                    <div class="hero-highlight">
                        <span>Completion</span>
                        <strong><?= (int)$completion_rate; ?>%</strong>
                        <small>Finished tasks versus your active queue today.</small>
                    </div>
                </div>
                <div class="hero-actions">
                    <a href="order-history.php" class="btn btn-light text-dark">
                        <i class="fas fa-list-check"></i> Review Orders
                    </a>
                    <a href="map-view.php" class="btn btn-outline-light">
                        <i class="fas fa-map-location-dot"></i> Open Full Map
                    </a>
                </div>
            </div>

            <div class="hero-side">
                <div class="hero-panel">
                    <div class="hero-panel-label">Today's Progress</div>
                    <div class="hero-panel-value" id="completedTodayHero"><?= (int)$today_deliveries ?> Deliveries</div>
                    <div class="hero-panel-note">Keep your status online to receive new pings and track assigned customer points in realtime.</div>
                    <div class="hero-panel-list">
                        <div class="hero-panel-list-item">
                            <div>
                                <span>Active Queue</span>
                                <strong><?= (int)$active_orders ?> live tasks</strong>
                            </div>
                            <b id="activeQueueHero"><?= (int)$active_orders ?></b>
                        </div>
                        <div class="hero-panel-list-item">
                            <div>
                                <span>Service Window</span>
                                <strong><?= htmlspecialchars($response_time, ENT_QUOTES, 'UTF-8'); ?></strong>
                            </div>
                            <b><?= (int)$confirmed_orders ?></b>
                        </div>
                    </div>
                </div>

                <div class="hero-panel">
                    <div class="d-flex justify-content-between align-items-center gap-3">
                        <div>
                            <div class="hero-panel-label">Current Earnings</div>
                            <div class="hero-panel-value" id="todayEarningsHero">&#8377;<?= (int)$today_earnings ?></div>
                        </div>
                        <button class="theme-toggle" title="Toggle Theme" type="button">
                            <i class="fas fa-moon"></i>
                        </button>
                    </div>
                    <div class="hero-panel-note"><?= date('d M Y'); ?> &middot; Live dashboard synced with your delivery queue.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="dashboard-stat-row">
        <div class="dashboard-stat-card">
            <div class="stat-topline">
                <span class="stat-icon orders"><i class="fas fa-motorcycle"></i></span>
                <span class="stat-chip">Active Queue</span>
            </div>
            <h3 id="activeQueueStat"><?= (int)$active_orders ?></h3>
            <p>Orders currently in progress or waiting for your delivery action.</p>
        </div>

        <div class="dashboard-stat-card">
            <div class="stat-topline">
                <span class="stat-icon done"><i class="fas fa-circle-check"></i></span>
                <span class="stat-chip">Completed Today</span>
            </div>
            <h3 id="completedTodayStat"><?= (int)$today_deliveries ?></h3>
            <p>Successful drop-offs completed today from your assigned route.</p>
        </div>

        <div class="dashboard-stat-card">
            <div class="stat-topline">
                <span class="stat-icon cash"><i class="fas fa-wallet"></i></span>
                <span class="stat-chip">Today's Earnings</span>
            </div>
            <h3 id="todayEarningsStat">&#8377;<?= (int)$today_earnings ?></h3>
            <p>Estimated payout based on the deliveries you have completed today.</p>
        </div>
    </div>

    <div class="performance-strip">
        <div class="performance-card">
            <div class="performance-label">Completion Rate</div>
            <div class="performance-value"><?= (int)$completion_rate; ?>%</div>
            <div class="performance-note">Based on completed versus open delivery tasks.</div>
        </div>
        <div class="performance-card">
            <div class="performance-label">Response Window</div>
            <div class="performance-value"><?= htmlspecialchars($response_time, ENT_QUOTES, 'UTF-8'); ?></div>
            <div class="performance-note">Current average start pace for assigned orders.</div>
        </div>
        <div class="performance-card">
            <div class="performance-label">Service Status</div>
            <div class="performance-value"><?= htmlspecialchars($service_status, ENT_QUOTES, 'UTF-8'); ?></div>
            <div class="performance-note">Live rider state based on your queue movement.</div>
        </div>
        <div class="performance-card">
            <div class="performance-label">In Dispatch</div>
            <div class="performance-value"><?= (int)$on_way_orders; ?></div>
            <div class="performance-note">Orders currently moving toward customer delivery.</div>
        </div>
    </div>

    <div class="ops-banner">
        <div class="ops-banner-card">
            <div class="ops-banner-title">Operations Pulse</div>
            <div class="ops-banner-copy"><?= htmlspecialchars($ops_message, ENT_QUOTES, 'UTF-8'); ?></div>
        </div>
        <div class="ops-banner-card">
            <div class="ops-banner-title">Transit Focus</div>
            <div class="ops-banner-copy"><?= htmlspecialchars($ops_focus, ENT_QUOTES, 'UTF-8'); ?></div>
        </div>
    </div>

    <div class="dashboard-grid dashboard-grid-pro">
        <div class="main-stack">
            <div class="order-card position-relative map-card dispatch-map-card">
                <div class="section-head">
                    <div class="section-title">
                        <span class="section-title-badge"><i class="fas fa-map-marked-alt"></i></span>
                        <div>
                            <h5>Live Orders Map</h5>
                            <p>View your current position and assigned delivery points in real time.</p>
                        </div>
                    </div>
                    <span class="glass-pill"><i class="fas fa-bolt"></i> Realtime Tracking</span>
                </div>
            <div class="live-map-wrap">
                <div id="liveMap"></div>
                <div id="liveMapPlaceholder" class="live-map-placeholder">
                    <div class="text-center px-3">
                        <div class="h5 fw-bold mb-2"><i class="fas fa-signal me-2 text-warning"></i>Go Online to view map</div>
                        <div class="text-muted small">Turn on <b>Online</b> to share your live location and see active delivery points.</div>
                    </div>
                </div>
            </div>
            <button id="currentLocationBtn" class="btn btn-location position-absolute" style="bottom: 1rem; left: 1rem;" type="button">
                <i class="fas fa-location-arrow"></i> My Location
            </button>
            </div>

            <div class="order-card live-order queue-card">
                <div class="section-head">
                    <div class="section-title">
                        <span class="section-title-badge"><i class="fas fa-boxes-stacked"></i></span>
                        <div>
                            <h5>Delivery Queue</h5>
                            <p>Handle new pickups and in-transit drops from one dispatch board.</p>
                        </div>
                    </div>
                    <div class="d-flex gap-2 flex-wrap">
                        <span class="glass-pill">Active Orders: <span id="activeOrdersCount"><?= (int)$active_orders ?></span></span>
                        <span class="badge bg-success">Live <span class="live-dot"></span></span>
                    </div>
                </div>

                <div class="queue-columns">
                    <div class="queue-column">
                        <div class="queue-column-head">
                            <h5 class="orders-section-title">New Assigned Orders</h5>
                            <span class="queue-count"><?= (int)$confirmed_orders ?></span>
                        </div>

                        <div id="newOrdersContainer">
                            <?php
                            $new_orders_q = mysqli_query(
                                $conn,
                                "SELECT o.*, u.name as c_name, u.phone as c_phone
                                 FROM orders o JOIN users u ON o.user_id = u.id
                                 WHERE o.rider_id={$rider_id} AND o.order_status = 'Confirmed'
                                 ORDER BY o.id DESC"
                            );

                            if ($new_orders_q && mysqli_num_rows($new_orders_q) > 0):
                                while ($order = mysqli_fetch_assoc($new_orders_q)):
                                    $is_cod = (($order['payment_mode'] ?? '') === 'COD');
                            ?>
                                <div class="delivery-order-tile mb-3" data-state="confirmed">
                                    <div class="delivery-order-topbar">
                                        <span class="delivery-order-code">Order #<?= qb_order_display_id((int)$order['id']) ?></span>
                                        <span class="delivery-chip chip-new">Pickup Pending</span>
                                    </div>

                                    <div class="delivery-order-customer">
                                        <div>
                                            <div class="delivery-order-title"><?= htmlspecialchars((string)$order['c_name']); ?></div>
                                            <div class="delivery-order-sub">
                                                <i class="fas fa-location-dot me-1"></i>
                                                <?= htmlspecialchars(mb_strimwidth((string)$order['delivery_address'], 0, 78, '...')); ?>
                                            </div>
                                        </div>
                                        <div class="delivery-order-total">&#8377;<?= number_format((float)$order['total_amount'], 0); ?></div>
                                    </div>

                                    <div class="delivery-order-stats">
                                        <div class="delivery-stat">
                                            <span>Payment</span>
                                            <strong><?= $is_cod ? ((($order['payment_status'] ?? '') === 'Paid') ? 'Cash Paid' : 'COD Collection') : 'Paid Online'; ?></strong>
                                        </div>
                                        <div class="delivery-stat">
                                            <span>Next Action</span>
                                            <strong>Start pickup run</strong>
                                        </div>
                                    </div>

                                    <div class="order-progress" aria-hidden="true">
                                        <span class="order-progress-step is-active"></span>
                                        <span class="order-progress-step"></span>
                                        <span class="order-progress-step"></span>
                                    </div>
                                    <div class="order-progress-labels">
                                        <span>Assigned</span>
                                        <span>Pickup</span>
                                        <span>Delivered</span>
                                    </div>

                                    <div class="delivery-actions">
                                        <form method="POST" action="accept-order.php">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <i class="fas fa-play me-1"></i> Start Delivery
                                            </button>
                                        </form>
                                        <form method="POST" action="reject-order.php">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fas fa-xmark me-1"></i> Cancel
                                            </button>
                                        </form>
                                        <a href="order-details.php?id=<?= (int)$order['id'] ?>" class="btn btn-primary btn-sm delivery-detail-btn">
                                            <i class="fas fa-eye me-1"></i> View
                                        </a>
                                    </div>
                                </div>
                            <?php
                                endwhile;
                            else:
                            ?>
                                <div class="empty-state">No newly assigned orders right now.</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="queue-column">
                        <div class="queue-column-head">
                            <h5 class="orders-section-title">Active Deliveries</h5>
                            <span class="queue-count" id="activeDeliveriesCount"><?= (int)$on_way_orders ?></span>
                        </div>

                        <div id="ordersContainer">
                            <?php
                            $orders_q = mysqli_query(
                                $conn,
                                "SELECT o.*, u.name as c_name, u.phone as c_phone
                                 FROM orders o JOIN users u ON o.user_id = u.id
                                 WHERE o.rider_id={$rider_id} AND o.order_status='On the Way'
                                 ORDER BY o.id DESC LIMIT 5"
                            );

                            if ($orders_q && mysqli_num_rows($orders_q) > 0):
                                while ($order = mysqli_fetch_assoc($orders_q)):
                                    $is_cod = (($order['payment_mode'] ?? '') === 'COD');
                            ?>
                                <div class="delivery-order-tile mb-3" data-state="onway" data-order-id="<?= (int)$order['id'] ?>">
                                    <div class="delivery-order-topbar">
                                        <span class="delivery-order-code">Order #<?= qb_order_display_id((int)$order['id']) ?></span>
                                        <span class="delivery-chip chip-way">On Route</span>
                                    </div>

                                    <div class="delivery-order-customer">
                                        <div>
                                            <div class="delivery-order-title"><?= htmlspecialchars((string)$order['c_name']); ?></div>
                                            <div class="delivery-order-sub">
                                                <i class="fas fa-location-dot me-1"></i>
                                                <?= htmlspecialchars(mb_strimwidth((string)$order['delivery_address'], 0, 78, '...')); ?>
                                            </div>
                                        </div>
                                        <div class="delivery-order-total">&#8377;<?= number_format((float)$order['total_amount'], 0); ?></div>
                                    </div>

                                    <div class="delivery-order-stats">
                                        <div class="delivery-stat">
                                            <span>Payment</span>
                                            <strong><?= $is_cod ? ((($order['payment_status'] ?? '') === 'Paid') ? 'Cash Paid' : 'COD Collection') : 'Paid Online'; ?></strong>
                                        </div>
                                        <div class="delivery-stat">
                                            <span>Customer Contact</span>
                                            <strong>Call or WhatsApp</strong>
                                        </div>
                                    </div>

                                    <div class="order-progress" aria-hidden="true">
                                        <span class="order-progress-step is-active"></span>
                                        <span class="order-progress-step is-active"></span>
                                        <span class="order-progress-step"></span>
                                    </div>
                                    <div class="order-progress-labels">
                                        <span>Assigned</span>
                                        <span>On Route</span>
                                        <span>Delivered</span>
                                    </div>

                                    <div class="delivery-actions delivery-actions-compact">
                                        <a href="tel:<?= preg_replace('/[^0-9]/', '', (string)$order['c_phone']) ?>" class="btn btn-call delivery-icon-btn" title="Call">
                                            <i class="fas fa-phone"></i>
                                            <span>Call</span>
                                        </a>
                                        <a href="https://wa.me/91<?= preg_replace('/[^0-9]/', '', (string)$order['c_phone']) ?>" target="_blank" class="btn btn-whatsapp delivery-icon-btn" title="WhatsApp" rel="noreferrer">
                                            <i class="fab fa-whatsapp"></i>
                                            <span>WhatsApp</span>
                                        </a>
                                        <a href="order-details.php?id=<?= (int)$order['id'] ?>" class="btn btn-primary btn-sm delivery-detail-btn">
                                            <i class="fas fa-circle-info me-1"></i> Details
                                        </a>
                                    </div>
                                </div>
                            <?php
                                endwhile;
                            else:
                            ?>
                                <div class="empty-state">
                                    <i class="fas fa-truck fa-3x mb-3"></i>
                                    <p class="mb-0">No active orders. Ready for the next delivery!</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="order-card activity-card">
                <div class="section-title mb-3">
                    <span class="section-title-badge"><i class="fas fa-satellite-dish"></i></span>
                    <div>
                        <h6>Recent Delivery Activity</h6>
                        <p>Latest movement from your assigned rider stream.</p>
                    </div>
                </div>
                <div class="activity-list">
                    <?php if (!empty($recent_activity)): ?>
                        <?php foreach ($recent_activity as $activity): ?>
                            <div class="activity-item">
                                <span class="activity-dot"></span>
                                <div>
                                    <strong>Order #<?= qb_order_display_id((int)$activity['id']); ?> for <?= htmlspecialchars((string)$activity['c_name'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                    <span><?= htmlspecialchars((string)$activity['order_status'], ENT_QUOTES, 'UTF-8'); ?> &middot; <?= date('d M, h:i A', strtotime((string)$activity['order_date'])); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="empty-state">No rider activity recorded yet.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="sidebar">
            <div class="sidebar-stack">
                <div class="order-card">
                    <div class="section-title mb-3">
                        <span class="section-title-badge"><i class="fas fa-chart-line"></i></span>
                        <div>
                            <h6>Shift Earnings</h6>
                            <p>Quick visual of your earning trend through the day.</p>
                        </div>
                    </div>
                    <canvas id="earningsChart"></canvas>
                    <div class="chart-note">Forecast based on completed drops and current delivery pace.</div>
                </div>

                <div class="order-card">
                    <div class="section-title mb-3">
                        <span class="section-title-badge"><i class="fas fa-bolt"></i></span>
                        <div>
                            <h6>Shift Snapshot</h6>
                            <p>Short summary of your live delivery performance.</p>
                        </div>
                    </div>
                    <div class="sidebar-list">
                        <div class="sidebar-list-item">
                            <div>
                                <strong class="today-earnings text-success">&#8377;<?= (int)$today_earnings ?></strong>
                                <span>Estimated earnings today</span>
                            </div>
                            <i class="fas fa-indian-rupee-sign"></i>
                        </div>
                        <div class="sidebar-list-item">
                            <div>
                                <strong class="today-deliveries"><?= (int)$today_deliveries ?> deliveries</strong>
                                <span>Completed successfully so far</span>
                            </div>
                            <i class="fas fa-circle-check"></i>
                        </div>
                        <div class="sidebar-list-item">
                            <div>
                                <strong id="sidebarActiveOrders"><?= (int)$active_orders ?> active orders</strong>
                                <span>Open tasks currently in your queue</span>
                            </div>
                            <i class="fas fa-motorcycle"></i>
                        </div>
                    </div>
                </div>

                <div class="order-card">
                    <div class="section-title mb-3">
                        <span class="section-title-badge"><i class="fas fa-route"></i></span>
                        <div>
                            <h6>Today's Workflow</h6>
                            <p>Quick operational flow for your current delivery shift.</p>
                        </div>
                    </div>
                    <div class="timeline">
                        <div class="timeline-item">
                            <span class="timeline-dot"><i class="fas fa-bell-concierge"></i></span>
                            <div class="timeline-card">
                                <strong id="freshAssignmentsStat"><?= (int)$confirmed_orders; ?> fresh assignments</strong>
                                <span>Orders waiting for pickup or delivery start.</span>
                            </div>
                        </div>
                        <div class="timeline-item">
                            <span class="timeline-dot"><i class="fas fa-motorcycle"></i></span>
                            <div class="timeline-card">
                                <strong id="ordersInTransitStat"><?= (int)$on_way_orders; ?> orders in transit</strong>
                                <span>Customers are currently waiting on these routes.</span>
                            </div>
                        </div>
                        <div class="timeline-item">
                            <span class="timeline-dot"><i class="fas fa-flag-checkered"></i></span>
                            <div class="timeline-card">
                                <strong id="deliveriesCompletedStat"><?= (int)$today_deliveries; ?> deliveries completed</strong>
                                <span>Finished tasks successfully marked for today.</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="order-card">
                    <div class="section-title mb-3">
                        <span class="section-title-badge"><i class="fas fa-compass"></i></span>
                        <div>
                            <h6>Quick Actions</h6>
                            <p>Open your most-used rider tools faster.</p>
                        </div>
                    </div>
                    <div class="action-buttons action-buttons-pro">
                        <a href="order-history.php" class="btn btn-outline-primary"><i class="fas fa-history"></i> Order History</a>
                        <a href="earnings.php" class="btn btn-outline-success"><i class="fas fa-chart-line"></i> Earnings</a>
                        <a href="my-profile.php" class="btn btn-outline-warning"><i class="fas fa-user-cog"></i> Profile</a>
                        <a href="map-view.php" class="btn btn-outline-info"><i class="fas fa-map"></i> Full Map</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include(__DIR__ . '/includes/footer.php'); ?>
