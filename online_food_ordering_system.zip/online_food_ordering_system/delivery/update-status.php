<?php
/**
 * Delivery Status & Earning Management
 * File: update-status.php
 */

include('includes/db-connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id']) && isset($_POST['new_status'])) {
    qb_require_csrf();
    
    $order_id = (int)($_POST['order_id'] ?? 0);
    $new_status = (string)($_POST['new_status'] ?? '');
    $rider_id = (int)($_SESSION['user_id'] ?? 0);

    $allowed = ['On the Way', 'Delivered'];
    if ($order_id <= 0 || $rider_id <= 0 || !in_array($new_status, $allowed, true)) {
        header("Location: dashboard.php?status=error&msg=Invalid request");
        exit();
    }

    // 1. Security Check: Kya ye order waqai is rider ko assigned hai?
    $verify_q = "SELECT id, order_status, payment_mode, payment_status FROM orders WHERE id = {$order_id} AND rider_id = {$rider_id} LIMIT 1";
    $verify_res = mysqli_query($conn, $verify_q);

    if (mysqli_num_rows($verify_res) > 0) {
        $cur = mysqli_fetch_assoc($verify_res);
        $current_status = (string)($cur['order_status'] ?? '');
        $payment_mode = (string)($cur['payment_mode'] ?? '');
        $payment_status = (string)($cur['payment_status'] ?? '');

        // Allowed transitions only
        $transition_ok = ($current_status === 'Confirmed' && $new_status === 'On the Way')
            || ($current_status === 'On the Way' && $new_status === 'Delivered');
        if (!$transition_ok) {
            header("Location: order-details.php?id={$order_id}&status=error&msg=Invalid transition");
            exit();
        }
        
        // 2. Transaction Start (Safety ke liye)
        mysqli_begin_transaction($conn);

        try {
            // A. Update Order Status
            $new_status_safe = mysqli_real_escape_string($conn, $new_status);
            $payment_update = ($current_status === 'On the Way' && $new_status === 'Delivered' && $payment_mode === 'COD' && $payment_status !== 'Paid')
                ? ", payment_status = 'Paid'"
                : "";
            $update_order = "UPDATE orders SET order_status = '{$new_status_safe}'{$payment_update} WHERE id = {$order_id} AND rider_id = {$rider_id}";
            if (!mysqli_query($conn, $update_order) || mysqli_affected_rows($conn) <= 0) {
                throw new Exception('Order update failed');
            }

            // B. Earning Logic: Agar status 'Delivered' ho gaya hai
            if ($new_status == 'Delivered') {
                $earning_amount = 40.00; // Aapka fixed commission per order

                // Update Rider's Wallet
                $update_wallet = "UPDATE users SET wallet_balance = wallet_balance + {$earning_amount} WHERE id = {$rider_id} AND role='delivery'";
                if (!mysqli_query($conn, $update_wallet)) {
                    throw new Exception('Wallet update failed');
                }

                // Add Transaction Record (Optional but recommended)
                $txn_remark = "Earning for Order #" . qb_order_display_id($order_id);
                $log_txn = "INSERT INTO wallet_transactions (user_id, amount, type, remarks) 
                            VALUES ('$rider_id', '$earning_amount', 'Credit', '$txn_remark')";
                // mysqli_query($conn, $log_txn); 
            }

            // Sab theek raha toh Save karein
            mysqli_commit($conn);
            
            // Redirect with Success
            header("Location: dashboard.php?status=success&msg=Order updated to $new_status");
            exit();

        } catch (Exception $e) {
            mysqli_rollback($conn);
            header("Location: dashboard.php?status=error&msg=Something went wrong");
            exit();
        }
        
    } else {
        // Unauthorized access attempt
        header("Location: dashboard.php?status=error&msg=Unauthorized Action");
        exit();
    }

} else {
    // Direct link access block
    header("Location: dashboard.php");
    exit();
}
?>
