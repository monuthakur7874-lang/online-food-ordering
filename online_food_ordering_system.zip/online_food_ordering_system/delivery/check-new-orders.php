<?php
/**
 * Delivery Panel - New Orders Poll Endpoint
 * File: delivery/check-new-orders.php
 */
include('includes/db-connect.php');

header('Content-Type: application/json; charset=utf-8');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
if ($rider_id <= 0) {
    http_response_code(403);
    echo json_encode(['newOrders' => 0]);
    exit();
}

// Notify only once per new order id (avoid repeating notifications every poll)
if (!isset($_SESSION['last_notified_order_id'])) {
    $_SESSION['last_notified_order_id'] = 0;
}
$last_notified_id = (int)$_SESSION['last_notified_order_id'];

$stmt = mysqli_prepare(
    $conn,
    "SELECT COUNT(*) AS cnt, COALESCE(MAX(id), 0) AS max_id
     FROM orders
     WHERE rider_id = ? AND order_status = 'Confirmed' AND id > ?"
);

if (!$stmt) {
    echo json_encode(['newOrders' => 0]);
    exit();
}

mysqli_stmt_bind_param($stmt, "ii", $rider_id, $last_notified_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $cnt, $max_id);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

$new_orders = (int)($cnt ?? 0);
if ($new_orders > 0) {
    $_SESSION['last_notified_order_id'] = (int)$max_id;
}

echo json_encode(['newOrders' => $new_orders]);
exit();
