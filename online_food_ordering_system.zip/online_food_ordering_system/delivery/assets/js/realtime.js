// Professional Real-time Delivery Panel JS
// Features: Auto-refresh, Geolocation, Notifications, Charts, Maps

class DeliveryPanel {
  constructor() {
    this.riderId = window.riderId || 0;
    this.map = null;
    this.markers = {};
    this.riderMarker = null;
    this.geoWatchId = null;
    this.autoTrackTimer = null;
    this.dutySyncInFlight = false;
    this.init();
  }

  init() {
    this.initThemeToggle();
    this.initDutyToggleSync();
    this.initCharts();
    this.initMap();

    if (document.getElementById('ordersContainer') || document.getElementById('newOrdersContainer')) {
      this.startRealtimeUpdates();
      this.initNotifications();
    }

    if (document.getElementById('liveMap') || document.getElementById('currentLocationBtn')) {
      this.initLocationTracking();
    }
  }

  initThemeToggle() {
    const toggle = document.querySelector('.theme-toggle');
    const html = document.documentElement;
    const savedTheme = localStorage.getItem('delivery-theme') || 'light';
    const syncIcon = (theme) => {
      const icon = toggle?.querySelector('i');
      if (icon) {
        icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
      }
    };

    html.setAttribute('data-theme', savedTheme);
    syncIcon(savedTheme);

    if (!toggle) return;

    toggle.addEventListener('click', () => {
      const currentTheme = html.getAttribute('data-theme');
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      html.setAttribute('data-theme', newTheme);
      localStorage.setItem('delivery-theme', newTheme);
      syncIcon(newTheme);
    });
  }

  initDutyToggleSync() {
    const dutyToggle = document.getElementById('dutyToggle');
    if (!dutyToggle) return;

    const label = document.querySelector('label[for="dutyToggle"]');
    const dutyStorage = window.sessionStorage;
    const storageKey = 'delivery-duty-status';
    const normalizeStatus = (value) => (value === 'Online' ? 'Online' : 'Offline');
    const getCurrentStatus = () => (dutyToggle.checked ? 'Online' : 'Offline');

    const setLabel = () => {
      if (label) label.textContent = getCurrentStatus();
    };

    const emitDutyStatusUpdate = () => {
      document.dispatchEvent(new CustomEvent('delivery-duty-updated', {
        detail: { status: getCurrentStatus() }
      }));
    };

    const applyStatus = (statusText) => {
      dutyToggle.checked = normalizeStatus(statusText) === 'Online';
      setLabel();
      emitDutyStatusUpdate();
    };

    const postDuty = async (statusText = getCurrentStatus()) => {
      if (this.dutySyncInFlight) return;
      this.dutySyncInFlight = true;

      try {
        const normalizedStatus = normalizeStatus(statusText);
        const body = new URLSearchParams({
          duty_status: normalizedStatus,
          csrf_token: window.csrfToken || ''
        });

        await fetch('location-sync.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
          body,
          keepalive: true
        });

        dutyStorage.setItem(storageKey, normalizedStatus);
      } catch (_) {
        // silent
      } finally {
        this.dutySyncInFlight = false;
      }
    };

    const serverStatus = normalizeStatus(window.deliveryInitialDutyStatus);
    const storedRawStatus = dutyStorage.getItem(storageKey);
    const preferredStatus = storedRawStatus ? normalizeStatus(storedRawStatus) : serverStatus;

    applyStatus(preferredStatus);
    dutyStorage.setItem(storageKey, preferredStatus);

    if (preferredStatus !== serverStatus) {
      postDuty(preferredStatus);
    }

    dutyToggle.addEventListener('change', () => {
      const nextStatus = getCurrentStatus();
      dutyStorage.setItem(storageKey, nextStatus);
      setLabel();
      emitDutyStatusUpdate();
      postDuty(nextStatus);
    });
  }

  initCharts() {
    const ctx = document.getElementById('earningsChart')?.getContext('2d');
    if (!ctx) return;

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['8AM', '10AM', '12PM', '2PM', '4PM', '6PM', '8PM'],
        datasets: [{
          label: 'Earnings',
          data: [120, 190, 300, 500, 460, 520, 800],
          borderColor: '#e23744',
          backgroundColor: 'rgba(226, 55, 68, 0.12)',
          pointBackgroundColor: '#ffffff',
          pointBorderColor: '#e23744',
          pointBorderWidth: 2,
          pointRadius: 4,
          pointHoverRadius: 5,
          tension: 0.38,
          fill: true
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => ` \u20B9${Number(ctx.raw || 0).toLocaleString('en-IN')}`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: '#64748b', font: { size: 11 } }
          },
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(226, 55, 68, 0.10)' },
            ticks: {
              color: '#64748b',
              callback: (value) => `\u20B9${value}`
            }
          }
        }
      }
    });
  }

  async initMap() {
    const mapElement = document.getElementById('liveMap');
    const placeholder = document.getElementById('liveMapPlaceholder');
    const dutyToggle = document.getElementById('dutyToggle');
    if (!mapElement) return;

    const setMapVisible = (show) => {
      mapElement.style.display = show ? 'block' : 'none';
      if (placeholder) placeholder.style.display = show ? 'none' : 'flex';
    };

    const isOnline = () => (!dutyToggle ? true : !!dutyToggle.checked);

    const ensureMap = async () => {
      if (this.map) return;

      const leafletCss = document.createElement('link');
      leafletCss.rel = 'stylesheet';
      leafletCss.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      document.head.appendChild(leafletCss);

      await new Promise((resolve) => {
        const leafletJs = document.createElement('script');
        leafletJs.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        leafletJs.onload = resolve;
        document.head.appendChild(leafletJs);
      });

      this.map = L.map('liveMap').setView([20.5937, 78.9629], 5);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: 'OpenStreetMap'
      }).addTo(this.map);

      this.loadOrderMarkers();

      const fullscreenBtn = L.control({ position: 'topright' });
      fullscreenBtn.onAdd = () => {
        const btn = L.DomUtil.create('button', 'map-fullscreen-btn btn');
        btn.innerHTML = '[ ]';
        btn.title = 'Fullscreen Map';
        btn.onclick = () => {
          window.location.href = 'map-view.php';
        };
        return btn;
      };
      fullscreenBtn.addTo(this.map);
    };

    setMapVisible(isOnline());
    if (isOnline()) await ensureMap();

    if (dutyToggle) {
      dutyToggle.addEventListener('change', async () => {
        const online = isOnline();
        setMapVisible(online);
        if (online) {
          await ensureMap();
          if (this.map) {
            setTimeout(() => this.map.invalidateSize(true), 60);
          }
        }
      });
    }
  }

  loadOrderMarkers() {
    fetch(`get-active-orders.php?rider_id=${this.riderId}`, { cache: 'no-store' })
      .then((res) => res.json())
      .then((orders) => {
        if (this.map) {
          Object.values(this.markers).forEach((marker) => {
            try {
              this.map.removeLayer(marker);
            } catch (_) {
              // noop
            }
          });
        }

        this.markers = {};

        orders.forEach((order) => {
          if (order.lat && order.lng) {
            const marker = L.marker([order.lat, order.lng])
              .addTo(this.map)
              .bindPopup(`
            <b>Order #${1000 + (((Number(order.id || 0) * 7919) + 4173) % 9000)}</b><br>
                ${this.escapeHtml(order.c_name || 'Customer')}<br>
                Status: ${this.escapeHtml(order.order_status || '')}<br>
                <a href="order-details.php?id=${Number(order.id)}" class="btn btn-primary btn-sm">View</a>
              `);
            this.markers[order.id] = marker;
          }
        });
      });
  }

  startRealtimeUpdates() {
    setInterval(() => {
      this.refreshOrders();
      this.updateLocation();
    }, 10000);
  }

  refreshOrders() {
    fetch('get-dashboard-data.php', { cache: 'no-store' })
      .then((res) => res.json())
      .then((data) => {
        this.updateOrderCards(data.orders || []);

        const earningsEl = document.querySelector('.today-earnings');
        const deliveriesEl = document.querySelector('.today-deliveries');
        if (earningsEl) earningsEl.textContent = `\u20B9${Number(data.earnings || 0).toLocaleString('en-IN')}`;
        if (deliveriesEl) deliveriesEl.textContent = `${Number(data.deliveries || 0)} deliveries`;

        this.updateStats(data);
      });
  }

  updateOrderCards(orders = []) {
    const newOrdersContainer = document.getElementById('newOrdersContainer');
    const activeOrdersContainer = document.getElementById('ordersContainer');
    if (!newOrdersContainer && !activeOrdersContainer) return;

    const confirmedOrders = orders.filter((order) => order.order_status === 'Confirmed');
    const onWayOrders = orders.filter((order) => order.order_status === 'On the Way');

    if (newOrdersContainer) {
      newOrdersContainer.innerHTML = confirmedOrders.length
        ? confirmedOrders.map((order) => this.renderConfirmedOrder(order)).join('')
        : '<div class="empty-state">No newly assigned orders right now.</div>';
    }

    if (activeOrdersContainer) {
      activeOrdersContainer.innerHTML = onWayOrders.length
        ? onWayOrders.map((order) => this.renderOnWayOrder(order)).join('')
        : `<div class="empty-state">
             <i class="fas fa-truck fa-3x mb-3"></i>
             <p class="mb-0">No active orders. Ready for the next delivery!</p>
           </div>`;
    }
  }

  updateStats(data = {}) {
    const setText = (id, value) => {
      const el = document.getElementById(id);
      if (el) el.textContent = value;
    };

    const activeOrders = Number(data.active_orders || 0);
    const deliveries = Number(data.deliveries || 0);
    const earnings = Number(data.earnings || 0);
    const confirmed = Number(data.confirmed_orders || 0);
    const onWay = Number(data.on_way_orders || 0);

    setText('activeQueueStat', activeOrders);
    setText('activeQueueHero', activeOrders);
    setText('completedTodayStat', deliveries);
    setText('completedTodayHero', `${deliveries} Deliveries`);
    setText('todayEarningsStat', `\u20B9${earnings.toLocaleString('en-IN')}`);
    setText('todayEarningsHero', `\u20B9${earnings.toLocaleString('en-IN')}`);
    setText('activeOrdersCount', activeOrders);
    setText('activeDeliveriesCount', onWay);
    setText('sidebarActiveOrders', `${activeOrders} active orders`);
    setText('freshAssignmentsStat', `${confirmed} fresh assignments`);
    setText('ordersInTransitStat', `${onWay} orders in transit`);
    setText('deliveriesCompletedStat', `${deliveries} deliveries completed`);
  }

  updateLocation() {}

  renderConfirmedOrder(order) {
    const isCod = (order.payment_mode === 'COD') || (order.payment_status === 'Pending');
    return `
      <div class="delivery-order-tile mb-3" data-state="confirmed">
        <div class="delivery-order-topbar">
          <span class="delivery-order-code">Order #${1000 + (((Number(order.id || 0) * 7919) + 4173) % 9000)}</span>
          <span class="delivery-chip chip-new">Pickup Pending</span>
        </div>

        <div class="delivery-order-customer">
          <div>
            <div class="delivery-order-title">${this.escapeHtml(order.c_name || 'Customer')}</div>
            <div class="delivery-order-sub">
              <i class="fas fa-location-dot me-1"></i>
              ${this.escapeHtml(this.truncate(order.delivery_address || '', 78))}
            </div>
          </div>
          <div class="delivery-order-total">\u20B9${Number(order.total_amount || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</div>
        </div>

        <div class="delivery-order-stats">
          <div class="delivery-stat">
            <span>Payment</span>
            <strong>${isCod ? 'COD Collection' : 'Paid Online'}</strong>
          </div>
          <div class="delivery-stat">
            <span>Next Action</span>
            <strong>Start pickup run</strong>
          </div>
        </div>

        <div class="order-progress" aria-hidden="true">
          <span class="order-progress-step is-active"></span>
          <span class="order-progress-step"></span>
          <span class="order-progress-step"></span>
        </div>
        <div class="order-progress-labels">
          <span>Assigned</span>
          <span>Pickup</span>
          <span>Delivered</span>
        </div>

        <div class="delivery-actions">
          <form method="POST" action="accept-order.php">
            <input type="hidden" name="csrf_token" value="${this.escapeAttribute(window.csrfToken || '')}">
            <input type="hidden" name="order_id" value="${Number(order.id)}">
            <button type="submit" class="btn btn-success btn-sm">
              <i class="fas fa-play me-1"></i> Start Delivery
            </button>
          </form>
          <form method="POST" action="reject-order.php">
            <input type="hidden" name="csrf_token" value="${this.escapeAttribute(window.csrfToken || '')}">
            <input type="hidden" name="order_id" value="${Number(order.id)}">
            <button type="submit" class="btn btn-danger btn-sm">
              <i class="fas fa-xmark me-1"></i> Cancel
            </button>
          </form>
          <a href="order-details.php?id=${Number(order.id)}" class="btn btn-primary btn-sm delivery-detail-btn">
            <i class="fas fa-eye me-1"></i> View
          </a>
        </div>
      </div>`;
  }

  renderOnWayOrder(order) {
    const isCod = (order.payment_mode === 'COD') || (order.payment_status === 'Pending');
    const phone = String(order.c_phone || '').replace(/[^0-9]/g, '');
    return `
      <div class="delivery-order-tile mb-3" data-state="onway" data-order-id="${Number(order.id)}">
        <div class="delivery-order-topbar">
          <span class="delivery-order-code">Order #${1000 + (((Number(order.id || 0) * 7919) + 4173) % 9000)}</span>
          <span class="delivery-chip chip-way">On Route</span>
        </div>

        <div class="delivery-order-customer">
          <div>
            <div class="delivery-order-title">${this.escapeHtml(order.c_name || 'Customer')}</div>
            <div class="delivery-order-sub">
              <i class="fas fa-location-dot me-1"></i>
              ${this.escapeHtml(this.truncate(order.delivery_address || '', 78))}
            </div>
          </div>
          <div class="delivery-order-total">\u20B9${Number(order.total_amount || 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</div>
        </div>

        <div class="delivery-order-stats">
          <div class="delivery-stat">
            <span>Payment</span>
            <strong>${isCod ? 'COD Collection' : 'Paid Online'}</strong>
          </div>
          <div class="delivery-stat">
            <span>Customer Contact</span>
            <strong>Call or WhatsApp</strong>
          </div>
        </div>

        <div class="order-progress" aria-hidden="true">
          <span class="order-progress-step is-active"></span>
          <span class="order-progress-step is-active"></span>
          <span class="order-progress-step"></span>
        </div>
        <div class="order-progress-labels">
          <span>Assigned</span>
          <span>On Route</span>
          <span>Delivered</span>
        </div>

        <div class="delivery-actions delivery-actions-compact">
          <a href="tel:${phone}" class="btn btn-call delivery-icon-btn" title="Call">
            <i class="fas fa-phone"></i>
            <span>Call</span>
          </a>
          <a href="https://wa.me/91${phone}" target="_blank" class="btn btn-whatsapp delivery-icon-btn" title="WhatsApp" rel="noreferrer">
            <i class="fab fa-whatsapp"></i>
            <span>WhatsApp</span>
          </a>
          <a href="order-details.php?id=${Number(order.id)}" class="btn btn-primary btn-sm delivery-detail-btn">
            <i class="fas fa-circle-info me-1"></i> Details
          </a>
        </div>
      </div>`;
  }

  truncate(value, maxLength) {
    const text = String(value || '');
    return text.length > maxLength ? `${text.slice(0, maxLength - 3)}...` : text;
  }

  escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  escapeAttribute(value) {
    return this.escapeHtml(value);
  }

  initLocationTracking() {
    if (!navigator.geolocation) return;

    const locationBtn = document.getElementById('currentLocationBtn');
    const dutyToggle = document.getElementById('dutyToggle');
    const isOnline = () => (!dutyToggle ? true : !!dutyToggle.checked);

    const stopTracking = () => {
      if (this.geoWatchId !== null) {
        try {
          navigator.geolocation.clearWatch(this.geoWatchId);
        } catch (_) {
          // noop
        }
        this.geoWatchId = null;
      }

      if (this.autoTrackTimer !== null) {
        clearInterval(this.autoTrackTimer);
        this.autoTrackTimer = null;
      }
    };

    const startTracking = () => {
      stopTracking();

      navigator.geolocation.getCurrentPosition(
        (pos) => this.updateRiderLocation(pos.coords),
        () => {},
        { enableHighAccuracy: true, timeout: 10000 }
      );

      try {
        this.geoWatchId = navigator.geolocation.watchPosition(
          (pos) => this.updateRiderLocation(pos.coords),
          () => {},
          { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 }
        );
      } catch (_) {
        this.autoTrackTimer = setInterval(() => {
          navigator.geolocation.getCurrentPosition(
            (pos) => this.updateRiderLocation(pos.coords),
            () => {},
            { enableHighAccuracy: true, timeout: 10000 }
          );
        }, 30000);
      }
    };

    if (locationBtn) {
      locationBtn.addEventListener('click', () => {
        if (!isOnline()) {
          alert('Go Online to share your live location.');
          return;
        }

        navigator.geolocation.getCurrentPosition(
          (pos) => this.updateRiderLocation(pos.coords),
          () => alert('Location access denied'),
          { enableHighAccuracy: true, timeout: 10000 }
        );
      });
    }

    if (dutyToggle) {
      dutyToggle.addEventListener('change', () => {
        if (isOnline()) startTracking();
        else stopTracking();
      });
    }

    if (isOnline()) startTracking();
  }

  updateRiderLocation(coords) {
    fetch('live-location.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': window.csrfToken || ''
      },
      body: JSON.stringify({ lat: coords.latitude, lng: coords.longitude })
    });

    if (this.map) {
      const pos = [coords.latitude, coords.longitude];
      this.map.setView(pos, 15);

      if (!this.riderMarker) {
        this.riderMarker = L.circleMarker(pos, {
          radius: 10,
          color: '#2563eb',
          weight: 3,
          fillColor: 'rgba(37,99,235,0.25)',
          fillOpacity: 1
        }).addTo(this.map).bindPopup('My Live Location');
      } else {
        this.riderMarker.setLatLng(pos);
      }
    }
  }

  initNotifications() {
    if (!('Notification' in window)) return;

    if (Notification.permission === 'granted') {
      this.checkNewOrders();
    } else if (Notification.permission !== 'denied') {
      Notification.requestPermission().then((permission) => {
        if (permission === 'granted') this.checkNewOrders();
      });
    }
  }

  checkNewOrders() {
    setInterval(() => {
      fetch('check-new-orders.php')
        .then((res) => res.json())
        .then((data) => {
          if (data.newOrders > 0) {
            new Notification('New Order Assigned!', {
              body: `${data.newOrders} new delivery${data.newOrders > 1 ? 's' : ''}`
            });
          }
        });
    }, 30000);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new DeliveryPanel();
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
