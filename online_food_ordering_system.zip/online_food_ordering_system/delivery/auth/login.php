<?php
include('../../config/db.php');

if (empty($_SESSION['csrf_token'])) {
    try {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } catch (Throwable $e) {
        $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
    }
}

if (isset($_SESSION['delivery_id']) && isset($_SESSION['delivery_role']) && $_SESSION['delivery_role'] === 'delivery') {
    header('location: ../dashboard.php');
    exit();
}

$login_error = '';
$login_notice = '';

if (isset($_GET['msg']) && $_GET['msg'] === 'logged_out') {
    $login_notice = 'You have been logged out successfully.';
} elseif (isset($_GET['msg']) && $_GET['msg'] !== '') {
    $login_notice = trim((string)$_GET['msg']);
}

if (isset($_POST['login_btn'])) {
    $csrf_ok = hash_equals((string)($_SESSION['csrf_token'] ?? ''), (string)($_POST['csrf_token'] ?? ''));
    if (!$csrf_ok) {
        $login_error = 'Security check failed. Please refresh and try again.';
    } else {
    $email = mysqli_real_escape_string($conn, (string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    $query = "SELECT * FROM users WHERE email='{$email}' AND role='delivery' AND status='Active' LIMIT 1";
    $res = mysqli_query($conn, $query);

    if ($res && mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);

        $stored_password = (string)($row['password'] ?? '');
        $is_valid = password_verify($password, $stored_password) || ($password !== '' && $password === $stored_password);

        if ($is_valid) {
            session_regenerate_id(true);

            $_SESSION['delivery_id'] = $row['id'];
            $_SESSION['delivery_name'] = $row['name'];
            $_SESSION['delivery_role'] = $row['role'];
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['user_role'] = $row['role'];

            if ($password === $stored_password) {
                $new_hash = password_hash($password, PASSWORD_DEFAULT);
                $safe_hash = mysqli_real_escape_string($conn, $new_hash);
                $uid = (int)$row['id'];
                @mysqli_query($conn, "UPDATE users SET password='{$safe_hash}' WHERE id={$uid} LIMIT 1");
            }

            header('location: ../dashboard.php');
            exit();
        }

        $login_error = 'Password galat hai.';
    } else {
        $login_error = 'Rider account nahi mila.';
    }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rider Login | Delivery Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            min-height: 100vh;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Plus Jakarta Sans', sans-serif;
            background:
                radial-gradient(900px 520px at 8% 12%, rgba(226,55,68,0.18), transparent 60%),
                radial-gradient(720px 420px at 92% 18%, rgba(251,146,60,0.16), transparent 60%),
                linear-gradient(135deg, #fff8f8 0%, #fff1f2 48%, #fff7ed 100%);
            padding: 1.25rem;
        }

        .login-shell {
            width: min(1080px, 100%);
            display: grid;
            grid-template-columns: minmax(0, 1fr) minmax(380px, 0.92fr);
            border-radius: 34px;
            overflow: hidden;
            box-shadow: 0 30px 70px rgba(15,23,42,0.14);
            background: #fff;
        }

        .login-brand {
            position: relative;
            padding: 2.4rem;
            color: #fff;
            background:
                radial-gradient(circle at top left, rgba(255,255,255,0.24), transparent 34%),
                radial-gradient(circle at 85% 20%, rgba(255,190,152,0.22), transparent 24%),
                linear-gradient(135deg, #cb1b45 0%, #e23744 48%, #ff7e8b 100%);
        }

        .login-brand::after {
            content: '';
            position: absolute;
            right: -70px;
            bottom: -70px;
            width: 220px;
            height: 220px;
            border-radius: 50%;
            background: rgba(255,255,255,0.12);
        }

        .login-brand > * {
            position: relative;
            z-index: 1;
        }

        .brand-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.55rem;
            padding: 0.55rem 0.95rem;
            border-radius: 999px;
            background: rgba(255,255,255,0.14);
            border: 1px solid rgba(255,255,255,0.18);
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
        }

        .login-brand h1 {
            margin: 1rem 0 0.6rem;
            font-size: clamp(2rem, 3vw, 3rem);
            font-weight: 800;
            line-height: 1.05;
        }

        .login-brand p {
            margin: 0;
            max-width: 460px;
            color: rgba(255,255,255,0.84);
            line-height: 1.7;
        }

        .brand-points {
            display: grid;
            gap: 0.9rem;
            margin-top: 1.5rem;
        }

        .brand-point {
            display: flex;
            align-items: center;
            gap: 0.9rem;
            padding: 0.95rem 1rem;
            border-radius: 20px;
            background: rgba(255,255,255,0.12);
            border: 1px solid rgba(255,255,255,0.16);
            backdrop-filter: blur(12px);
        }

        .brand-point i {
            width: 42px;
            height: 42px;
            border-radius: 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(255,255,255,0.16);
        }

        .login-card {
            padding: 2.2rem;
            background: #fff;
        }

        .login-card h2 {
            margin: 0;
            font-size: 1.8rem;
            font-weight: 800;
            color: #111827;
        }

        .login-card p {
            margin: 0.45rem 0 0;
            color: #6b7280;
        }

        .form-label {
            font-size: 0.76rem;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: #6b7280;
        }

        .input-group-text,
        .form-control {
            border-radius: 18px;
            border: 1px solid rgba(226,55,68,0.12);
            min-height: 54px;
        }

        .input-group-text {
            background: rgba(226,55,68,0.05);
            color: #e23744;
            border-right: none;
            padding-left: 1rem;
        }

        .form-control {
            border-left: none;
            padding-left: 0.25rem;
            box-shadow: none !important;
        }

        .form-control:focus {
            border-color: rgba(226,55,68,0.28);
        }

        .login-btn {
            border: none;
            border-radius: 18px;
            padding: 0.95rem 1rem;
            font-weight: 800;
            background: linear-gradient(135deg, #e23744, #ff7e8b);
            box-shadow: 0 16px 30px rgba(226,55,68,0.18);
        }

        .login-links {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
            margin-top: 1rem;
        }

        @media (max-width: 900px) {
            .login-shell {
                grid-template-columns: 1fr;
            }

            .login-brand,
            .login-card {
                padding: 1.5rem;
            }
        }
    </style>
</head>
<body>

<div class="login-shell">
    <div class="login-brand">
        <span class="brand-badge"><i class="fas fa-motorcycle"></i> Zomato Rider Access</span>
        <h1>Ride smart, stay synced, deliver faster.</h1>
        <p>Login to manage live dispatch, customer drops, route tracking and earnings from one unified rider panel.</p>

        <div class="brand-points">
            <div class="brand-point">
                <i class="fas fa-bolt"></i>
                <div>
                    <div class="fw-bold">Realtime Queue</div>
                    <div class="small text-white-50">Fresh assignments and active deliveries update in one view.</div>
                </div>
            </div>
            <div class="brand-point">
                <i class="fas fa-location-crosshairs"></i>
                <div>
                    <div class="fw-bold">Live Tracking</div>
                    <div class="small text-white-50">Map sync and rider status help keep dispatch movement clear.</div>
                </div>
            </div>
            <div class="brand-point">
                <i class="fas fa-wallet"></i>
                <div>
                    <div class="fw-bold">Shift Earnings</div>
                    <div class="small text-white-50">Monitor today, month and payout flow without leaving the panel.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="login-card">
        <h2>Rider Login</h2>
        <p>Use your delivery account to enter the dispatch workspace.</p>

        <div class="mt-4">
            <?php
            if ($login_notice !== '') {
                echo "<div class='alert alert-success border-0 rounded-4 py-3 small'><i class='fas fa-circle-check me-2'></i>" . htmlspecialchars($login_notice, ENT_QUOTES, 'UTF-8') . "</div>";
            }
            if ($login_error !== '') {
                echo "<div class='alert alert-danger border-0 rounded-4 py-3 small'><i class='fas fa-exclamation-circle me-2'></i>" . htmlspecialchars($login_error, ENT_QUOTES, 'UTF-8') . "</div>";
            }
            ?>

            <form action="" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars((string)($_SESSION['csrf_token'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                        <input type="email" name="email" class="form-control" placeholder="rider@example.com" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                    </div>
                </div>

                <button type="submit" name="login_btn" class="btn btn-primary w-100 login-btn">
                    Login to Rider Panel <i class="fas fa-arrow-right ms-2"></i>
                </button>

                <div class="login-links">
                    <a href="../../index.php" class="text-decoration-none small text-muted">Back to Website</a>
                    <span class="small text-muted">Self registration is disabled</span>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
