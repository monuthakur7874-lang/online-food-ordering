<?php
/**
 * Logout Logic for Rider Panel
 */

// 1. Database/Config include karein kyunki wahan session_start() hai
include('../../config/db.php');

// 2. Delivery-specific sessions clear karein (don't destroy full session)
unset($_SESSION['delivery_id'], $_SESSION['delivery_name'], $_SESSION['delivery_role']);
unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_role']);

// 3. Session destroy Nahi karein - preserve other panels
// session_destroy(); // COMMENTED OUT



// 5. User ko login page par redirect karein
// Hum "logged_out" ka ek message bhi bhej rahe hain URL mein
header("Location: login.php?msg=logged_out");
exit();
?>