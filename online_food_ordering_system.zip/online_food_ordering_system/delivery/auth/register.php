<?php
include_once('../../config/db.php');

// Self-registration for riders is disabled (use Admin Panel -> Delivery -> Onboard Rider)
header("Location: login.php?msg=Registration disabled. Contact admin.");
exit();

if(isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $v_no = mysqli_real_escape_string($conn, $_POST['vehicle_no']);
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name, email, phone, vehicle_no, password, role) 
            VALUES ('$name', '$email', '$phone', '$v_no', '$pass', 'delivery')";
    
    if(mysqli_query($conn, $sql)) {
        header("location: login.php?msg=Registered Successfully!");
    }
}
?>
<form method="POST">
    <input type="text" name="name" placeholder="Full Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="phone" placeholder="Phone" required>
    <input type="text" name="vehicle_no" placeholder="Vehicle No (e.g. GJ-01-1234)" required>
    <input type="password" name="password" placeholder="Password" required>
    <button name="register">Sign Up as Rider</button>
</form>
