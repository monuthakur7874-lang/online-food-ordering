<?php
/**
 * Delivery Panel - Authentication Check Middleware
 * Is file ko har protected page ke top par include karein.
 */

// 1. Check karein ki user logged in hai ya nahi
// Hum check kar rahe hain ki kya Session mein 'user_id' aur 'user_role' set hain.
if (!isset($_SESSION['delivery_id']) || !isset($_SESSION['delivery_role'])) {
    
    // Clear conflicting sessions
    unset($_SESSION['user_id'], $_SESSION['admin_id'], $_SESSION['user_role'], $_SESSION['admin_role']);
    
    header("Location: auth/login.php");
    exit();
}

// Ensure delivery role only
if ($_SESSION['delivery_role'] !== 'delivery') {
    session_destroy();
    unset($_SESSION['delivery_id'], $_SESSION['delivery_role']);
    header("Location: auth/login.php?error=unauthorized");
    exit();
}

// Copy for compatibility
$_SESSION['user_id'] = $_SESSION['delivery_id'];
$_SESSION['user_role'] = $_SESSION['delivery_role'];


// 3. User Active Status Check (Optional but Recommended)
// Agar aap database mein 'status' check karna chahte hain toh yahan query dal sakte hain.
?>