<?php
include('../config/db.php');
include('auth/auth-check.php');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$today = date('Y-m-d');
$commission_per_delivery = 40;

function qb_fetch_daily_summary_payload(mysqli $conn, int $rider_id, string $today, int $commission_per_delivery): array {
    $payload = [
        'summary_date' => date('l, d M Y'),
        'orders_done' => 0,
        'cash_collected' => 0.0,
        'commission_earned' => 0.0,
        'tips_earned' => 0.0,
        'net_payout' => 0.0,
        'avg_order_value' => 0.0,
        'first_delivery_time' => '',
        'latest_delivery_time' => '',
        'timeline' => [],
        'generated_at' => date('h:i A'),
    ];

    $stats_q = mysqli_query(
        $conn,
        "SELECT COUNT(id) AS total_orders, SUM(total_amount) AS collection
         FROM orders
         WHERE rider_id = {$rider_id} AND order_status = 'Delivered' AND DATE(order_date) = '{$today}'"
    );
    if ($stats_q && ($stats = mysqli_fetch_assoc($stats_q))) {
        $payload['orders_done'] = (int)($stats['total_orders'] ?? 0);
        $payload['cash_collected'] = (float)($stats['collection'] ?? 0);
    }

    $payload['commission_earned'] = $payload['orders_done'] * $commission_per_delivery;
    $payload['net_payout'] = $payload['commission_earned'] + $payload['tips_earned'];
    $payload['avg_order_value'] = $payload['orders_done'] > 0
        ? round($payload['cash_collected'] / $payload['orders_done'])
        : 0;

    $history_q = mysqli_query(
        $conn,
        "SELECT id, total_amount, payment_mode, payment_status, order_date
         FROM orders
         WHERE rider_id = {$rider_id} AND order_status = 'Delivered' AND DATE(order_date) = '{$today}'
         ORDER BY order_date DESC, id DESC"
    );

    if ($history_q) {
        $first_time = '';
        $latest_time = '';

        while ($row = mysqli_fetch_assoc($history_q)) {
            $order_date = (string)($row['order_date'] ?? '');
            if ($latest_time === '') {
                $latest_time = $order_date;
            }
            $first_time = $order_date;

            $payload['timeline'][] = [
                'id' => (int)$row['id'],
                'order_date' => $order_date,
                'total_amount' => (float)($row['total_amount'] ?? 0),
                'payment_mode' => (string)($row['payment_mode'] ?? ''),
                'payment_status' => (string)($row['payment_status'] ?? ''),
                'earning_amount' => $commission_per_delivery,
            ];
        }

        $payload['first_delivery_time'] = $first_time ? date('h:i A', strtotime($first_time)) : '';
        $payload['latest_delivery_time'] = $latest_time ? date('h:i A', strtotime($latest_time)) : '';
    }

    return $payload;
}

$payload = qb_fetch_daily_summary_payload($conn, $rider_id, $today, $commission_per_delivery);

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit();
}

$delivery_page_title = 'Daily Summary - Rider Panel';
include('includes/header.php');
?>

<style>
    .summary-shell {
        max-width: 1420px;
        margin: 0 auto;
    }

    .summary-hero {
        position: relative;
        overflow: hidden;
        margin-bottom: 1.5rem;
        padding: 1.8rem;
        border-radius: 28px;
        background:
            radial-gradient(circle at top left, rgba(255,255,255,0.16), transparent 34%),
            linear-gradient(135deg, #0f172a 0%, #334155 42%, #4f46e5 100%);
        color: #fff;
        box-shadow: 0 24px 58px rgba(15,23,42,0.22);
    }

    .summary-hero::after {
        content: '';
        position: absolute;
        right: -90px;
        bottom: -130px;
        width: 290px;
        height: 290px;
        border-radius: 50%;
        background: rgba(255,255,255,0.08);
    }

    .summary-hero-grid {
        position: relative;
        z-index: 1;
        display: grid;
        grid-template-columns: minmax(0, 1.45fr) minmax(320px, 0.95fr);
        gap: 1.15rem;
        align-items: center;
    }

    .summary-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.55rem;
        padding: 0.45rem 0.85rem;
        border-radius: 999px;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.16);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
    }

    .summary-hero h1 {
        margin: 0.95rem 0 0.55rem;
        font-size: clamp(1.9rem, 3vw, 2.8rem);
        font-weight: 800;
        line-height: 1.06;
    }

    .summary-hero p {
        margin: 0;
        max-width: 690px;
        color: rgba(255,255,255,0.8);
        font-size: 0.98rem;
    }

    .summary-actions {
        display: flex;
        gap: 0.85rem;
        flex-wrap: wrap;
        margin-top: 1.25rem;
    }

    .summary-actions .btn {
        border-radius: 14px;
        padding: 0.82rem 1rem;
        font-weight: 700;
    }

    .hero-side {
        display: grid;
        gap: 0.85rem;
    }

    .hero-panel {
        padding: 1rem 1.1rem;
        border-radius: 22px;
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.16);
        backdrop-filter: blur(12px);
    }

    .hero-panel .k {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: rgba(255,255,255,0.66);
    }

    .hero-panel .v {
        margin-top: 0.45rem;
        font-size: 1.85rem;
        font-weight: 800;
        line-height: 1;
    }

    .hero-panel .t {
        margin-top: 0.36rem;
        color: rgba(255,255,255,0.76);
        font-size: 0.88rem;
    }

    .summary-kpis {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 1rem;
        margin-bottom: 1.35rem;
    }

    .summary-kpi,
    .summary-panel,
    .summary-insight {
        background: rgba(255,255,255,0.96);
        border: 1px solid rgba(15,23,42,0.08);
        border-radius: 24px;
        padding: 1.15rem;
        box-shadow: 0 16px 34px rgba(15,23,42,0.08);
    }

    [data-theme='dark'] .summary-kpi,
    [data-theme='dark'] .summary-panel,
    [data-theme='dark'] .summary-insight {
        background: rgba(15,23,42,0.74);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 18px 40px rgba(0,0,0,0.34);
    }

    .summary-kpi-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.9rem;
    }

    .summary-kpi-icon {
        width: 46px;
        height: 46px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
        color: #fff;
    }

    .icon-orders { background: linear-gradient(135deg, #2563eb, #1d4ed8); }
    .icon-earned { background: linear-gradient(135deg, #11998e, #38ef7d); }
    .icon-collected { background: linear-gradient(135deg, #ef4444, #f97316); }
    .icon-average { background: linear-gradient(135deg, #8b5cf6, #6366f1); }

    .summary-kpi-chip {
        padding: 0.38rem 0.68rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        color: #475569;
        font-size: 0.74rem;
        font-weight: 700;
    }

    [data-theme='dark'] .summary-kpi-chip,
    [data-theme='dark'] .summary-pill {
        background: rgba(255,255,255,0.08);
        color: rgba(255,255,255,0.76);
    }

    .summary-kpi-value {
        font-size: 1.82rem;
        font-weight: 800;
        color: var(--text-color);
        line-height: 1;
    }

    .summary-kpi-note {
        margin-top: 0.35rem;
        font-size: 0.9rem;
        color: var(--muted);
    }

    .summary-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 320px;
        gap: 1rem;
        align-items: start;
    }

    .panel-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
        margin-bottom: 1rem;
    }

    .panel-head h5,
    .insight-head h6 {
        margin: 0;
        font-weight: 800;
        color: var(--text-color);
    }

    .panel-head p,
    .insight-head p {
        margin: 0.25rem 0 0;
        color: var(--muted);
        font-size: 0.9rem;
    }

    .summary-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.52rem 0.8rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        border: 1px solid rgba(15,23,42,0.08);
        color: #475569;
        font-size: 0.8rem;
        font-weight: 700;
    }

    .breakdown-card {
        padding: 1rem 1.05rem;
        border-radius: 20px;
        background: linear-gradient(135deg, rgba(99,102,241,0.08), rgba(34,197,94,0.08));
        border: 1px solid rgba(99,102,241,0.14);
        margin-bottom: 1rem;
    }

    .breakdown-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        margin-bottom: 0.75rem;
    }

    .breakdown-row:last-child {
        margin-bottom: 0;
    }

    .breakdown-row .k {
        color: var(--muted);
        font-size: 0.9rem;
    }

    .breakdown-row .v {
        color: var(--text-color);
        font-size: 0.96rem;
        font-weight: 800;
    }

    .breakdown-total {
        margin-top: 0.85rem;
        padding-top: 0.85rem;
        border-top: 1px solid rgba(15,23,42,0.08);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
    }

    .timeline-list {
        display: grid;
        gap: 0.9rem;
    }

    .timeline-card {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        border-radius: 20px;
        background: rgba(255,255,255,0.9);
        border: 1px solid rgba(15,23,42,0.08);
        box-shadow: 0 12px 24px rgba(15,23,42,0.06);
    }

    [data-theme='dark'] .timeline-card {
        background: rgba(15,23,42,0.62);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 14px 28px rgba(0,0,0,0.28);
    }

    .timeline-left {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        min-width: 0;
    }

    .timeline-dot {
        width: 46px;
        height: 46px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(99,102,241,0.14), rgba(16,185,129,0.14));
        color: #4f46e5;
        flex: 0 0 auto;
    }

    .timeline-copy strong {
        display: block;
        color: var(--text-color);
        font-size: 0.95rem;
        font-weight: 800;
    }

    .timeline-copy span {
        display: block;
        margin-top: 0.2rem;
        color: var(--muted);
        font-size: 0.84rem;
    }

    .timeline-right {
        text-align: right;
    }

    .timeline-right strong {
        display: block;
        font-size: 1.05rem;
        font-weight: 800;
        color: #16a34a;
    }

    .timeline-right span {
        display: block;
        margin-top: 0.2rem;
        color: var(--muted);
        font-size: 0.78rem;
        font-weight: 700;
    }

    .insight-stack {
        display: grid;
        gap: 1rem;
    }

    .insight-head {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.9rem;
    }

    .insight-icon {
        width: 44px;
        height: 44px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(37,99,235,0.14), rgba(15,118,110,0.18));
        color: #0f766e;
        font-size: 1rem;
    }

    .mini-stat {
        padding: 0.92rem 0.95rem;
        border-radius: 18px;
        background: rgba(15,23,42,0.04);
        margin-bottom: 0.75rem;
    }

    [data-theme='dark'] .mini-stat {
        background: rgba(255,255,255,0.06);
    }

    .mini-stat:last-child {
        margin-bottom: 0;
    }

    .mini-stat .k {
        font-size: 0.72rem;
        font-weight: 800;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--muted);
    }

    .mini-stat .v {
        margin-top: 0.25rem;
        font-size: 1.35rem;
        font-weight: 800;
        color: var(--text-color);
        line-height: 1.1;
    }

    .mini-stat .t {
        margin-top: 0.2rem;
        font-size: 0.83rem;
        color: var(--muted);
    }

    .empty-state {
        padding: 2.4rem 1.2rem;
        border-radius: 22px;
        border: 1px dashed rgba(148,163,184,0.35);
        background: rgba(148,163,184,0.06);
        text-align: center;
    }

    [data-theme='dark'] .empty-state {
        background: rgba(255,255,255,0.04);
        border-color: rgba(255,255,255,0.12);
    }

    @media (max-width: 1200px) {
        .summary-hero-grid,
        .summary-kpis,
        .summary-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .summary-hero {
            padding: 1.25rem;
            border-radius: 24px;
        }

        .panel-head,
        .summary-actions,
        .timeline-card,
        .breakdown-row,
        .breakdown-total {
            flex-direction: column;
            align-items: stretch;
        }

        .timeline-right {
            text-align: left;
        }
    }
</style>

<div class="summary-shell">
    <div class="summary-hero">
        <div class="summary-hero-grid">
            <div>
                <span class="summary-eyebrow"><i class="fas fa-calendar-day"></i> Daily Performance Report</span>
                <h1>Review today&apos;s deliveries, earnings, and delivery timeline in one clean professional summary.</h1>
                <p>Track your completed orders, incentive payout, and collection pace for today with a dashboard-style day report.</p>
                <div class="summary-actions">
                    <a href="earnings.php" class="btn btn-light text-dark"><i class="fas fa-wallet"></i> Earnings</a>
                    <a href="order-history.php?status=Delivered" class="btn btn-outline-light"><i class="fas fa-clock-rotate-left"></i> Order History</a>
                </div>
            </div>
            <div class="hero-side">
                <div class="hero-panel">
                    <div class="k">Summary Date</div>
                    <div class="v" id="summaryDateHero"><?= htmlspecialchars($payload['summary_date'], ENT_QUOTES, 'UTF-8'); ?></div>
                    <div class="t">Today&apos;s rider performance snapshot updates every 30 seconds.</div>
                </div>
                <div class="hero-panel">
                    <div class="k">Net Payout Today</div>
                    <div class="v" id="netPayoutHero">Rs <?= number_format((float)$payload['net_payout'], 2); ?></div>
                    <div class="t">Commission plus any extra incentives recorded for today.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="summary-kpis">
        <div class="summary-kpi">
            <div class="summary-kpi-top">
                <span class="summary-kpi-icon icon-orders"><i class="fas fa-box"></i></span>
                <span class="summary-kpi-chip">Orders</span>
            </div>
            <div class="summary-kpi-value" id="ordersDone"><?= (int)$payload['orders_done']; ?></div>
            <div class="summary-kpi-note">Total deliveries completed today.</div>
        </div>

        <div class="summary-kpi">
            <div class="summary-kpi-top">
                <span class="summary-kpi-icon icon-earned"><i class="fas fa-coins"></i></span>
                <span class="summary-kpi-chip">Earned</span>
            </div>
            <div class="summary-kpi-value" id="commissionEarned">Rs <?= number_format((float)$payload['commission_earned'], 0); ?></div>
            <div class="summary-kpi-note">Delivery incentive earned at Rs <?= $commission_per_delivery; ?> per completed trip.</div>
        </div>

        <div class="summary-kpi">
            <div class="summary-kpi-top">
                <span class="summary-kpi-icon icon-collected"><i class="fas fa-money-bill-wave"></i></span>
                <span class="summary-kpi-chip">Collected</span>
            </div>
            <div class="summary-kpi-value" id="cashCollected">Rs <?= number_format((float)$payload['cash_collected'], 0); ?></div>
            <div class="summary-kpi-note">Order value delivered to customers through today&apos;s trips.</div>
        </div>

        <div class="summary-kpi">
            <div class="summary-kpi-top">
                <span class="summary-kpi-icon icon-average"><i class="fas fa-chart-line"></i></span>
                <span class="summary-kpi-chip">Average</span>
            </div>
            <div class="summary-kpi-value" id="avgOrderValue">Rs <?= number_format((float)$payload['avg_order_value'], 0); ?></div>
            <div class="summary-kpi-note">Average delivered order value for today.</div>
        </div>
    </div>

    <div class="summary-layout">
        <div class="summary-panel">
            <div class="panel-head">
                <div>
                    <h5><i class="fas fa-receipt me-2 text-primary"></i>Today&apos;s Earnings Breakdown</h5>
                    <p>Clear payout split for delivered orders and incentives earned today.</p>
                </div>
                <div class="summary-pill" id="lastUpdated">
                    <i class="far fa-clock"></i>
                    Last updated: <?= htmlspecialchars($payload['generated_at'], ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>

            <div class="breakdown-card">
                <div class="breakdown-row">
                    <span class="k">Delivery Incentives (Rs <?= $commission_per_delivery; ?> x <span id="ordersDoneInline"><?= (int)$payload['orders_done']; ?></span>)</span>
                    <span class="v" id="commissionInline">Rs <?= number_format((float)$payload['commission_earned'], 2); ?></span>
                </div>
                <div class="breakdown-row">
                    <span class="k">Customer Tips</span>
                    <span class="v text-success" id="tipsEarned">Rs <?= number_format((float)$payload['tips_earned'], 2); ?></span>
                </div>
                <div class="breakdown-total">
                    <span class="fw-bold">Net Payout Today</span>
                    <h5 class="fw-bold text-primary mb-0" id="netPayout">Rs <?= number_format((float)$payload['net_payout'], 2); ?></h5>
                </div>
            </div>

            <div class="panel-head" style="margin-top: 1.1rem;">
                <div>
                    <h5><i class="fas fa-route me-2 text-warning"></i>Delivery Timeline</h5>
                    <p>Chronological log of completed deliveries for today.</p>
                </div>
            </div>

            <div id="timelineList" class="timeline-list">
                <?php if (!empty($payload['timeline'])): ?>
                    <?php foreach ($payload['timeline'] as $row): ?>
                        <?php $date_value = strtotime($row['order_date']); ?>
                        <article class="timeline-card">
                            <div class="timeline-left">
                                <span class="timeline-dot"><i class="fas fa-circle-check"></i></span>
                                <div class="timeline-copy">
                                    <strong>Order Delivered #<?= (int)$row['id']; ?></strong>
                                    <span>
                                        <?= $date_value ? date('h:i A', $date_value) : '-'; ?>
                                        &middot;
                                        <?= htmlspecialchars(trim(($row['payment_mode'] ?: 'Payment') . ' / ' . ($row['payment_status'] ?: 'Unknown')), ENT_QUOTES, 'UTF-8'); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="timeline-right">
                                <strong>+Rs <?= number_format((float)$row['earning_amount'], 2); ?></strong>
                                <span>Order value Rs <?= number_format((float)$row['total_amount'], 0); ?></span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-truck fa-3x mb-3 text-muted"></i>
                        <h5 class="text-muted mb-2">No deliveries completed today yet.</h5>
                        <p class="text-muted small mb-0">Once you complete orders today, the timeline will appear here automatically.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <aside class="insight-stack">
            <div class="summary-insight">
                <div class="insight-head">
                    <span class="insight-icon"><i class="fas fa-stopwatch"></i></span>
                    <div>
                        <h6>Day Window</h6>
                        <p>Quick timing view of your completed shift.</p>
                    </div>
                </div>
                <div class="mini-stat">
                    <div class="k">First Delivery</div>
                    <div class="v" id="firstDeliveryTime"><?= htmlspecialchars($payload['first_delivery_time'] ?: '-', ENT_QUOTES, 'UTF-8'); ?></div>
                    <div class="t">Earliest completed drop-off recorded today.</div>
                </div>
                <div class="mini-stat">
                    <div class="k">Latest Delivery</div>
                    <div class="v" id="latestDeliveryTime"><?= htmlspecialchars($payload['latest_delivery_time'] ?: '-', ENT_QUOTES, 'UTF-8'); ?></div>
                    <div class="t">Most recent completed delivery recorded today.</div>
                </div>
            </div>

            <div class="summary-insight">
                <div class="insight-head">
                    <span class="insight-icon"><i class="fas fa-lightbulb"></i></span>
                    <div>
                        <h6>Focus Note</h6>
                        <p>What this report is helping you watch right now.</p>
                    </div>
                </div>
                <div class="mini-stat">
                    <div class="k">Current Focus</div>
                    <div class="v" id="focusValue"><?= $payload['orders_done'] > 0 ? 'Active Day' : 'Waiting'; ?></div>
                    <div class="t" id="focusText"><?= $payload['orders_done'] > 0
                        ? 'Your day report is tracking completed deliveries and incentive output in real time.'
                        : 'No completed deliveries yet today, so this report is waiting for the first successful drop.'; ?></div>
                </div>
            </div>
        </aside>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const formatMoney = (value, decimals = 0) => `Rs ${Number(value || 0).toLocaleString('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  })}`;

  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const summaryDateHeroEl = document.getElementById('summaryDateHero');
  const netPayoutHeroEl = document.getElementById('netPayoutHero');
  const ordersDoneEl = document.getElementById('ordersDone');
  const commissionEarnedEl = document.getElementById('commissionEarned');
  const cashCollectedEl = document.getElementById('cashCollected');
  const avgOrderValueEl = document.getElementById('avgOrderValue');
  const ordersDoneInlineEl = document.getElementById('ordersDoneInline');
  const commissionInlineEl = document.getElementById('commissionInline');
  const tipsEarnedEl = document.getElementById('tipsEarned');
  const netPayoutEl = document.getElementById('netPayout');
  const timelineListEl = document.getElementById('timelineList');
  const firstDeliveryTimeEl = document.getElementById('firstDeliveryTime');
  const latestDeliveryTimeEl = document.getElementById('latestDeliveryTime');
  const focusValueEl = document.getElementById('focusValue');
  const focusTextEl = document.getElementById('focusText');
  const lastUpdatedEl = document.getElementById('lastUpdated');

  const renderTimeline = (items) => {
    if (!Array.isArray(items) || items.length === 0) {
      return `
        <div class="empty-state">
          <i class="fas fa-truck fa-3x mb-3 text-muted"></i>
          <h5 class="text-muted mb-2">No deliveries completed today yet.</h5>
          <p class="text-muted small mb-0">Once you complete orders today, the timeline will appear here automatically.</p>
        </div>`;
    }

    return items.map((item) => {
      const date = item.order_date ? new Date(item.order_date.replace(' ', 'T')) : null;
      const timeText = date && !Number.isNaN(date.getTime())
        ? date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
        : '-';
      const paymentText = `${item.payment_mode || 'Payment'} / ${item.payment_status || 'Unknown'}`;

      return `
        <article class="timeline-card">
          <div class="timeline-left">
            <span class="timeline-dot"><i class="fas fa-circle-check"></i></span>
            <div class="timeline-copy">
              <strong>Order Delivered #${Number(item.id)}</strong>
              <span>${escapeHtml(timeText)} &middot; ${escapeHtml(paymentText)}</span>
            </div>
          </div>
          <div class="timeline-right">
            <strong>+${formatMoney(item.earning_amount, 2)}</strong>
            <span>Order value ${formatMoney(item.total_amount, 0)}</span>
          </div>
        </article>`;
    }).join('');
  };

  const applyPayload = (payload) => {
    if (!payload) return;

    if (summaryDateHeroEl) summaryDateHeroEl.textContent = payload.summary_date || '';
    if (netPayoutHeroEl) netPayoutHeroEl.textContent = formatMoney(payload.net_payout, 2);
    if (ordersDoneEl) ordersDoneEl.textContent = Number(payload.orders_done || 0).toLocaleString('en-IN');
    if (commissionEarnedEl) commissionEarnedEl.textContent = formatMoney(payload.commission_earned, 0);
    if (cashCollectedEl) cashCollectedEl.textContent = formatMoney(payload.cash_collected, 0);
    if (avgOrderValueEl) avgOrderValueEl.textContent = formatMoney(payload.avg_order_value, 0);
    if (ordersDoneInlineEl) ordersDoneInlineEl.textContent = Number(payload.orders_done || 0).toLocaleString('en-IN');
    if (commissionInlineEl) commissionInlineEl.textContent = formatMoney(payload.commission_earned, 2);
    if (tipsEarnedEl) tipsEarnedEl.textContent = formatMoney(payload.tips_earned, 2);
    if (netPayoutEl) netPayoutEl.textContent = formatMoney(payload.net_payout, 2);
    if (timelineListEl) timelineListEl.innerHTML = renderTimeline(payload.timeline || []);
    if (firstDeliveryTimeEl) firstDeliveryTimeEl.textContent = payload.first_delivery_time || '-';
    if (latestDeliveryTimeEl) latestDeliveryTimeEl.textContent = payload.latest_delivery_time || '-';
    if (focusValueEl) focusValueEl.textContent = Number(payload.orders_done || 0) > 0 ? 'Active Day' : 'Waiting';
    if (focusTextEl) {
      focusTextEl.textContent = Number(payload.orders_done || 0) > 0
        ? 'Your day report is tracking completed deliveries and incentive output in real time.'
        : 'No completed deliveries yet today, so this report is waiting for the first successful drop.';
    }
    if (lastUpdatedEl) lastUpdatedEl.innerHTML = `<i class="far fa-clock"></i> Last updated: ${escapeHtml(payload.generated_at || '')}`;
  };

  const refreshSummary = () => {
    fetch('daily-summary.php?ajax=1', { cache: 'no-store' })
      .then((response) => response.ok ? response.json() : null)
      .then((payload) => {
        if (payload) applyPayload(payload);
      })
      .catch(() => {});
  };

  setInterval(refreshSummary, 30000);
});
</script>

<?php include('includes/footer.php'); ?>
