<?php
include('includes/db-connect.php');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!function_exists('qb_verify_csrf_token') || !qb_verify_csrf_token($csrf)) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Invalid CSRF token']);
        exit();
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    $lat_raw = $input['lat'] ?? 0;
    $lng_raw = $input['lng'] ?? 0;

    $lat = (string)(is_numeric($lat_raw) ? $lat_raw : '0');
    $lng = (string)(is_numeric($lng_raw) ? $lng_raw : '0');

    $rider_id = (int)($_SESSION['user_id'] ?? 0);
    if ($rider_id <= 0) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
        exit();
    }

    $stmt = mysqli_prepare($conn, "UPDATE users SET lat=?, lng=?, last_seen=NOW() WHERE id=? AND role='delivery'");
    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => 'Prepare failed']);
        exit();
    }

    mysqli_stmt_bind_param($stmt, "ssi", $lat, $lng, $rider_id);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    echo json_encode($ok ? ['status' => 'success', 'message' => 'Location updated'] : ['status' => 'error', 'message' => 'Update failed']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid method']);
}
?>
