<?php
/**
 * Delivery Panel - Dashboard Data (AJAX)
 * File: delivery/get-dashboard-data.php
 */
include('includes/db-connect.php');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
if ($rider_id <= 0) {
    http_response_code(403);
    echo json_encode(['orders' => [], 'earnings' => 0, 'deliveries' => 0]);
    exit();
}

$today = date('Y-m-d');

// Deliveries today
$deliveries = 0;
$stmt = mysqli_prepare($conn, "SELECT COUNT(id) AS total FROM orders WHERE rider_id=? AND order_status='Delivered' AND DATE(order_date)=?");
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "is", $rider_id, $today);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $deliveries);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
}
$deliveries = (int)$deliveries;

// Earnings model: ₹50 per delivery (same as delivery/dashboard.php)
$earnings = $deliveries * 40;

// Active orders list (basic; UI rendering can be handled client-side if needed)
$orders = [];
$stmt = mysqli_prepare(
    $conn,
    "SELECT o.id, o.total_amount, o.payment_status, o.order_status, o.delivery_address, u.name AS c_name, u.phone AS c_phone
     FROM orders o
     JOIN users u ON o.user_id = u.id
     WHERE o.rider_id=? AND o.order_status IN ('Confirmed','On the Way')
     ORDER BY o.id DESC
     LIMIT 10"
);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $rider_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            $orders[] = $row;
        }
    }
    mysqli_stmt_close($stmt);
}

echo json_encode([
    'orders' => $orders,
    'earnings' => $earnings,
    'deliveries' => $deliveries,
    'confirmed_orders' => count(array_filter($orders, static function ($order) {
        return (($order['order_status'] ?? '') === 'Confirmed');
    })),
    'on_way_orders' => count(array_filter($orders, static function ($order) {
        return (($order['order_status'] ?? '') === 'On the Way');
    })),
    'active_orders' => count($orders)
]);
exit();
