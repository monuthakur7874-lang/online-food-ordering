<?php
require_once(__DIR__ . '/includes/db-connect.php');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$contentType = (string)($_SERVER['CONTENT_TYPE'] ?? '');
header('Content-Type: application/json; charset=utf-8');

$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
$post = $_POST;

if ($isPost && stripos($contentType, 'application/json') !== false) {
    $json = json_decode((string)file_get_contents('php://input'), true);
    if (is_array($json)) {
        $post = array_merge($post, $json);
    }
}

if ($rider_id <= 0) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'message' => 'Unauthorized']);
    exit;
}

// CSRF for state-changing AJAX (token provided by delivery/includes/header.php)
if ($isPost) {
    qb_require_csrf((string)($post['csrf_token'] ?? ''));
}

// A) Duty Status Toggle (Online/Offline)
if ($isPost && isset($post['duty_status'])) {
    $duty_status = ($post['duty_status'] === 'Online') ? 'Yes' : 'No';
    $stmt = mysqli_prepare($conn, "UPDATE users SET is_online=?, last_seen=NOW() WHERE id=? AND role='delivery'");
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Prepare failed']);
        exit;
    }
    mysqli_stmt_bind_param($stmt, "si", $duty_status, $rider_id);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    echo json_encode(['ok' => (bool)$ok, 'status' => $duty_status]);
    exit;
}

// B) AJAX call ke liye GPS Update logic
if ($isPost && isset($post['lat'], $post['lng'])) {
    $lat_raw = $post['lat'];
    $lng_raw = $post['lng'];
    $lat = (string)(is_numeric($lat_raw) ? $lat_raw : '0');
    $lng = (string)(is_numeric($lng_raw) ? $lng_raw : '0');

    $stmt = mysqli_prepare($conn, "UPDATE users SET lat=?, lng=?, last_seen=NOW() WHERE id=? AND role='delivery'");
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Prepare failed']);
        exit;
    }
    mysqli_stmt_bind_param($stmt, "ssi", $lat, $lng, $rider_id);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    echo json_encode(['ok' => (bool)$ok]);
    exit;
}

// C) Order status update (button/action based)
if ($isPost && isset($post['order_id'], $post['status'])) {
    $oid = (int)$post['order_id'];
    $status = (string)$post['status'];
    $allowed_statuses = ['Pending', 'Confirmed', 'On the Way', 'Delivered', 'Cancelled'];

    if ($oid > 0 && in_array($status, $allowed_statuses, true)) {
        $status_esc = mysqli_real_escape_string($conn, $status);
        $update = mysqli_query($conn, "UPDATE orders SET order_status='$status_esc' WHERE id=$oid AND rider_id=$rider_id");
        if ($update) {
            echo json_encode(['ok' => true]);
            exit;
        }
    }

    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Bad request']);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'message' => 'Bad request']);
exit;
