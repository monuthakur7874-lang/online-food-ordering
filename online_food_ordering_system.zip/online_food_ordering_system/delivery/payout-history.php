<?php
include('../config/db.php');
include('auth/auth-check.php');

$rider_id = (int)($_SESSION['user_id'] ?? 0);
$allowed_statuses = ['All', 'Completed', 'Pending', 'Failed'];
$status_filter = isset($_GET['status']) ? (string)$_GET['status'] : 'All';
$status_filter = in_array($status_filter, $allowed_statuses, true) ? $status_filter : 'All';

function qb_fetch_payout_payload(mysqli $conn, int $rider_id, string $status_filter): array {
    $payload = [
        'status_filter' => $status_filter,
        'totals' => [
            'completed_amount' => 0.0,
            'completed_count' => 0,
            'pending_amount' => 0.0,
            'pending_count' => 0,
            'failed_count' => 0,
            'all_count' => 0,
        ],
        'selected_count' => 0,
        'payouts' => [],
        'generated_at' => date('h:i A'),
    ];

    $stats_sql = "
        SELECT
            SUM(CASE WHEN status = 'Completed' THEN amount ELSE 0 END) AS completed_amount,
            SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) AS completed_count,
            SUM(CASE WHEN status = 'Pending' THEN amount ELSE 0 END) AS pending_amount,
            SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) AS pending_count,
            SUM(CASE WHEN status = 'Failed' THEN 1 ELSE 0 END) AS failed_count,
            COUNT(*) AS all_count
        FROM payouts
        WHERE rider_id = {$rider_id}";
    $stats_res = mysqli_query($conn, $stats_sql);
    if ($stats_res && ($stats_row = mysqli_fetch_assoc($stats_res))) {
        $payload['totals']['completed_amount'] = (float)($stats_row['completed_amount'] ?? 0);
        $payload['totals']['completed_count'] = (int)($stats_row['completed_count'] ?? 0);
        $payload['totals']['pending_amount'] = (float)($stats_row['pending_amount'] ?? 0);
        $payload['totals']['pending_count'] = (int)($stats_row['pending_count'] ?? 0);
        $payload['totals']['failed_count'] = (int)($stats_row['failed_count'] ?? 0);
        $payload['totals']['all_count'] = (int)($stats_row['all_count'] ?? 0);
    }

    $where_status = '';
    if ($status_filter !== 'All') {
        $status_safe = mysqli_real_escape_string($conn, $status_filter);
        $where_status = " AND status = '{$status_safe}'";
    }

    $list_sql = "
        SELECT id, amount, status, created_at
        FROM payouts
        WHERE rider_id = {$rider_id}{$where_status}
        ORDER BY created_at DESC, id DESC";
    $list_res = mysqli_query($conn, $list_sql);
    if ($list_res) {
        while ($row = mysqli_fetch_assoc($list_res)) {
            $payload['payouts'][] = [
                'id' => (int)$row['id'],
                'amount' => (float)($row['amount'] ?? 0),
                'status' => (string)($row['status'] ?? ''),
                'created_at' => (string)($row['created_at'] ?? ''),
                'method_label' => 'Bank Transfer',
            ];
        }
    }

    $payload['selected_count'] = count($payload['payouts']);
    return $payload;
}

$payload = qb_fetch_payout_payload($conn, $rider_id, $status_filter);

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload);
    exit();
}

$delivery_page_title = 'Payout History - Rider Panel';
include('includes/header.php');
?>

<style>
    .payout-shell {
        max-width: 1420px;
        margin: 0 auto;
    }

    .payout-hero {
        position: relative;
        overflow: hidden;
        margin-bottom: 1.5rem;
        padding: 1.8rem;
        border-radius: 28px;
        background:
            radial-gradient(circle at top left, rgba(255,255,255,0.16), transparent 34%),
            linear-gradient(135deg, #0f172a 0%, #1d4ed8 42%, #0f766e 100%);
        color: #fff;
        box-shadow: 0 24px 58px rgba(15,23,42,0.22);
    }

    .payout-hero::after {
        content: '';
        position: absolute;
        right: -90px;
        bottom: -130px;
        width: 290px;
        height: 290px;
        border-radius: 50%;
        background: rgba(255,255,255,0.08);
    }

    .payout-hero-grid {
        position: relative;
        z-index: 1;
        display: grid;
        grid-template-columns: minmax(0, 1.45fr) minmax(320px, 0.95fr);
        gap: 1.15rem;
        align-items: center;
    }

    .payout-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 0.55rem;
        padding: 0.45rem 0.85rem;
        border-radius: 999px;
        background: rgba(255,255,255,0.12);
        border: 1px solid rgba(255,255,255,0.16);
        font-size: 0.78rem;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
    }

    .payout-hero h1 {
        margin: 0.95rem 0 0.55rem;
        font-size: clamp(1.9rem, 3vw, 2.8rem);
        font-weight: 800;
        line-height: 1.06;
    }

    .payout-hero p {
        margin: 0;
        max-width: 690px;
        color: rgba(255,255,255,0.8);
        font-size: 0.98rem;
    }

    .payout-actions {
        display: flex;
        gap: 0.85rem;
        flex-wrap: wrap;
        margin-top: 1.25rem;
    }

    .payout-actions .btn {
        border-radius: 14px;
        padding: 0.82rem 1rem;
        font-weight: 700;
    }

    .hero-side {
        display: grid;
        gap: 0.85rem;
    }

    .hero-panel {
        padding: 1rem 1.1rem;
        border-radius: 22px;
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.16);
        backdrop-filter: blur(12px);
    }

    .hero-panel .k {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: rgba(255,255,255,0.66);
    }

    .hero-panel .v {
        margin-top: 0.45rem;
        font-size: 1.85rem;
        font-weight: 800;
        line-height: 1;
    }

    .hero-panel .t {
        margin-top: 0.36rem;
        color: rgba(255,255,255,0.76);
        font-size: 0.88rem;
    }

    .payout-kpis {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 1rem;
        margin-bottom: 1.35rem;
    }

    .payout-kpi,
    .payout-panel,
    .payout-insight {
        background: rgba(255,255,255,0.96);
        border: 1px solid rgba(15,23,42,0.08);
        border-radius: 24px;
        padding: 1.15rem;
        box-shadow: 0 16px 34px rgba(15,23,42,0.08);
    }

    [data-theme='dark'] .payout-kpi,
    [data-theme='dark'] .payout-panel,
    [data-theme='dark'] .payout-insight {
        background: rgba(15,23,42,0.74);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 18px 40px rgba(0,0,0,0.34);
    }

    .payout-kpi-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.9rem;
    }

    .payout-kpi-icon {
        width: 46px;
        height: 46px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
        color: #fff;
    }

    .icon-completed { background: linear-gradient(135deg, #11998e, #38ef7d); }
    .icon-pending { background: linear-gradient(135deg, #f59e0b, #f97316); }
    .icon-failed { background: linear-gradient(135deg, #ef4444, #dc2626); }
    .icon-total { background: linear-gradient(135deg, #2563eb, #1d4ed8); }

    .payout-kpi-chip {
        padding: 0.38rem 0.68rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        color: #475569;
        font-size: 0.74rem;
        font-weight: 700;
    }

    [data-theme='dark'] .payout-kpi-chip,
    [data-theme='dark'] .payout-pill {
        background: rgba(255,255,255,0.08);
        color: rgba(255,255,255,0.76);
    }

    .payout-kpi-value {
        font-size: 1.82rem;
        font-weight: 800;
        color: var(--text-color);
        line-height: 1;
    }

    .payout-kpi-note {
        margin-top: 0.35rem;
        font-size: 0.9rem;
        color: var(--muted);
    }

    .payout-layout {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 320px;
        gap: 1rem;
        align-items: start;
    }

    .panel-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
        margin-bottom: 1rem;
    }

    .panel-head h5,
    .insight-head h6 {
        margin: 0;
        font-weight: 800;
        color: var(--text-color);
    }

    .panel-head p,
    .insight-head p {
        margin: 0.25rem 0 0;
        color: var(--muted);
        font-size: 0.9rem;
    }

    .payout-tabs {
        display: inline-flex;
        gap: 0.45rem;
        padding: 0.45rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        border: 1px solid rgba(15,23,42,0.08);
        flex-wrap: wrap;
    }

    .payout-tab {
        padding: 0.68rem 0.95rem;
        border-radius: 999px;
        font-size: 0.86rem;
        font-weight: 800;
        color: #475569;
        text-decoration: none;
        transition: all .2s ease;
    }

    .payout-tab.active {
        background: linear-gradient(135deg, #2563eb, #1d4ed8);
        color: #fff;
        box-shadow: 0 10px 22px rgba(37,99,235,0.22);
    }

    .payout-statusbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        flex-wrap: wrap;
        margin-bottom: 1rem;
    }

    .payout-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.52rem 0.8rem;
        border-radius: 999px;
        background: rgba(15,23,42,0.05);
        border: 1px solid rgba(15,23,42,0.08);
        color: #475569;
        font-size: 0.8rem;
        font-weight: 700;
    }

    .payout-list {
        display: grid;
        gap: 0.9rem;
    }

    .transfer-card {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        border-radius: 20px;
        background: rgba(255,255,255,0.9);
        border: 1px solid rgba(15,23,42,0.08);
        box-shadow: 0 12px 24px rgba(15,23,42,0.06);
    }

    [data-theme='dark'] .transfer-card {
        background: rgba(15,23,42,0.62);
        border-color: rgba(255,255,255,0.1);
        box-shadow: 0 14px 28px rgba(0,0,0,0.28);
    }

    .transfer-left {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        min-width: 0;
    }

    .transfer-icon {
        width: 46px;
        height: 46px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex: 0 0 auto;
    }

    .transfer-icon.completed {
        background: linear-gradient(135deg, rgba(34,197,94,0.14), rgba(16,185,129,0.14));
        color: #16a34a;
    }

    .transfer-icon.pending {
        background: linear-gradient(135deg, rgba(245,158,11,0.14), rgba(249,115,22,0.14));
        color: #d97706;
    }

    .transfer-icon.failed {
        background: linear-gradient(135deg, rgba(239,68,68,0.12), rgba(220,38,38,0.14));
        color: #dc2626;
    }

    .transfer-copy strong {
        display: block;
        color: var(--text-color);
        font-size: 0.95rem;
        font-weight: 800;
    }

    .transfer-copy span {
        display: block;
        margin-top: 0.2rem;
        color: var(--muted);
        font-size: 0.84rem;
    }

    .transfer-right {
        text-align: right;
    }

    .transfer-right strong {
        display: block;
        font-size: 1.05rem;
        font-weight: 800;
        color: var(--text-color);
    }

    .transfer-status {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        margin-top: 0.25rem;
        padding: 0.4rem 0.72rem;
        border-radius: 999px;
        font-size: 0.76rem;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .status-completed {
        background: rgba(34,197,94,0.14);
        color: #15803d;
        border: 1px solid rgba(34,197,94,0.18);
    }

    .status-pending {
        background: rgba(245,158,11,0.14);
        color: #b45309;
        border: 1px solid rgba(245,158,11,0.18);
    }

    .status-failed {
        background: rgba(239,68,68,0.12);
        color: #b91c1c;
        border: 1px solid rgba(239,68,68,0.18);
    }

    .insight-stack {
        display: grid;
        gap: 1rem;
    }

    .insight-head {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin-bottom: 0.9rem;
    }

    .insight-icon {
        width: 44px;
        height: 44px;
        border-radius: 16px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, rgba(37,99,235,0.14), rgba(15,118,110,0.18));
        color: #0f766e;
        font-size: 1rem;
    }

    .mini-stat {
        padding: 0.92rem 0.95rem;
        border-radius: 18px;
        background: rgba(15,23,42,0.04);
        margin-bottom: 0.75rem;
    }

    [data-theme='dark'] .mini-stat {
        background: rgba(255,255,255,0.06);
    }

    .mini-stat:last-child {
        margin-bottom: 0;
    }

    .mini-stat .k {
        font-size: 0.72rem;
        font-weight: 800;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: var(--muted);
    }

    .mini-stat .v {
        margin-top: 0.25rem;
        font-size: 1.35rem;
        font-weight: 800;
        color: var(--text-color);
        line-height: 1.1;
    }

    .mini-stat .t {
        margin-top: 0.2rem;
        font-size: 0.83rem;
        color: var(--muted);
    }

    .focus-banner {
        padding: 1rem 1.05rem;
        border-radius: 20px;
        background: linear-gradient(135deg, rgba(14,165,233,0.1), rgba(37,99,235,0.1));
        border: 1px solid rgba(14,165,233,0.14);
    }

    .focus-banner strong {
        display: block;
        color: var(--text-color);
        font-size: 0.95rem;
        font-weight: 800;
    }

    .focus-banner span {
        display: block;
        margin-top: 0.28rem;
        color: var(--muted);
        font-size: 0.84rem;
    }

    .empty-state {
        padding: 2.4rem 1.2rem;
        border-radius: 22px;
        border: 1px dashed rgba(148,163,184,0.35);
        background: rgba(148,163,184,0.06);
        text-align: center;
    }

    [data-theme='dark'] .empty-state {
        background: rgba(255,255,255,0.04);
        border-color: rgba(255,255,255,0.12);
    }

    @media (max-width: 1200px) {
        .payout-hero-grid,
        .payout-kpis,
        .payout-layout {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 768px) {
        .payout-hero {
            padding: 1.25rem;
            border-radius: 24px;
        }

        .panel-head,
        .payout-statusbar,
        .payout-actions,
        .transfer-card {
            flex-direction: column;
            align-items: stretch;
        }

        .transfer-right {
            text-align: left;
        }
    }
</style>

<div class="payout-shell">
    <div class="payout-hero">
        <div class="payout-hero-grid">
            <div>
                <span class="payout-eyebrow"><i class="fas fa-building-columns"></i> Rider Payout Center</span>
                <h1>Track completed transfers, pending withdrawals, and payout history in one proper finance view.</h1>
                <p>Review your banking history, monitor transfer statuses, and keep your rider payout timeline organized with live sync.</p>
                <div class="payout-actions">
                    <a href="earnings.php" class="btn btn-light text-dark"><i class="fas fa-wallet"></i> Earnings</a>
                    <a href="daily-summary.php" class="btn btn-outline-light"><i class="fas fa-calendar-day"></i> Daily Summary</a>
                </div>
            </div>
            <div class="hero-side">
                <div class="hero-panel">
                    <div class="k">Completed Payouts</div>
                    <div class="v" id="heroCompletedAmount">Rs <?= number_format((float)$payload['totals']['completed_amount'], 2); ?></div>
                    <div class="t"><?= (int)$payload['totals']['completed_count']; ?> successful transfers recorded so far.</div>
                </div>
                <div class="hero-panel">
                    <div class="k">Selected View</div>
                    <div class="v" id="heroFilterLabel"><?= htmlspecialchars($payload['status_filter'], ENT_QUOTES, 'UTF-8'); ?></div>
                    <div class="t">This page will live refresh every 30 seconds to stay current.</div>
                </div>
            </div>
        </div>
    </div>

    <div class="payout-kpis">
        <div class="payout-kpi">
            <div class="payout-kpi-top">
                <span class="payout-kpi-icon icon-completed"><i class="fas fa-circle-check"></i></span>
                <span class="payout-kpi-chip">Completed</span>
            </div>
            <div class="payout-kpi-value" id="completedAmount">Rs <?= number_format((float)$payload['totals']['completed_amount'], 2); ?></div>
            <div class="payout-kpi-note" id="completedCountNote"><?= (int)$payload['totals']['completed_count']; ?> payout requests completed successfully.</div>
        </div>

        <div class="payout-kpi">
            <div class="payout-kpi-top">
                <span class="payout-kpi-icon icon-pending"><i class="fas fa-hourglass-half"></i></span>
                <span class="payout-kpi-chip">Pending</span>
            </div>
            <div class="payout-kpi-value" id="pendingAmount">Rs <?= number_format((float)$payload['totals']['pending_amount'], 2); ?></div>
            <div class="payout-kpi-note" id="pendingCountNote"><?= (int)$payload['totals']['pending_count']; ?> requests are waiting to be settled.</div>
        </div>

        <div class="payout-kpi">
            <div class="payout-kpi-top">
                <span class="payout-kpi-icon icon-failed"><i class="fas fa-triangle-exclamation"></i></span>
                <span class="payout-kpi-chip">Failed</span>
            </div>
            <div class="payout-kpi-value" id="failedCount"><?= (int)$payload['totals']['failed_count']; ?></div>
            <div class="payout-kpi-note">Transfers that did not complete successfully.</div>
        </div>

        <div class="payout-kpi">
            <div class="payout-kpi-top">
                <span class="payout-kpi-icon icon-total"><i class="fas fa-layer-group"></i></span>
                <span class="payout-kpi-chip">Visible</span>
            </div>
            <div class="payout-kpi-value" id="selectedCount"><?= (int)$payload['selected_count']; ?></div>
            <div class="payout-kpi-note">Records currently visible in the selected filter.</div>
        </div>
    </div>

    <div class="payout-layout">
        <div class="payout-panel">
            <div class="panel-head">
                <div>
                    <h5><i class="fas fa-arrow-right-arrow-left me-2 text-primary"></i>Payout Transfer Feed</h5>
                    <p>Review every rider transfer with cleaner status cards and timeline clarity.</p>
                </div>
                <div class="payout-tabs">
                    <?php foreach ($allowed_statuses as $tab): ?>
                        <a class="payout-tab <?= $status_filter === $tab ? 'active' : ''; ?>" href="?status=<?= urlencode($tab); ?>" data-status-tab="<?= htmlspecialchars($tab, ENT_QUOTES, 'UTF-8'); ?>">
                            <?= htmlspecialchars($tab, ENT_QUOTES, 'UTF-8'); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="payout-statusbar">
                <div class="payout-pill">
                    <i class="fas fa-signal"></i>
                    Auto-refresh every 30s
                </div>
                <div class="payout-pill" id="lastUpdated">
                    <i class="far fa-clock"></i>
                    Last updated: <?= htmlspecialchars($payload['generated_at'], ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>

            <div id="payoutList" class="payout-list" data-selected-status="<?= htmlspecialchars($payload['status_filter'], ENT_QUOTES, 'UTF-8'); ?>">
                <?php if (!empty($payload['payouts'])): ?>
                    <?php foreach ($payload['payouts'] as $row): ?>
                        <?php
                            $status = (string)$row['status'];
                            $date_value = strtotime($row['created_at']);
                            $status_class = $status === 'Completed' ? 'completed' : ($status === 'Pending' ? 'pending' : 'failed');
                            $status_tag = $status === 'Completed' ? 'status-completed' : ($status === 'Pending' ? 'status-pending' : 'status-failed');
                            $icon_name = $status === 'Completed' ? 'fa-check-double' : ($status === 'Pending' ? 'fa-clock' : 'fa-circle-xmark');
                        ?>
                        <article class="transfer-card">
                            <div class="transfer-left">
                                <span class="transfer-icon <?= $status_class; ?>"><i class="fas <?= $icon_name; ?>"></i></span>
                                <div class="transfer-copy">
                                    <strong><?= htmlspecialchars($row['method_label'], ENT_QUOTES, 'UTF-8'); ?> #<?= (int)$row['id']; ?></strong>
                                    <span><?= $date_value ? date('d M, Y', $date_value) : '-'; ?> &middot; <?= $date_value ? date('h:i A', $date_value) : '-'; ?></span>
                                </div>
                            </div>
                            <div class="transfer-right">
                                <strong>Rs <?= number_format((float)$row['amount'], 2); ?></strong>
                                <span class="transfer-status <?= $status_tag; ?>"><?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8'); ?></span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-building-columns fa-3x mb-3 text-muted"></i>
                        <h5 class="text-muted mb-2">No payout records found.</h5>
                        <p class="text-muted small mb-0">Your transfer history will appear here as soon as withdrawals are processed.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <aside class="insight-stack">
            <div class="payout-insight">
                <div class="insight-head">
                    <span class="insight-icon"><i class="fas fa-chart-pie"></i></span>
                    <div>
                        <h6>Payout Snapshot</h6>
                        <p>Quick dashboard-style transfer summary.</p>
                    </div>
                </div>
                <div class="mini-stat">
                    <div class="k">All Requests</div>
                    <div class="v" id="allCount"><?= (int)$payload['totals']['all_count']; ?></div>
                    <div class="t">Total payout requests ever created for this rider.</div>
                </div>
                <div class="mini-stat">
                    <div class="k">Pending Queue</div>
                    <div class="v" id="pendingCount"><?= (int)$payload['totals']['pending_count']; ?></div>
                    <div class="t">Transfers still waiting to complete or clear.</div>
                </div>
            </div>

            <div class="payout-insight">
                <div class="insight-head">
                    <span class="insight-icon"><i class="fas fa-compass"></i></span>
                    <div>
                        <h6>Current Focus</h6>
                        <p>Context for the selected payout filter.</p>
                    </div>
                </div>
                <div class="focus-banner">
                    <strong id="focusTitle"><?= $status_filter === 'All' ? 'Showing every payout request.' : 'Showing ' . htmlspecialchars($status_filter, ENT_QUOTES, 'UTF-8') . ' payout requests.'; ?></strong>
                    <span id="focusText"><?= $status_filter === 'Completed'
                        ? 'Use this view to review money already transferred to your bank.'
                        : ($status_filter === 'Pending'
                            ? 'Use this view to track payouts that are still being processed.'
                            : ($status_filter === 'Failed'
                                ? 'Use this view to inspect transfer attempts that did not go through.'
                                : 'Use this view to see the full end-to-end payout history in one place.')); ?></span>
                </div>
            </div>
        </aside>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const formatMoney = (value) => `Rs ${Number(value || 0).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;

  const escapeHtml = (value) => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const selectedCountEl = document.getElementById('selectedCount');
  const completedAmountEl = document.getElementById('completedAmount');
  const completedCountNoteEl = document.getElementById('completedCountNote');
  const pendingAmountEl = document.getElementById('pendingAmount');
  const pendingCountNoteEl = document.getElementById('pendingCountNote');
  const failedCountEl = document.getElementById('failedCount');
  const heroCompletedAmountEl = document.getElementById('heroCompletedAmount');
  const heroFilterLabelEl = document.getElementById('heroFilterLabel');
  const allCountEl = document.getElementById('allCount');
  const pendingCountEl = document.getElementById('pendingCount');
  const focusTitleEl = document.getElementById('focusTitle');
  const focusTextEl = document.getElementById('focusText');
  const payoutListEl = document.getElementById('payoutList');
  const lastUpdatedEl = document.getElementById('lastUpdated');

  const getFocusText = (status) => {
    if (status === 'Completed') return 'Use this view to review money already transferred to your bank.';
    if (status === 'Pending') return 'Use this view to track payouts that are still being processed.';
    if (status === 'Failed') return 'Use this view to inspect transfer attempts that did not go through.';
    return 'Use this view to see the full end-to-end payout history in one place.';
  };

  const getFocusTitle = (status) => {
    return status === 'All' ? 'Showing every payout request.' : `Showing ${status} payout requests.`;
  };

  const renderPayouts = (items) => {
    if (!Array.isArray(items) || items.length === 0) {
      return `
        <div class="empty-state">
          <i class="fas fa-building-columns fa-3x mb-3 text-muted"></i>
          <h5 class="text-muted mb-2">No payout records found.</h5>
          <p class="text-muted small mb-0">Your transfer history will appear here as soon as withdrawals are processed.</p>
        </div>`;
    }

    return items.map((item) => {
      const date = item.created_at ? new Date(item.created_at.replace(' ', 'T')) : null;
      const dateText = date && !Number.isNaN(date.getTime())
        ? date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
        : '-';
      const timeText = date && !Number.isNaN(date.getTime())
        ? date.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
        : '-';
      const status = item.status || '';
      const statusClass = status === 'Completed' ? 'completed' : (status === 'Pending' ? 'pending' : 'failed');
      const tagClass = status === 'Completed' ? 'status-completed' : (status === 'Pending' ? 'status-pending' : 'status-failed');
      const iconName = status === 'Completed' ? 'fa-check-double' : (status === 'Pending' ? 'fa-clock' : 'fa-circle-xmark');

      return `
        <article class="transfer-card">
          <div class="transfer-left">
            <span class="transfer-icon ${statusClass}"><i class="fas ${iconName}"></i></span>
            <div class="transfer-copy">
              <strong>${escapeHtml(item.method_label || 'Bank Transfer')} #${Number(item.id)}</strong>
              <span>${escapeHtml(dateText)} &middot; ${escapeHtml(timeText)}</span>
            </div>
          </div>
          <div class="transfer-right">
            <strong>${formatMoney(item.amount)}</strong>
            <span class="transfer-status ${tagClass}">${escapeHtml(status)}</span>
          </div>
        </article>`;
    }).join('');
  };

  const applyPayload = (payload) => {
    if (!payload || !payload.totals) return;

    payoutListEl.dataset.selectedStatus = payload.status_filter || 'All';
    payoutListEl.innerHTML = renderPayouts(payload.payouts || []);

    if (selectedCountEl) selectedCountEl.textContent = Number(payload.selected_count || 0).toLocaleString('en-IN');
    if (completedAmountEl) completedAmountEl.textContent = formatMoney(payload.totals.completed_amount);
    if (completedCountNoteEl) completedCountNoteEl.textContent = `${Number(payload.totals.completed_count || 0).toLocaleString('en-IN')} payout requests completed successfully.`;
    if (pendingAmountEl) pendingAmountEl.textContent = formatMoney(payload.totals.pending_amount);
    if (pendingCountNoteEl) pendingCountNoteEl.textContent = `${Number(payload.totals.pending_count || 0).toLocaleString('en-IN')} requests are waiting to be settled.`;
    if (failedCountEl) failedCountEl.textContent = Number(payload.totals.failed_count || 0).toLocaleString('en-IN');
    if (heroCompletedAmountEl) heroCompletedAmountEl.textContent = formatMoney(payload.totals.completed_amount);
    if (heroFilterLabelEl) heroFilterLabelEl.textContent = payload.status_filter || 'All';
    if (allCountEl) allCountEl.textContent = Number(payload.totals.all_count || 0).toLocaleString('en-IN');
    if (pendingCountEl) pendingCountEl.textContent = Number(payload.totals.pending_count || 0).toLocaleString('en-IN');
    if (focusTitleEl) focusTitleEl.textContent = getFocusTitle(payload.status_filter || 'All');
    if (focusTextEl) focusTextEl.textContent = getFocusText(payload.status_filter || 'All');
    if (lastUpdatedEl) lastUpdatedEl.innerHTML = `<i class="far fa-clock"></i> Last updated: ${escapeHtml(payload.generated_at || '')}`;
  };

  const refreshPayouts = () => {
    const selectedStatus = payoutListEl.dataset.selectedStatus || 'All';
    fetch(`payout-history.php?ajax=1&status=${encodeURIComponent(selectedStatus)}`, { cache: 'no-store' })
      .then((response) => response.ok ? response.json() : null)
      .then((payload) => {
        if (payload) applyPayload(payload);
      })
      .catch(() => {});
  };

  setInterval(refreshPayouts, 30000);
});
</script>

<?php include('includes/footer.php'); ?>
