<?php
require_once(__DIR__ . '/../config/db.php');

unset($_SESSION['delivery_id'], $_SESSION['delivery_name'], $_SESSION['delivery_role']);
unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_role']);

header('Location: auth/login.php?msg=logged_out');
exit();
?>
