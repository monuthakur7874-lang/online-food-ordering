<?php
include('includes/db-connect.php');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

if (!isset($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$csrf_token = function_exists('qb_csrf_token') ? qb_csrf_token() : ($_SESSION['csrf_token'] ?? '');
$order_id = (int)($_GET['id'] ?? 0);
$rider_id = (int)($_SESSION['user_id'] ?? 0);

if ($order_id <= 0 || $rider_id <= 0) {
    header("Location: dashboard.php");
    exit();
}

$query = "SELECT o.*, u.name as c_name, u.phone as c_phone, u.email as c_email
          FROM orders o
          JOIN users u ON o.user_id = u.id
          WHERE o.id = {$order_id} AND o.rider_id = {$rider_id}
          LIMIT 1";
$res = mysqli_query($conn, $query);
$order = $res ? mysqli_fetch_assoc($res) : null;

$delivery_page_title = 'Order Details - Rider Panel';
include('includes/header.php');

if (!$order) {
    echo "<div class='container mt-5 text-center'><h4 class='text-muted'>Order not found!</h4></div>";
    include('includes/footer.php');
    exit();
}

$order_status = (string)($order['order_status'] ?? '');
$payment_mode = (string)($order['payment_mode'] ?? '');
$payment_status = (string)($order['payment_status'] ?? '');
$is_cod_order = ($payment_mode === 'COD');
$is_cod_pending = $is_cod_order && ($payment_status !== 'Paid');
$collect_amount = $is_cod_order ? (float)($order['total_amount'] ?? 0) : 0.0;

$is_online = false;
if (isset($rider_is_online)) {
    $is_online = ((string)$rider_is_online === 'Yes');
} else {
    $res_on = mysqli_query($conn, "SELECT is_online FROM users WHERE id={$rider_id} AND role='delivery' LIMIT 1");
    if ($res_on) {
        $row_on = mysqli_fetch_assoc($res_on);
        $is_online = ((string)($row_on['is_online'] ?? 'No') === 'Yes');
    }
}

$step = 0;
if ($order_status === 'Confirmed') $step = 1;
elseif ($order_status === 'On the Way') $step = 2;
elseif ($order_status === 'Delivered') $step = 3;
$is_cancelled = ($order_status === 'Cancelled');
?>

<style>
  :root { --od-accent: #e23744; --od-accent-soft: #ff7e8b; --od-dark: #231f20; }

  .detail-header {
    background:
      radial-gradient(900px 500px at 15% 15%, rgba(226,55,68,0.24), transparent 60%),
      radial-gradient(700px 420px at 85% 0%, rgba(251,146,60,0.22), transparent 60%),
      linear-gradient(135deg, #231f20 0%, #7f1d3b 55%, #e23744 100%);
    color: white;
    padding: 42px 20px 54px;
    border-radius: 22px;
    border: 1px solid rgba(255,255,255,0.08);
    box-shadow: 0 22px 48px rgba(226,55,68,0.16);
  }

  .detail-header .ord-pill {
    background: rgba(255,255,255,0.92);
    border: 1px solid rgba(15,23,42,0.12);
    color: #0f172a;
    border-radius: 999px;
    padding: 6px 12px;
    font-weight: 800;
    font-size: 12px;
  }

  .info-card {
    background: white;
    border-radius: 22px;
    border: 1px solid rgba(0,0,0,0.05);
    box-shadow: 0 18px 44px rgba(15,23,42,0.10);
    overflow: hidden;
  }

  .floating-nav-btn {
    background: var(--od-accent);
    color: white;
    width: 52px; height: 52px;
    border-radius: 16px;
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 14px 26px rgba(226,55,68,0.24);
    text-decoration: none;
    border: 1px solid rgba(255,255,255,0.2);
  }
  .floating-nav-btn:hover { color: white; transform: translateY(-2px); }

  .od-stepper { display:flex; gap:10px; justify-content:center; margin-top: 14px; flex-wrap:wrap; }
  .od-step { display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius: 16px; background: rgba(255,255,255,0.10); border: 1px solid rgba(255,255,255,0.12); min-width: 210px; }
  .od-dot { width: 12px; height: 12px; border-radius: 999px; background: rgba(255,255,255,0.30); box-shadow: 0 0 0 0 rgba(34,197,94,0); }
  .od-step.done .od-dot { background: #22c55e; box-shadow: 0 0 0 8px rgba(34,197,94,0.12); }
  .od-step.curr { background: rgba(34,197,94,0.12); border-color: rgba(34,197,94,0.22); }
  .od-step.curr .od-dot { background: #22c55e; box-shadow: 0 0 0 10px rgba(34,197,94,0.16); }
  .od-step .t { font-weight: 800; font-size: 12px; letter-spacing: 0.7px; text-transform: uppercase; color: rgba(255,255,255,0.88); }
  .od-step .s { font-size: 11px; color: rgba(229,231,235,0.76); margin-top: 2px; }

  .od-items .rowline { padding: 12px 0; border-bottom: 1px dashed rgba(15,23,42,0.12); }
  .od-items .rowline:last-child { border-bottom: none; }

  .od-total {
    background: linear-gradient(135deg, rgba(226,55,68,0.08) 0%, rgba(251,146,60,0.08) 100%);
    border-top: 1px solid rgba(15,23,42,0.08);
  }

  .btn-cta {
    border: none !important;
    border-radius: 18px !important;
    font-weight: 900 !important;
    letter-spacing: 0.6px;
    padding: 14px 16px !important;
    box-shadow: 0 16px 34px rgba(15,23,42,0.14) !important;
  }
  .btn-cta.primary { background: linear-gradient(135deg, #e23744 0%, #ff7e8b 100%) !important; }
  .btn-cta.success { background: linear-gradient(135deg, #10b981 0%, #22c55e 100%) !important; }
  .btn-cta:disabled { filter: grayscale(0.4); opacity: 0.65; box-shadow: none !important; }

  .cod-collect-card {
    background: linear-gradient(135deg, #fff7ed 0%, #fef3c7 100%);
    border: 1px solid rgba(245,158,11,0.26);
    border-radius: 18px;
    padding: 14px 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    color: #78350f;
  }
  .cod-collect-card .cod-title { font-weight: 900; letter-spacing: 0.2px; }
  .cod-collect-card .cod-amount { font-weight: 900; font-size: 22px; color: #111827; white-space: nowrap; }

  .bg-success-soft { background-color: #ecfdf5; color: #10b981; }

  .card.info-card,
  .card.border-0.shadow-sm.rounded-4 {
    border-radius: 24px !important;
    border: 1px solid rgba(226,55,68,0.08) !important;
    box-shadow: 0 18px 38px rgba(15,23,42,0.06) !important;
  }
</style>

<div class="detail-header mb-4">
  <div class="d-flex justify-content-between align-items-center">
    <a href="dashboard.php" class="text-white text-decoration-none"><i class="fas fa-chevron-left me-2"></i> Back</a>
    <span class="ord-pill">#<?php echo qb_order_display_id((int)$order['id']); ?></span>
  </div>
  <div class="text-center mt-3">
    <h3 class="fw-bold mb-1"><?php echo htmlspecialchars((string)$order['c_name']); ?></h3>
    <p class="opacity-75 small mb-0"><i class="fas fa-clock me-1"></i> Received: <?php echo date('d M, h:i A', strtotime((string)$order['order_date'])); ?></p>

    <div class="od-stepper">
      <div class="od-step <?php echo ($step >= 1) ? 'done' : ''; ?> <?php echo ($step === 1) ? 'curr' : ''; ?>">
        <div class="od-dot"></div>
        <div><div class="t">Assigned</div><div class="s">Order confirmed for pickup</div></div>
      </div>
      <div class="od-step <?php echo ($step >= 2) ? 'done' : ''; ?> <?php echo ($step === 2) ? 'curr' : ''; ?>">
        <div class="od-dot"></div>
        <div><div class="t">On The Way</div><div class="s">Rider started delivery</div></div>
      </div>
      <div class="od-step <?php echo ($step >= 3) ? 'done' : ''; ?> <?php echo ($step === 3) ? 'curr' : ''; ?>">
        <div class="od-dot"></div>
        <div><div class="t">Delivered</div><div class="s">Successfully completed</div></div>
      </div>
    </div>
  </div>
</div>

<div class="card info-card p-4 mb-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h6 class="text-muted small fw-bold mb-1">DELIVERY ADDRESS</h6>
      <p class="fw-bold text-dark mb-0"><?php echo htmlspecialchars((string)$order['delivery_address']); ?></p>
      <div class="text-muted small mt-1">
        <i class="fas fa-credit-card me-1"></i>
        <?php echo htmlspecialchars($payment_mode ?: '-'); ?> -
        <?php echo $is_cod_order ? ($is_cod_pending ? 'Collect COD' : 'Cash Paid') : 'Paid Online'; ?>
      </div>
    </div>
    <a
      href="https://www.google.com/maps/search/?api=1&query=<?php echo urlencode((string)$order['delivery_address']); ?>"
      target="_blank"
      class="floating-nav-btn"
      title="Open in Google Maps"
    >
      <i class="fas fa-directions fa-lg"></i>
    </a>
  </div>

  <div class="d-grid mt-2">
    <a href="tel:<?php echo preg_replace('/[^0-9]/', '', (string)$order['c_phone']); ?>" class="btn btn-success btn-lg rounded-4 fw-bold">
      <i class="fas fa-phone-alt me-2"></i> Call Customer
    </a>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-4 mb-4">
  <div class="card-header bg-white py-3 border-0">
    <h6 class="fw-bold mb-0"><i class="fas fa-utensils text-primary me-2"></i> Order Items</h6>
  </div>
  <div class="card-body pt-0 od-items">
    <?php
    $items_total = 0.0;
    $items_query = "SELECT oi.quantity, oi.price, f.title as food_name
                    FROM order_items oi
                    LEFT JOIN foods f ON oi.food_id = f.id
                    WHERE oi.order_id = {$order_id}";
    $items_res = mysqli_query($conn, $items_query);
    if ($items_res && mysqli_num_rows($items_res) > 0):
        while ($item = mysqli_fetch_assoc($items_res)):
            $qty = (int)($item['quantity'] ?? 0);
            $unit = (float)($item['price'] ?? 0);
            $line = $qty * $unit;
            $items_total += $line;
    ?>
      <div class="rowline d-flex justify-content-between align-items-start">
        <div>
          <div class="fw-bold text-dark"><?php echo htmlspecialchars((string)($item['food_name'] ?? 'Item')); ?></div>
          <div class="text-muted small">Qty: <b><?php echo $qty; ?></b> • Unit: <b>&#8377;<?php echo number_format($unit, 2); ?></b></div>
        </div>
        <div class="text-end">
          <div class="fw-bold text-dark">&#8377;<?php echo number_format($line, 2); ?></div>
        </div>
      </div>
    <?php
        endwhile;
    else:
        echo "<div class='text-muted small py-3'>No items found for this order.</div>";
    endif;
    ?>
  </div>
  <div class="card-footer od-total border-0 py-3 rounded-bottom-4">
    <div class="d-flex justify-content-between align-items-center mb-1">
      <span class="text-muted fw-bold">Items Total</span>
      <span class="fw-bold text-dark">&#8377;<?php echo number_format($items_total, 2); ?></span>
    </div>
    <div class="d-flex justify-content-between align-items-center mb-1">
      <span class="text-muted fw-bold">Delivery</span>
      <span class="fw-bold text-dark">&#8377;<?php echo number_format(max(0, (float)$order['total_amount'] - $items_total), 2); ?></span>
    </div>
    <div class="d-flex justify-content-between align-items-center pt-2 border-top">
      <span class="text-muted fw-bold"><?php echo $is_cod_order ? ($is_cod_pending ? 'To Collect (COD)' : 'Cash Paid') : 'Paid'; ?></span>
      <h4 class="fw-bold <?php echo $is_cod_pending ? 'text-primary' : 'text-success'; ?> mb-0">&#8377;<?php echo number_format($is_cod_order ? $collect_amount : (float)$order['total_amount'], 2); ?></h4>
    </div>
  </div>
</div>

<div class="card border-0 shadow-sm rounded-4 mb-5">
  <div class="card-body" id="orderStatusControl" data-order-status="<?php echo htmlspecialchars($order_status, ENT_QUOTES, 'UTF-8'); ?>">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <h6 class="fw-bold mb-0">Order Status Control</h6>
      <span id="orderDutyBadge" class="badge rounded-pill <?php echo $is_online ? 'bg-success' : 'bg-secondary'; ?>">
        <?php echo $is_online ? 'Online' : 'Offline'; ?>
      </span>
    </div>

    <?php if ($order_status === 'Confirmed' || $order_status === 'On the Way'): ?>
      <div id="orderDutyAlert" class="alert alert-secondary border-0 rounded-4 small mb-3 <?php echo $is_online ? 'd-none' : ''; ?>">
        <i class="fas fa-toggle-off me-1"></i> Go <b>Online</b> to update status and share live location.
      </div>
    <?php endif; ?>

    <?php if ($order_status === 'Confirmed'): ?>
      <div class="alert alert-warning border-0 rounded-4 small">
        <i class="fas fa-info-circle me-1"></i> Reach the restaurant and pick up the order to start navigation.
      </div>
      <form action="update-status.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
        <input type="hidden" name="new_status" value="On the Way">
        <button type="submit" id="orderStatusSubmitBtn" class="btn btn-primary btn-lg w-100 btn-cta primary" <?php echo $is_online ? '' : 'disabled'; ?>>
          <i class="fas fa-box-open me-2"></i> CONFIRM PICKUP
        </button>
      </form>
      <form action="reject-order.php" method="POST" class="mt-3">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
        <button type="submit" class="btn btn-outline-danger w-100 rounded-4 fw-bold py-3">
          <i class="fas fa-xmark me-2"></i> CANCEL THIS ORDER
        </button>
      </form>
    <?php elseif ($order_status === 'On the Way'): ?>
      <div class="alert alert-info border-0 rounded-4 small">
        <i class="fas fa-motorcycle me-1"></i> You are currently delivering this order. Use the map for help.
      </div>
      <?php if ($is_cod_pending): ?>
        <div class="cod-collect-card mb-3">
          <div>
            <div class="cod-title"><i class="fas fa-hand-holding-dollar me-2"></i>Collect Cash Before Delivery</div>
            <div class="small">Cash on delivery order. Confirm delivery only after collecting cash from the customer.</div>
          </div>
          <div class="cod-amount">&#8377;<?php echo number_format($collect_amount, 2); ?></div>
        </div>
      <?php endif; ?>
      <form action="update-status.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
        <input type="hidden" name="new_status" value="Delivered">
        <button
          type="submit"
          id="orderStatusSubmitBtn"
          class="btn btn-success btn-lg w-100 btn-cta success"
          <?php echo $is_online ? '' : 'disabled'; ?>
          <?php echo $is_cod_pending ? 'data-cod-confirm="1"' : ''; ?>
        >
          <i class="fas fa-check-circle me-2"></i> <?php echo $is_cod_pending ? 'COLLECT CASH & MARK AS DELIVERED' : 'MARK AS DELIVERED'; ?>
        </button>
      </form>
      <form action="reject-order.php" method="POST" class="mt-3">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
        <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
        <button type="submit" class="btn btn-outline-danger w-100 rounded-4 fw-bold py-3">
          <i class="fas fa-xmark me-2"></i> CANCEL DELIVERY
        </button>
      </form>
    <?php elseif ($is_cancelled): ?>
      <div class="text-center py-2">
        <span class="badge bg-danger px-4 py-2 rounded-pill">
          <i class="fas fa-ban me-1"></i> ORDER CANCELLED
        </span>
      </div>
    <?php else: ?>
      <div class="text-center py-2">
        <span class="badge bg-success-soft text-success px-4 py-2 rounded-pill">
          <i class="fas fa-check-double me-1"></i> ORDER COMPLETED
        </span>
      </div>
    <?php endif; ?>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const dutyToggle = document.getElementById('dutyToggle');
  const dutyBadge = document.getElementById('orderDutyBadge');
  const dutyAlert = document.getElementById('orderDutyAlert');
  const submitBtn = document.getElementById('orderStatusSubmitBtn');
  if (!dutyToggle || !dutyBadge) return;

  const syncOrderDutyUi = () => {
    const isOnline = !!dutyToggle.checked;
    dutyBadge.textContent = isOnline ? 'Online' : 'Offline';
    dutyBadge.classList.toggle('bg-success', isOnline);
    dutyBadge.classList.toggle('bg-secondary', !isOnline);

    if (dutyAlert) {
      dutyAlert.classList.toggle('d-none', isOnline);
    }

    if (submitBtn) {
      submitBtn.disabled = !isOnline;
    }
  };

  syncOrderDutyUi();
  dutyToggle.addEventListener('change', syncOrderDutyUi);
  document.addEventListener('delivery-duty-updated', syncOrderDutyUi);

  const statusForm = submitBtn ? submitBtn.closest('form') : null;
  if (statusForm && submitBtn && submitBtn.dataset.codConfirm === '1') {
    statusForm.addEventListener('submit', (event) => {
      const ok = window.confirm('Cash collect kar liya hai? OK dabane par order delivered aur payment paid mark ho jayega.');
      if (!ok) {
        event.preventDefault();
      }
    });
  }
});
</script>

<?php include('includes/footer.php'); ?>
