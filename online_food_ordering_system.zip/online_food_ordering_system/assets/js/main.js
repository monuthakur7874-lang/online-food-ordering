/**
 * QuickBite - Custom Interactive Scripts
 * Handling UI animations, Cart updates, and Form Validations
 */

document.addEventListener("DOMContentLoaded", function() {
    "use strict";

    // 1. Navbar Scroll Effect: Scroll karne par navbar ka background change hoga
    const navbar = document.querySelector(".navbar");
    window.addEventListener("scroll", () => {
        if (window.scrollY > 50) {
            navbar.classList.add("shadow-sm", "bg-white", "navbar-scrolled");
        } else {
            navbar.classList.remove("shadow-sm", "bg-white", "navbar-scrolled");
        }
    });

    // 2. Quantity Change Auto-Submit: Cart mein quantity badalte hi page refresh
    const qtyInputs = document.querySelectorAll(".qty-input");
    qtyInputs.forEach(input => {
        input.addEventListener("change", function() {
            this.form.submit();
        });
    });

    // 3. Smooth Scroll for Anchor Links (Menu section ke liye)
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if(target) {
                target.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // 4. Cart Add Notification (Simple Alert or Toast)
    const addBtns = document.querySelectorAll(".btn-add-cart");
    addBtns.forEach(btn => {
        btn.addEventListener("click", function() {
            // Aap yahan Toast notification logic daal sakte hain
            console.log("Item added to cart logic triggered");
        });
    });

    // 5. Checkout Form Validation
    const checkoutForm = document.getElementById("checkoutForm");
    if(checkoutForm) {
        checkoutForm.addEventListener("submit", function(e) {
            const address = document.getElementsByName("delivery_address")[0].value;
            if(address.length < 10) {
                e.preventDefault();
                alert("Please provide a complete delivery address for faster delivery.");
            }
        });
    }
});

// 6. Delete Confirmation Logic (Orders ya Cart Items ke liye)
function confirmDelete(message = "Are you sure you want to remove this?") {
    return confirm(message);
}