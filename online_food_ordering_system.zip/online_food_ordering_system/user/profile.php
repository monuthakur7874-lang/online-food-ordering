<?php
/**
 * QuickBite - User Profile & Settings
 * File: user/profile.php
 */
require_once(__DIR__ . '/../config/db.php');
require_once(__DIR__ . '/includes/csrf.php');

// Security: Check if user is logged in (must be before any HTML output)
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$msg = "";

// 1. Update Profile Logic
if (isset($_POST['update_profile'])) {
    if (!qb_csrf_validate((string)($_POST['csrf_token'] ?? ''))) {
        $msg = "<div class='alert alert-danger border-0 rounded-4 small py-2 shadow-sm'>Security check failed. Please refresh and try again.</div>";
    } else {
        $name = trim((string)($_POST['name'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));
        $address = trim((string)($_POST['address'] ?? ''));

        if ($name === '' || $phone === '' || $address === '') {
            $msg = "<div class='alert alert-warning border-0 rounded-4 small py-2 shadow-sm'>All fields are required.</div>";
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE users SET name=?, phone=?, address=? WHERE id=?");
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "sssi", $name, $phone, $address, $user_id);
                if (mysqli_stmt_execute($stmt)) {
                    $_SESSION['user_name'] = $name;
                    $msg = "<div class='alert alert-success border-0 rounded-4 small py-2 shadow-sm'><i class='fas fa-check-circle me-2'></i>Profile Updated Successfully!</div>";
                }
                mysqli_stmt_close($stmt);
            }
        }
    }
}

// 2. Update Password Logic (Bcrypt Hash)
if (isset($_POST['update_password'])) {
    if (!qb_csrf_validate((string)($_POST['csrf_token'] ?? ''))) {
        $msg = "<div class='alert alert-danger border-0 rounded-4 small py-2 shadow-sm'>Security check failed. Please refresh and try again.</div>";
    } else {
        $current_pass_input = (string)($_POST['current_pass'] ?? '');
        $new_pass = (string)($_POST['new_pass'] ?? '');
        $conf_pass = (string)($_POST['conf_pass'] ?? '');

        $db_hashed_pass = null;
        $stmt = mysqli_prepare($conn, "SELECT password FROM users WHERE id=? LIMIT 1");
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $db_hashed_pass);
            mysqli_stmt_fetch($stmt);
            mysqli_stmt_close($stmt);
        }

        if (is_string($db_hashed_pass) && password_verify($current_pass_input, $db_hashed_pass)) {
            if (strlen($new_pass) < 6) {
                $msg = "<div class='alert alert-warning border-0 rounded-4 small py-2 shadow-sm'><i class='fas fa-exclamation-circle me-2'></i>New password must be at least 6 characters!</div>";
            } elseif ($new_pass === $conf_pass) {
                $new_hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
                $stmt = mysqli_prepare($conn, "UPDATE users SET password=? WHERE id=?");
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "si", $new_hashed_pass, $user_id);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
                $msg = "<div class='alert alert-success border-0 rounded-4 small py-2 shadow-sm'><i class='fas fa-key me-2'></i>Password Updated Successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger border-0 rounded-4 small py-2 shadow-sm'><i class='fas fa-exclamation-triangle me-2'></i>New passwords do not match!</div>";
            }
        } else {
            $msg = "<div class='alert alert-danger border-0 rounded-4 small py-2 shadow-sm'><i class='fas fa-lock me-2'></i>Current Password is incorrect!</div>";
        }
    }
}

// 3. Fetch User Data
$user = null;
$stmt = mysqli_prepare($conn, "SELECT id, name, email, phone, address FROM users WHERE id=? LIMIT 1");
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $uid, $uname, $uemail, $uphone, $uaddress);
    if (mysqli_stmt_fetch($stmt)) {
        $user = [
            'id' => (int)$uid,
            'name' => (string)$uname,
            'email' => (string)$uemail,
            'phone' => (string)$uphone,
            'address' => (string)$uaddress,
        ];
    }
    mysqli_stmt_close($stmt);
}
if (!$user) {
    header("Location: auth/logout.php");
    exit();
}

// 4. Count Total Orders
$order_total = 0;
$stmt = mysqli_prepare($conn, "SELECT COUNT(id) AS total FROM orders WHERE user_id=?");
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $order_total);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);
}

include('includes/header.php');
$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
?>

<div class="container mt-5 mb-5">
    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card border-0 shadow-sm rounded-5 p-4 text-center h-100 overflow-hidden">
                <div class="mb-3">
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['name']); ?>&size=128&background=ff4757&color=fff" 
                         class="rounded-circle shadow-sm border border-4 border-white" width="120">
                </div>
                <h4 class="fw-bold mb-1"><?php echo $h($user['name']); ?></h4>
                <p class="text-muted small mb-4"><?php echo $h($user['email']); ?></p>
                
                <div class="row g-2 mb-4">
                    <div class="col-6">
                        <div class="bg-light p-3 rounded-4">
                            <h5 class="fw-bold mb-0 text-danger"><?php echo (int)$order_total; ?></h5>
                            <small class="text-muted">Orders</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="bg-light p-3 rounded-4">
                            <h5 class="fw-bold mb-0 text-success">Active</h5>
                            <small class="text-muted">Status</small>
                        </div>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <a href="my-orders.php" class="btn btn-light rounded-pill fw-bold py-2 border">
                        <i class="fas fa-shopping-bag me-2"></i>My Orders
                    </a>
                    <a href="auth/logout.php" class="btn btn-outline-danger rounded-pill fw-bold py-2">
                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="mb-4">
                <?php echo $msg; ?>
            </div>

            <div class="card border-0 shadow-sm rounded-5 p-4 p-md-5 mb-4">
                <div class="d-flex align-items-center mb-4">
                    <div class="icon-box bg-light-danger text-danger rounded-3 p-2 me-3">
                        <i class="fas fa-user-edit"></i>
                    </div>
                    <h4 class="fw-bold mb-0">Personal Information</h4>
                </div>
                
                <form action="" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo $h($qb_csrf_token); ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold text-muted">Full Name</label>
                            <input type="text" name="name" class="form-control rounded-3 py-2" value="<?php echo $h($user['name']); ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold text-muted">Phone Number</label>
                            <input type="text" name="phone" class="form-control rounded-3 py-2" value="<?php echo $h($user['phone']); ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">Email Address (Read Only)</label>
                        <input type="email" class="form-control rounded-3 bg-light py-2" value="<?php echo $h($user['email']); ?>" readonly>
                    </div>
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-muted">Primary Delivery Address</label>
                        <textarea name="address" class="form-control rounded-3" rows="3" required><?php echo $h($user['address']); ?></textarea>
                    </div>
                    <button type="submit" name="update_profile" class="btn btn-danger px-5 py-2 rounded-pill fw-bold shadow-sm">
                        UPDATE PROFILE
                    </button>
                </form>
            </div>

            <div class="card border-0 shadow-sm rounded-5 p-4 p-md-5" id="change-password">
                <div class="d-flex align-items-center mb-4">
                    <div class="icon-box bg-light-warning text-warning rounded-3 p-2 me-3">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h4 class="fw-bold mb-0">Change Password</h4>
                </div>
                
                <form action="" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo $h($qb_csrf_token); ?>">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted">Current Password</label>
                        <input type="password" name="current_pass" class="form-control rounded-3 py-2" placeholder="Enter current password" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold text-muted">New Password</label>
                            <input type="password" name="new_pass" class="form-control rounded-3 py-2" placeholder="Min. 6 characters" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold text-muted">Confirm New Password</label>
                            <input type="password" name="conf_pass" class="form-control rounded-3 py-2" placeholder="Confirm new password" required>
                        </div>
                    </div>
                    <button type="submit" name="update_password" class="btn btn-dark px-5 py-2 rounded-pill fw-bold shadow-sm">
                        UPDATE PASSWORD
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .bg-light-danger { background-color: #fff5f5; }
    .bg-light-warning { background-color: #fffaf0; }
    .icon-box { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; }
    .form-control:focus {
        border-color: #ff4757;
        box-shadow: 0 0 0 0.25rem rgba(255, 71, 87, 0.1);
    }
</style>

<?php include('includes/footer.php'); ?>
