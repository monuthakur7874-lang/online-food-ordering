<?php
/**
 * QuickBite - Payment Gateway (UI + simple validation)
 * File: user/payment-gateway.php
 *
 * Note: This project uses a simulated payment flow (no real gateway API).
 * It validates inputs and then marks order as Paid/Failed in DB.
 * For a real gateway (Razorpay/Paytm/PhonePe), add server-side API integration.
 */

require_once(__DIR__ . '/../config/db.php');
require_once(__DIR__ . '/includes/csrf.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$order_id = (int)($_GET['order_id'] ?? 0);
if ($order_id <= 0) {
    header("Location: index.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$is_test_mode = isset($_GET['test']) && $_GET['test'] === '1';

$total_amount = 0.0;
$payment_mode = '';
$order_user_id = 0;
$payment_status = 'Pending';

$stmt = mysqli_prepare($conn, "SELECT total_amount, payment_mode, user_id, payment_status FROM orders WHERE id = ? LIMIT 1");
if (!$stmt) {
    header("Location: index.php");
    exit();
}
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $total_amount, $payment_mode, $order_user_id, $payment_status);
$found = mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

if (!$found || (int)$order_user_id !== $user_id) {
    header("Location: index.php");
    exit();
}

if ($payment_mode !== 'Online') {
    header("Location: order-success.php?order_id=$order_id&status=cod");
    exit();
}

if ($payment_status === 'Paid') {
    header("Location: order-success.php?order_id=$order_id&status=paid");
    exit();
}

$amount = (float)$total_amount;
$error = '';
$selected_method = 'upi';

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function posted_value(string $key, string $default = ''): string {
    return isset($_POST[$key]) ? trim((string)$_POST[$key]) : $default;
}

function normalize_digits(string $v): string {
    return preg_replace('/\\D+/', '', $v);
}

function is_valid_upi_id(string $upi): bool {
    // Simple UPI ID check: name@bank
    return (bool)preg_match('/^[a-zA-Z0-9.\\-_]{2,}@[a-zA-Z]{2,}$/', $upi);
}

function is_valid_card_number_len(string $number): bool {
    // Dummy validation: allow any digits (12-19). No Luhn check (user wants any dummy card number).
    $digits = preg_replace('/\\D+/', '', $number);
    if ($digits === '') return false;
    $len = strlen($digits);
    return ($len >= 12 && $len <= 19);
}

function is_valid_expiry(string $exp): bool {
    $exp = trim($exp);
    if (!preg_match('/^(0[1-9]|1[0-2])\\s*\\/\\s*([0-9]{2}|[0-9]{4})$/', $exp, $m)) return false;
    $mm = (int)$m[1];
    $yy = (int)$m[2];
    if ($yy < 100) $yy += 2000;
    $nowY = (int)date('Y');
    $nowM = (int)date('n');
    if ($yy < $nowY) return false;
    if ($yy === $nowY && $mm < $nowM) return false;
    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_now'])) {
    $selected_method = (string)($_POST['method'] ?? 'upi');

    if (!qb_csrf_validate((string)($_POST['csrf_token'] ?? ''))) {
        $error = 'Security check failed. Please refresh and try again.';
    } else {
        $method = $selected_method;

        if (!in_array($method, ['upi', 'wallet', 'card'], true)) {
            $error = 'Please select a payment method.';
        } else {
            // Input validation per method
            if ($method === 'upi') {
                $upi_id = trim((string)($_POST['upi_id'] ?? ''));
                if ($upi_id === '' || !is_valid_upi_id($upi_id)) {
                    $error = 'Please enter a valid UPI ID (example: name@upi).';
                }
            } elseif ($method === 'wallet') {
                $wallet_provider = (string)($_POST['wallet_provider'] ?? '');
                $wallet_mobile = normalize_digits((string)($_POST['wallet_mobile'] ?? ''));
                if (!in_array($wallet_provider, ['Paytm', 'PhonePe'], true)) {
                    $error = 'Please choose a wallet provider.';
                } elseif (strlen($wallet_mobile) !== 10) {
                    $error = 'Please enter a valid mobile number for wallet payment.';
                }
            } else { // card
                $card_name = trim((string)($_POST['card_name'] ?? ''));
                $card_no = (string)($_POST['card_no'] ?? '');
                $card_exp = (string)($_POST['card_exp'] ?? '');
                $card_cvv = normalize_digits((string)($_POST['card_cvv'] ?? ''));
                if ($card_name === '' || strlen($card_name) < 2) {
                    $error = 'Please enter cardholder name.';
                } elseif (!is_valid_card_number_len($card_no)) {
                    $error = 'Please enter a card number (12 to 19 digits).';
                } elseif (!is_valid_expiry($card_exp)) {
                    $error = 'Please enter a valid expiry (MM/YY).';
                } elseif ($card_cvv === '' || (strlen($card_cvv) !== 3 && strlen($card_cvv) !== 4)) {
                    $error = 'Please enter a valid CVV.';
                }
            }

            if ($error === '') {
                $simulate = $is_test_mode ? (string)($_POST['simulate'] ?? 'success') : 'success';
                if (!in_array($simulate, ['success', 'fail'], true)) $simulate = 'success';

                $prefix = ($method === 'upi') ? 'UPI' : (($method === 'wallet') ? 'WAL' : 'CRD');
                $txn = $prefix . '-' . strtoupper(bin2hex(random_bytes(6)));
                $reference_no = (string)random_int(100000000000, 999999999999);
                $app_label = '';
                $reference_label = 'Reference No';

                if ($method === 'upi') {
                    $app_label = trim((string)($_POST['upi_app'] ?? 'UPI'));
                    $reference_label = 'UPI Ref No';
                } elseif ($method === 'wallet') {
                    $app_label = trim((string)($_POST['wallet_provider'] ?? 'Wallet'));
                    $reference_label = 'Wallet Ref No';
                } else {
                    $app_label = 'Card';
                    $reference_label = 'Card Auth No';
                }

                if ($simulate === 'fail') {
                    $stmt = mysqli_prepare($conn, "UPDATE orders SET payment_status='Failed', transaction_id=? WHERE id=? AND user_id=? AND payment_mode='Online'");
                    if ($stmt) {
                        mysqli_stmt_bind_param($stmt, "sii", $txn, $order_id, $user_id);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }
                    header("Location: order-success.php?order_id=$order_id&status=failed");
                    exit();
                }

                $stmt = mysqli_prepare($conn, "UPDATE orders SET payment_status='Paid', transaction_id=?, order_status='Confirmed' WHERE id=? AND user_id=? AND payment_mode='Online'");
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "sii", $txn, $order_id, $user_id);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }

                $_SESSION['payment_success'][$order_id] = [
                    'txn_id' => $txn,
                    'reference_no' => $reference_no,
                    'reference_label' => $reference_label,
                    'payment_status' => 'Paid',
                    'payment_method' => strtoupper($app_label !== '' ? $app_label : $method),
                    'amount' => $amount,
                    'order_id' => $order_id,
                ];

                header("Location: payment-success.php?order_id=$order_id");
                exit();
            }
        }
    }
}

$csrf = qb_csrf_token();
$upi_app_value = posted_value('upi_app', 'Paytm');
$upi_id_value = posted_value('upi_id');
$wallet_provider_value = posted_value('wallet_provider', 'Paytm');
$wallet_mobile_value = posted_value('wallet_mobile');
$card_name_value = posted_value('card_name');
$card_no_value = posted_value('card_no');
$card_exp_value = posted_value('card_exp');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Gateway | Food Monu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --qb-red: #ff4757; --qb-dark: #2f3542; --qb-slate: #6b7280; }
        body {
            background: radial-gradient(1200px 600px at 20% 10%, rgba(255, 71, 87, 0.12), transparent 55%),
                        radial-gradient(900px 450px at 85% 25%, rgba(47, 53, 66, 0.10), transparent 55%),
                        #f4f5f7;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial;
        }
        .payment-shell { width: min(940px, 94vw); }
        .pay-card {
            background: rgba(255,255,255,0.92);
            border-radius: 30px;
            box-shadow: 0 26px 60px rgba(17, 24, 39, 0.12);
            border: 1px solid rgba(0,0,0,0.06);
            overflow: hidden;
        }
        .pay-left {
            background:
                linear-gradient(160deg, rgba(255,71,87,0.16), rgba(255,255,255,0.0)),
                linear-gradient(180deg, rgba(255,255,255,0.88), rgba(255,248,248,0.94));
            border-right: 1px solid rgba(0,0,0,0.06);
        }
        .brand {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            font-weight: 800;
            color: #18212f;
            letter-spacing: 0.2px;
            font-size: 1.45rem;
        }
        .brand-mark {
            width: 42px;
            height: 42px;
            border-radius: 14px;
            background: linear-gradient(135deg, #ff4757, #ff7b72);
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 12px 22px rgba(255, 71, 87, 0.22);
        }
        .brand-copy {
            display: flex;
            flex-direction: column;
            line-height: 1.05;
        }
        .brand-copy small {
            font-size: 0.72rem;
            font-weight: 700;
            color: var(--qb-slate);
            text-transform: uppercase;
            letter-spacing: 0.12em;
        }
        .chip {
            display: inline-flex; align-items: center; gap: 8px;
            padding: 9px 14px; border-radius: 999px;
            border: 1px solid rgba(0,0,0,0.08);
            background: rgba(255,255,255,0.86);
            backdrop-filter: blur(8px);
            font-weight: 700;
            color: #111827;
        }
        .chip i { color: var(--qb-red); }
        .panel-label {
            font-size: 0.78rem;
            font-weight: 800;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: var(--qb-slate);
            margin-bottom: 4px;
        }
        .amount-block {
            background: rgba(255,255,255,0.76);
            border: 1px solid rgba(255,255,255,0.72);
            border-radius: 24px;
            padding: 18px 18px 16px;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.75);
        }
        .amount-value {
            font-size: clamp(2.1rem, 5vw, 3rem);
            font-weight: 800;
            color: #18212f;
            line-height: 1;
        }
        .method-card {
            border: 1px solid rgba(17,24,39,0.08);
            border-radius: 22px;
            padding: 18px 16px;
            cursor: pointer;
            transition: 0.2s ease;
            background: linear-gradient(180deg, #ffffff, #fcfcfd);
        }
        .method-card:hover { transform: translateY(-1px); box-shadow: 0 16px 32px rgba(17,24,39,0.07); }
        .method-card.active {
            border-color: rgba(255,71,87,0.42);
            box-shadow: 0 18px 35px rgba(255,71,87,0.10);
            background: linear-gradient(180deg, rgba(255,255,255,1), rgba(255,245,246,0.95));
        }
        .method-icon {
            width: 42px;
            height: 42px;
            border-radius: 14px;
            background: #fff4f4;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }
        .btn-pay {
            background: linear-gradient(135deg, #ff4757, #ff5f6d);
            border: none;
            box-shadow: 0 18px 36px rgba(255, 71, 87, 0.24);
        }
        .btn-pay:hover { background: linear-gradient(135deg, #ff3f50, #ff6573); }
        .muted { color: rgba(47,53,66,0.72); }
        .mono { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace; }
        .qb-card {
            border: 1px solid rgba(17,24,39,0.07);
            border-radius: 24px;
            padding: 18px;
            background: rgba(255,255,255,0.90);
            box-shadow: 0 16px 28px rgba(17,24,39,0.05);
        }
        .section-title {
            color: #18212f;
            font-size: clamp(2rem, 3vw, 2.45rem);
        }
        .field-shell {
            background: #fbfcfe;
            border: 1px solid rgba(17,24,39,0.08);
            border-radius: 24px;
            padding: 18px;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.78);
        }
        .form-control,
        .form-select {
            border: 1px solid rgba(17,24,39,0.10);
            min-height: 48px;
        }
        .form-control:focus,
        .form-select:focus {
            border-color: rgba(255, 71, 87, 0.45);
            box-shadow: 0 0 0 0.25rem rgba(255, 71, 87, 0.12);
        }
        .support-strip {
            margin-top: 14px;
            color: #6b7280;
        }
        @media (max-width: 991.98px) {
            .pay-left {
                border-right: 0;
                border-bottom: 1px solid rgba(0,0,0,0.06);
            }
        }
    </style>
</head>
<body>

<div class="payment-shell">
    <div class="pay-card">
        <div class="row g-0">
            <div class="col-lg-4 pay-left p-4 p-lg-5">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <div class="brand">
                        <span class="brand-mark"><i class="fas fa-utensils"></i></span>
                        <span class="brand-copy">
                            <span>Food Monu</span>
                            <small>Trusted Payments</small>
                        </span>
                    </div>
                    <?php if ($is_test_mode): ?>
                        <span class="chip"><i class="fas fa-flask"></i> Test Mode</span>
                    <?php else: ?>
                        <span class="chip"><i class="fas fa-lock"></i> Secure</span>
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <div class="panel-label">Order Reference</div>
                    <div class="fw-bold fs-3 mb-0">#<?php echo qb_order_display_id((int)$order_id); ?></div>
                </div>

                <div class="mb-4">
                    <div class="panel-label">Amount Payable</div>
                    <div class="amount-block">
                        <div class="amount-value"><?php echo '&#8377;' . number_format($amount, 2); ?></div>
                    </div>
                </div>

                <div class="qb-card">
                    <div class="small fw-bold text-uppercase muted mb-3">Payment Assurance</div>
                    <div class="d-flex flex-column gap-2 small">
                        <div class="d-flex align-items-center gap-2">
                            <i class="fas fa-shield-halved text-danger"></i>
                            <span>UPI, wallet and card support</span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <i class="fas fa-receipt text-danger"></i>
                            <span>Instant transaction reference after payment</span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <i class="fas fa-headset text-danger"></i>
                            <span>Support: <span class="mono">monu.help@gmail.com</span></span>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <a href="checkout.php" class="small text-decoration-none muted">
                        <i class="fas fa-arrow-left me-1"></i> Back to checkout
                    </a>
                </div>
            </div>

            <div class="col-lg-8 p-4 p-lg-5">
                <h3 class="fw-bold mb-1 section-title">Choose payment method</h3>
                <div class="muted mb-4">Select a method and complete the payment to confirm your order.</div>

                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo h($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="" id="paymentForm" novalidate>
                    <input type="hidden" name="csrf_token" value="<?php echo h($csrf); ?>">

                    <div class="mb-3">
                        <div class="small fw-bold text-uppercase muted mb-2">Payment Methods</div>
                        <div class="d-grid gap-2">
                            <label class="method-card d-flex align-items-center gap-3 <?php echo $selected_method === 'upi' ? 'active' : ''; ?>" data-method="upi">
                                <input type="radio" name="method" value="upi" class="form-check-input m-0" <?php echo $selected_method === 'upi' ? 'checked' : ''; ?>>
                                <div class="flex-grow-1">
                                    <div class="fw-bold">UPI</div>
                                    <div class="muted small">Paytm / PhonePe / GPay / Any UPI ID</div>
                                </div>
                                <span class="method-icon"><i class="fas fa-bolt text-warning"></i></span>
                            </label>

                            <label class="method-card d-flex align-items-center gap-3 <?php echo $selected_method === 'wallet' ? 'active' : ''; ?>" data-method="wallet">
                                <input type="radio" name="method" value="wallet" class="form-check-input m-0" <?php echo $selected_method === 'wallet' ? 'checked' : ''; ?>>
                                <div class="flex-grow-1">
                                    <div class="fw-bold">Wallet</div>
                                    <div class="muted small">Paytm / PhonePe</div>
                                </div>
                                <span class="method-icon"><i class="fas fa-wallet text-primary"></i></span>
                            </label>

                            <label class="method-card d-flex align-items-center gap-3 <?php echo $selected_method === 'card' ? 'active' : ''; ?>" data-method="card">
                                <input type="radio" name="method" value="card" class="form-check-input m-0" <?php echo $selected_method === 'card' ? 'checked' : ''; ?>>
                                <div class="flex-grow-1">
                                    <div class="fw-bold">Debit / Credit Card</div>
                                    <div class="muted small">Visa / MasterCard / RuPay</div>
                                </div>
                                <span class="method-icon"><i class="fas fa-credit-card text-info"></i></span>
                            </label>
                        </div>
                    </div>

                    <div id="upiBox" class="mb-3 field-shell">
                        <div class="row g-2">
                            <div class="col-md-5">
                                <label class="form-label small fw-bold muted">UPI App</label>
                                <select name="upi_app" class="form-select rounded-4" data-method-input="upi">
                                    <option value="Paytm" <?php echo $upi_app_value === 'Paytm' ? 'selected' : ''; ?>>Paytm</option>
                                    <option value="PhonePe" <?php echo $upi_app_value === 'PhonePe' ? 'selected' : ''; ?>>PhonePe</option>
                                    <option value="GPay" <?php echo $upi_app_value === 'GPay' ? 'selected' : ''; ?>>GPay</option>
                                    <option value="Other" <?php echo $upi_app_value === 'Other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                            <div class="col-md-7">
                                <label class="form-label small fw-bold muted">UPI ID</label>
                                <input type="text" name="upi_id" class="form-control rounded-4" placeholder="name@upi" autocomplete="off" value="<?php echo h($upi_id_value); ?>" data-method-input="upi" data-validation-type="upi">
                                <div class="form-text">Example: <span class="mono">monu@upi</span></div>
                                <div class="invalid-feedback">Valid UPI ID enter karo, jaise `name@upi`.</div>
                            </div>
                        </div>
                    </div>

                    <div id="walletBox" class="mb-3 field-shell" style="display:none;">
                        <div class="row g-2">
                            <div class="col-md-5">
                                <label class="form-label small fw-bold muted">Wallet Provider</label>
                                <select name="wallet_provider" class="form-select rounded-4" data-method-input="wallet">
                                    <option value="Paytm" <?php echo $wallet_provider_value === 'Paytm' ? 'selected' : ''; ?>>Paytm</option>
                                    <option value="PhonePe" <?php echo $wallet_provider_value === 'PhonePe' ? 'selected' : ''; ?>>PhonePe</option>
                                </select>
                            </div>
                            <div class="col-md-7">
                                <label class="form-label small fw-bold muted">Mobile Number</label>
                                <input type="text" name="wallet_mobile" class="form-control rounded-4" placeholder="10-digit mobile" autocomplete="off" value="<?php echo h($wallet_mobile_value); ?>" data-method-input="wallet" data-validation-type="wallet-mobile" inputmode="numeric">
                                <div class="form-text">OTP simulation in project (no SMS gateway).</div>
                                <div class="invalid-feedback">Wallet payment ke liye valid 10-digit mobile number chahiye.</div>
                            </div>
                        </div>
                    </div>

                    <div id="cardBox" class="mb-3 field-shell" style="display:none;">
                        <div class="row g-2">
                            <div class="col-12">
                                <label class="form-label small fw-bold muted">Cardholder Name</label>
                                <input type="text" name="card_name" class="form-control rounded-4" placeholder="Name on card" autocomplete="off" value="<?php echo h($card_name_value); ?>" data-method-input="card" data-validation-type="card-name">
                                <div class="invalid-feedback">Cardholder name kam se kam 2 characters ka hona chahiye.</div>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold muted">Card Number</label>
                                <input type="text" name="card_no" class="form-control rounded-4" placeholder="Any dummy card number" autocomplete="off" value="<?php echo h($card_no_value); ?>" data-method-input="card" data-validation-type="card-number" inputmode="numeric">
                                <div class="form-text">You can enter any dummy number (12&ndash;19 digits).</div>
                                <div class="invalid-feedback">Card number 12 se 19 digits ka hona chahiye.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold muted">Expiry (MM/YY)</label>
                                <input type="text" name="card_exp" class="form-control rounded-4" placeholder="MM/YY" autocomplete="off" value="<?php echo h($card_exp_value); ?>" data-method-input="card" data-validation-type="card-expiry" inputmode="numeric">
                                <div class="invalid-feedback">Valid future expiry enter karo, jaise 12/28.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold muted">CVV</label>
                                <input type="password" name="card_cvv" class="form-control rounded-4" placeholder="***" autocomplete="off" data-method-input="card" data-validation-type="card-cvv" inputmode="numeric">
                                <div class="invalid-feedback">CVV 3 ya 4 digits ka hona chahiye.</div>
                            </div>
                            <div class="col-12">
                                <div class="form-text">Note: This is a simulated card flow. For real payments, integrate a gateway.</div>
                            </div>
                        </div>
                    </div>

                    <?php if ($is_test_mode): ?>
                        <div class="mb-3">
                            <label class="form-label small fw-bold muted">Test Result</label>
                            <select name="simulate" class="form-select rounded-4">
                                <option value="success">Success</option>
                                <option value="fail">Fail</option>
                            </select>
                            <div class="form-text">Only visible in test mode: add <span class="mono">?test=1</span> in URL.</div>
                        </div>
                    <?php endif; ?>

                    <button type="submit" name="pay_now" class="btn btn-pay text-white w-100 py-3 rounded-pill fw-bold">
                        Pay Now
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="text-center small support-strip">
        Having trouble? Contact support: <span class="mono">monu.help@gmail.com</span>
    </div>
</div>

<script>
    (function () {
        const form = document.getElementById('paymentForm');
        const methodCards = document.querySelectorAll('[data-method]');
        const radios = document.querySelectorAll('input[name="method"]');
        const upiBox = document.getElementById('upiBox');
        const walletBox = document.getElementById('walletBox');
        const cardBox = document.getElementById('cardBox');
        const methodInputs = document.querySelectorAll('[data-method-input]');

        function digitsOnly(value) {
            return (value || '').replace(/\D+/g, '');
        }

        function isValidExpiry(value) {
            const match = (value || '').trim().match(/^(0[1-9]|1[0-2])\s*\/\s*(\d{2}|\d{4})$/);
            if (!match) return false;
            const month = parseInt(match[1], 10);
            let year = parseInt(match[2], 10);
            if (year < 100) year += 2000;
            const now = new Date();
            const currentYear = now.getFullYear();
            const currentMonth = now.getMonth() + 1;
            if (year < currentYear) return false;
            if (year === currentYear && month < currentMonth) return false;
            return true;
        }

        function validateInput(input, activeMethod) {
            const fieldMethod = input.getAttribute('data-method-input');
            const isActiveField = fieldMethod === activeMethod;

            input.required = isActiveField;
            input.disabled = !isActiveField;
            input.setCustomValidity('');
            input.classList.remove('is-invalid');

            if (!isActiveField) {
                return true;
            }

            const raw = input.value.trim();
            const type = input.getAttribute('data-validation-type') || '';
            let valid = true;
            let message = '';

            if (type === 'upi') {
                valid = /^[a-zA-Z0-9.\-_]{2,}@[a-zA-Z]{2,}$/.test(raw);
                if (!valid) message = 'Please enter a valid UPI ID.';
            } else if (type === 'wallet-mobile') {
                const digits = digitsOnly(raw);
                valid = digits.length === 10;
                if (!valid) message = 'Please enter a valid 10-digit mobile number.';
            } else if (type === 'card-name') {
                valid = raw.length >= 2;
                if (!valid) message = 'Please enter cardholder name.';
            } else if (type === 'card-number') {
                const digits = digitsOnly(raw);
                valid = digits.length >= 12 && digits.length <= 19;
                if (!valid) message = 'Please enter a valid card number.';
            } else if (type === 'card-expiry') {
                valid = isValidExpiry(raw);
                if (!valid) message = 'Please enter a valid expiry date.';
            } else if (type === 'card-cvv') {
                const digits = digitsOnly(raw);
                valid = digits.length === 3 || digits.length === 4;
                if (!valid) message = 'Please enter a valid CVV.';
            } else if (input.tagName === 'SELECT') {
                valid = raw !== '';
                if (!valid) message = 'Please choose an option.';
            } else {
                valid = raw !== '';
                if (!valid) message = 'This field is required.';
            }

            if (!valid) {
                input.setCustomValidity(message);
                input.classList.add('is-invalid');
            }

            return valid;
        }

        function refresh() {
            const v = document.querySelector('input[name="method"]:checked')?.value || 'upi';
            upiBox.style.display = (v === 'upi') ? 'block' : 'none';
            walletBox.style.display = (v === 'wallet') ? 'block' : 'none';
            cardBox.style.display = (v === 'card') ? 'block' : 'none';

            methodCards.forEach(c => c.classList.toggle('active', c.getAttribute('data-method') === v));
            methodInputs.forEach(input => validateInput(input, v));
        }

        radios.forEach(r => r.addEventListener('change', refresh));
        methodCards.forEach(c => c.addEventListener('click', () => {
            const v = c.getAttribute('data-method');
            const target = document.querySelector('input[name="method"][value="' + v + '"]');
            if (target) target.checked = true;
            refresh();
        }));

        methodInputs.forEach(input => {
            input.addEventListener('input', () => {
                const activeMethod = document.querySelector('input[name="method"]:checked')?.value || 'upi';
                validateInput(input, activeMethod);
            });
            input.addEventListener('blur', () => {
                const activeMethod = document.querySelector('input[name="method"]:checked')?.value || 'upi';
                validateInput(input, activeMethod);
            });
        });

        form?.addEventListener('submit', function (event) {
            const activeMethod = document.querySelector('input[name="method"]:checked')?.value || 'upi';
            let formValid = true;

            methodInputs.forEach(input => {
                if (!validateInput(input, activeMethod)) {
                    formValid = false;
                }
            });

            if (!formValid || !form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                form.classList.add('was-validated');
            }
        });

        refresh();
    })();
</script>
</body>
</html>
