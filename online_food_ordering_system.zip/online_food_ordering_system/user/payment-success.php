<?php
/**
 * QuickBite - Payment Success Details
 * File: user/payment-success.php
 */
require_once(__DIR__ . '/../config/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$order_id = (int)($_GET['order_id'] ?? 0);
$user_id = (int)$_SESSION['user_id'];

if ($order_id <= 0) {
    header("Location: index.php");
    exit();
}

$order = null;
$stmt = mysqli_prepare(
    $conn,
    "SELECT id, user_id, total_amount, payment_mode, payment_status, transaction_id, order_status
     FROM orders
     WHERE id = ? AND user_id = ?
     LIMIT 1"
);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        $order = mysqli_fetch_assoc($result) ?: null;
    }
    mysqli_stmt_close($stmt);
}

if (!$order || ($order['payment_mode'] ?? '') !== 'Online') {
    header("Location: my-orders.php");
    exit();
}

$payment_meta = $_SESSION['payment_success'][$order_id] ?? [];
$txn_id = (string)($payment_meta['txn_id'] ?? ($order['transaction_id'] ?? ''));
$reference_no = (string)($payment_meta['reference_no'] ?? '');
$reference_label = (string)($payment_meta['reference_label'] ?? 'Reference No');
$payment_method = (string)($payment_meta['payment_method'] ?? 'ONLINE');
$payment_status = (string)($payment_meta['payment_status'] ?? ($order['payment_status'] ?? 'Pending'));
$amount = (float)($payment_meta['amount'] ?? ($order['total_amount'] ?? 0));

if ($reference_no === '' && $txn_id !== '') {
    $reference_no = (string)(100000000000 + (abs(crc32($txn_id)) % 899999999999));
}

$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful | Food Monu</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            background:
                radial-gradient(circle at top left, rgba(255, 71, 87, 0.14), transparent 30%),
                radial-gradient(circle at bottom right, rgba(47, 53, 66, 0.10), transparent 35%),
                #f7f8fb;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 12px;
        }
        .success-shell {
            width: min(760px, 100%);
        }
        .success-card {
            background: rgba(255,255,255,0.96);
            border-radius: 34px;
            border: 1px solid rgba(255, 71, 87, 0.10);
            box-shadow: 0 28px 60px rgba(47,53,66,0.12);
            overflow: hidden;
        }
        .success-head {
            background: linear-gradient(135deg, #ff4757, #ff7b72);
            color: #fff;
            padding: 28px 30px;
            text-align: center;
        }
        .success-badge {
            width: 84px;
            height: 84px;
            border-radius: 50%;
            background: rgba(255,255,255,0.18);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            margin-bottom: 14px;
        }
        .success-body {
            padding: 28px;
        }
        .status-ribbon {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            border-radius: 999px;
            background: #e9f8ef;
            color: #11834e;
            font-weight: 700;
            margin-bottom: 20px;
        }
        .details-card {
            border: 1px solid rgba(47,53,66,0.08);
            background: #fcfcfd;
            border-radius: 26px;
            padding: 22px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            gap: 18px;
            padding: 14px 0;
            border-bottom: 1px solid rgba(47,53,66,0.08);
        }
        .detail-row:last-child {
            border-bottom: 0;
        }
        .detail-row span {
            color: #7f8797;
            font-weight: 600;
        }
        .detail-row strong {
            color: #1f2937;
            text-align: right;
            word-break: break-word;
        }
        .amount-box {
            margin-top: 20px;
            background: #fff4f4;
            border-radius: 24px;
            padding: 18px 22px;
            text-align: center;
            border: 1px solid rgba(255, 71, 87, 0.12);
        }
        .amount-box span {
            display: block;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #8a94a6;
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 6px;
        }
        .amount-box strong {
            font-size: 34px;
            color: #e03143;
        }
        .action-row {
            display: grid;
            grid-template-columns: 1fr;
            gap: 14px;
            margin-top: 24px;
        }
        .processing-screen {
            position: fixed;
            inset: 0;
            background:
                radial-gradient(circle at top left, rgba(255, 71, 87, 0.18), transparent 32%),
                radial-gradient(circle at bottom right, rgba(47, 53, 66, 0.12), transparent 38%),
                rgba(247, 248, 251, 0.98);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px 12px;
            z-index: 20;
            transition: opacity 0.45s ease, visibility 0.45s ease;
        }
        .processing-screen.hide {
            opacity: 0;
            visibility: hidden;
            pointer-events: none;
        }
        .processing-card {
            width: min(460px, 100%);
            background: rgba(255,255,255,0.97);
            border-radius: 32px;
            border: 1px solid rgba(255, 71, 87, 0.10);
            box-shadow: 0 28px 60px rgba(47,53,66,0.14);
            padding: 34px 24px;
            text-align: center;
        }
        .processing-spinner {
            width: 78px;
            height: 78px;
            margin: 0 auto 18px;
            border-radius: 50%;
            border: 6px solid rgba(255, 71, 87, 0.14);
            border-top-color: #ff4757;
            animation: spin 0.9s linear infinite;
        }
        .processing-title {
            font-size: 30px;
            font-weight: 800;
            color: #1f2937;
            margin-bottom: 10px;
        }
        .processing-text {
            color: #6b7280;
            margin-bottom: 18px;
        }
        .processing-steps {
            display: grid;
            gap: 10px;
            text-align: left;
            margin-top: 20px;
        }
        .processing-step {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 14px;
            border-radius: 16px;
            background: #fff6f6;
            color: #4b5563;
            font-weight: 600;
        }
        .processing-step i {
            color: #ff4757;
        }
        .success-shell {
            opacity: 0;
            transform: translateY(16px);
            transition: opacity 0.45s ease, transform 0.45s ease;
        }
        .success-shell.ready {
            opacity: 1;
            transform: translateY(0);
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        @media (max-width: 575.98px) {
            .success-head,
            .success-body {
                padding: 22px;
            }
            .detail-row {
                flex-direction: column;
                gap: 6px;
            }
            .detail-row strong {
                text-align: left;
            }
            .action-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="processing-screen" id="processingScreen">
        <div class="processing-card">
            <div class="processing-spinner"></div>
            <div class="processing-title">Processing Payment</div>
            <p class="processing-text">Aapka transaction verify ho raha hai. Thoda sa wait kijiye.</p>
            <div class="processing-steps">
                <div class="processing-step">
                    <i class="fas fa-shield-halved"></i>
                    <span>Secure payment verification</span>
                </div>
                <div class="processing-step">
                    <i class="fas fa-receipt"></i>
                    <span>Transaction details generate ho rahi hain</span>
                </div>
                <div class="processing-step">
                    <i class="fas fa-circle-check"></i>
                    <span>Payment status update ho raha hai</span>
                </div>
            </div>
        </div>
    </div>

    <div class="success-shell" id="successShell">
        <div class="success-card">
            <div class="success-head">
                <div class="success-badge"><i class="fas fa-check"></i></div>
                <h1 class="fw-bold mb-2">Payment Successful</h1>
                <p class="mb-0">Aapka online payment successful ho gaya hai. Neeche sari payment details ready hain.</p>
            </div>

            <div class="success-body">
                <div class="status-ribbon">
                    <i class="fas fa-circle-check"></i>
                    <?php echo $h($payment_status); ?>
                </div>

                <div class="details-card">
                    <div class="detail-row">
                        <span>Txn ID</span>
                        <strong><?php echo $h($txn_id ?: 'Pending'); ?></strong>
                    </div>
                    <div class="detail-row">
                        <span><?php echo $h($reference_label); ?></span>
                        <strong><?php echo $h($reference_no ?: 'Pending'); ?></strong>
                    </div>
                    <div class="detail-row">
                        <span>Order ID</span>
                        <strong>#<?php echo qb_order_display_id((int)$order_id); ?></strong>
                    </div>
                    <div class="detail-row">
                        <span>Payment Method</span>
                        <strong><?php echo $h($payment_method); ?></strong>
                    </div>
                    <div class="detail-row">
                        <span>Payment Status</span>
                        <strong><?php echo $h($payment_status); ?></strong>
                    </div>
                </div>

                <div class="amount-box">
                    <span>Amount Paid</span>
                    <strong><?php echo '&#8377;' . $h(number_format($amount, 2)); ?></strong>
                </div>

                <div class="action-row">
                    <a href="order-success.php?order_id=<?php echo $order_id; ?>&status=paid" class="btn btn-danger rounded-pill py-3 fw-bold shadow">
                        <i class="fas fa-bag-shopping me-2"></i>Place Order
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function () {
            const processingScreen = document.getElementById('processingScreen');
            const successShell = document.getElementById('successShell');

            window.setTimeout(function () {
                processingScreen.classList.add('hide');
                successShell.classList.add('ready');
            }, 1800);
        })();
    </script>
</body>
</html>
