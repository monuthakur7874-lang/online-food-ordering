<?php
/**
 * QuickBite - My Orders (Professional UI)
 * File: user/my-orders.php
 */

require_once(__DIR__ . '/../config/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

$order_res = mysqli_query(
    $conn,
    "SELECT o.id, o.total_amount, o.order_date, o.order_status,
            o.payment_mode, o.payment_status, o.transaction_id, o.delivery_address,
            o.rider_id, r.name AS rider_name, r.phone AS rider_phone
     FROM orders o
     LEFT JOIN users r ON r.id = o.rider_id
     WHERE o.user_id = $user_id
     ORDER BY o.id DESC"
);

$orders = [];
if ($order_res) {
    while ($row = mysqli_fetch_assoc($order_res)) {
        $orders[] = $row;
    }
}

$total_orders = count($orders);
$count_active = 0;
$count_delivered = 0;
$count_cancelled = 0;
foreach ($orders as $o) {
    $st = (string)($o['order_status'] ?? '');
    if ($st === 'Delivered') $count_delivered++;
    elseif ($st === 'Cancelled') $count_cancelled++;
    else $count_active++;
}

// Prepared statement for order items (reused)
$items_stmt = mysqli_prepare(
    $conn,
    "SELECT oi.quantity, oi.price, f.title
     FROM order_items oi
     JOIN foods f ON oi.food_id = f.id
     WHERE oi.order_id = ?"
);

include('includes/header.php');
?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-9">
            <div class="d-flex justify-content-between align-items-end mb-4 flex-wrap gap-2">
                <div>
                    <h3 class="fw-bold mb-1">My Orders</h3>
                    <p class="text-muted small mb-0">Track orders, payments, and delivery updates</p>
                </div>
                <a href="index.php#menu" class="btn btn-danger rounded-pill px-4 fw-bold shadow-sm">
                    <i class="fas fa-plus me-2"></i>New Order
                </a>
            </div>

            <?php if ($total_orders > 0): ?>
                <div class="qb-toolbar mb-4">
                    <div class="qb-tabs">
                        <button type="button" class="qb-tab active" data-filter="all">
                            All <span class="qb-count"><?php echo (int)$total_orders; ?></span>
                        </button>
                        <button type="button" class="qb-tab" data-filter="active">
                            Active <span class="qb-count"><?php echo (int)$count_active; ?></span>
                        </button>
                        <button type="button" class="qb-tab" data-filter="delivered">
                            Delivered <span class="qb-count"><?php echo (int)$count_delivered; ?></span>
                        </button>
                        <button type="button" class="qb-tab" data-filter="cancelled">
                            Cancelled <span class="qb-count"><?php echo (int)$count_cancelled; ?></span>
                        </button>
                    </div>
                    <div class="qb-hint text-muted small">
                        Online pending/failed orders can be paid again.
                    </div>
                </div>

                <?php foreach ($orders as $order):
                    $order_id = (int)($order['id'] ?? 0);
                    $status = (string)($order['order_status'] ?? 'Pending');
                    $payment_mode = (string)($order['payment_mode'] ?? '');
                    $payment_status = (string)($order['payment_status'] ?? 'Pending');
                    $payment_label = ($payment_mode === 'COD' && $payment_status === 'Paid') ? 'Cash Paid' : $payment_status;
                    $txn = (string)($order['transaction_id'] ?? '');
                    $address = (string)($order['delivery_address'] ?? '');
                    $rider_name = (string)($order['rider_name'] ?? '');
                    $rider_phone = (string)($order['rider_phone'] ?? '');

                    $status_badge = "bg-soft-warning text-warning"; $status_dot = "bg-warning";
                    if ($status === 'On the Way') { $status_badge = "bg-soft-info text-info"; $status_dot = "bg-info"; }
                    if ($status === 'Delivered') { $status_badge = "bg-soft-success text-success"; $status_dot = "bg-success"; }
                    if ($status === 'Cancelled') { $status_badge = "bg-soft-danger text-danger"; $status_dot = "bg-danger"; }

                    $pay_badge = "bg-soft-warning text-warning";
                    if ($payment_status === 'Paid') $pay_badge = "bg-soft-success text-success";
                    if ($payment_status === 'Failed') $pay_badge = "bg-soft-danger text-danger";

                    $group = 'active';
                    if ($status === 'Delivered') $group = 'delivered';
                    if ($status === 'Cancelled') $group = 'cancelled';
                ?>
                    <div class="card border-0 shadow-sm rounded-4 mb-4 order-card qb-order" data-group="<?php echo $h($group); ?>">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start gap-3 mb-3 flex-wrap">
                                <div class="flex-grow-1">
                                    <div class="d-flex align-items-center gap-2 flex-wrap">
                                        <h5 class="fw-bold mb-0">Order <span class="text-danger">#<?php echo qb_order_display_id($order_id); ?></span></h5>
                                        <span class="text-muted small">
                                            <i class="far fa-calendar-alt me-1"></i><?php echo $h(date('d M Y, h:i A', strtotime((string)$order['order_date']))); ?>
                                        </span>
                                    </div>

                                    <div class="d-flex gap-2 flex-wrap mt-2">
                                        <span class="qb-pill <?php echo $status_badge; ?>">
                                            <span class="status-dot <?php echo $status_dot; ?>"></span><?php echo $h($status); ?>
                                        </span>
                                        <span class="qb-pill <?php echo $pay_badge; ?>">
                                            <i class="fas fa-money-check-dollar me-1"></i><?php echo $h($payment_label); ?>
                                        </span>
                                        <span class="qb-pill bg-soft-dark text-dark">
                                            <i class="fas fa-wallet me-1"></i><?php echo $h($payment_mode); ?>
                                        </span>
                                    </div>
                                </div>

                                <div class="text-end ms-auto">
                                    <div class="text-muted small">Total</div>
                                    <div class="fw-bold fs-4"><?php echo '&#8377;' . $h(number_format((float)$order['total_amount'], 2)); ?></div>
                                </div>
                            </div>

                            <hr class="opacity-10">

                            <div class="row align-items-start">
                                <div class="col-md-7">
                                    <p class="text-muted small fw-bold text-uppercase mb-2">Items</p>

                                    <div class="order-items-list">
                                        <?php
                                        $total_items = 0;
                                        if ($items_stmt) {
                                            mysqli_stmt_bind_param($items_stmt, "i", $order_id);
                                            mysqli_stmt_execute($items_stmt);
                                            mysqli_stmt_bind_result($items_stmt, $iqty, $iprice, $ititle);
                                            mysqli_stmt_store_result($items_stmt);
                                            $total_items = (int)mysqli_stmt_num_rows($items_stmt);

                                            $i = 0;
                                            while (mysqli_stmt_fetch($items_stmt)) {
                                                $i++;
                                                if ($i > 3) continue;
                                                ?>
                                                <div class="d-flex justify-content-between mb-1 small">
                                                    <span><span class="text-danger fw-bold"><?php echo (int)$iqty; ?>x</span> <?php echo $h($ititle); ?></span>
                                                    <span class="text-muted"><?php echo '&#8377;' . $h(number_format((float)$iprice, 2)); ?></span>
                                                </div>
                                                <?php
                                            }
                                            mysqli_stmt_free_result($items_stmt);
                                        }
                                        ?>
                                    </div>

                                    <?php if ($total_items > 3): ?>
                                        <button type="button" class="btn btn-link p-0 small text-decoration-none" data-bs-toggle="collapse" data-bs-target="#items<?php echo $order_id; ?>">
                                            View all items (<?php echo (int)$total_items; ?>)
                                        </button>
                                        <div class="collapse mt-2" id="items<?php echo $order_id; ?>">
                                            <div class="qb-subcard p-3 rounded-4">
                                                <?php
                                                if ($items_stmt) {
                                                    mysqli_stmt_bind_param($items_stmt, "i", $order_id);
                                                    mysqli_stmt_execute($items_stmt);
                                                    mysqli_stmt_bind_result($items_stmt, $iqty2, $iprice2, $ititle2);
                                                    mysqli_stmt_store_result($items_stmt);
                                                    while (mysqli_stmt_fetch($items_stmt)) {
                                                        ?>
                                                        <div class="d-flex justify-content-between mb-1 small">
                                                            <span><span class="text-danger fw-bold"><?php echo (int)$iqty2; ?>x</span> <?php echo $h($ititle2); ?></span>
                                                            <span class="text-muted"><?php echo '&#8377;' . $h(number_format((float)$iprice2, 2)); ?></span>
                                                        </div>
                                                        <?php
                                                    }
                                                    mysqli_stmt_free_result($items_stmt);
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="col-md-5 text-md-end mt-3 mt-md-0 border-start-md">
                                    <div class="ps-md-4">
                                        <div class="text-muted small fw-bold text-uppercase mb-2">Details</div>

                                        <div class="small mb-2">
                                            <i class="fas fa-location-dot text-danger me-1"></i>
                                            <span class="text-muted"><?php echo $h($address ?: '—'); ?></span>
                                        </div>

                                        <?php if ($payment_status === 'Paid' && $txn !== ''): ?>
                                            <div class="small mb-2">
                                                <i class="fas fa-receipt text-danger me-1"></i>
                                                <span class="text-muted">Txn: <?php echo $h($txn); ?></span>
                                            </div>
                                        <?php endif; ?>

                                        <?php if ($status === 'On the Way' && ($rider_name !== '' || $rider_phone !== '')): ?>
                                            <div class="small mb-3">
                                                <i class="fas fa-motorcycle text-danger me-1"></i>
                                                <span class="text-muted"><?php echo $h(trim($rider_name)); ?></span>
                                                <?php if ($rider_phone !== ''): ?>
                                                    <a class="text-decoration-none ms-1" href="tel:<?php echo $h(preg_replace('/\\D+/', '', $rider_phone)); ?>">
                                                        <?php echo $h($rider_phone); ?>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            <div class="mb-3"></div>
                                        <?php endif; ?>

                                        <div class="d-flex justify-content-md-end gap-2 flex-wrap">
                                            <?php if ($payment_status === 'Paid' || ($payment_mode === 'COD' && $status === 'Delivered')): ?>
                                                <a href="invoice.php?order_id=<?php echo $order_id; ?>" class="btn btn-outline-danger rounded-pill px-4 btn-sm fw-bold">
                                                    Invoice
                                                </a>
                                            <?php endif; ?>

                                            <?php if ($payment_mode === 'Online' && $payment_status !== 'Paid' && $status !== 'Cancelled'): ?>
                                                <a href="payment-gateway.php?order_id=<?php echo $order_id; ?>" class="btn btn-danger rounded-pill px-4 btn-sm fw-bold">
                                                    Pay Now
                                                </a>
                                            <?php endif; ?>

                                            <?php if ($status !== 'Delivered' && $status !== 'Cancelled'): ?>
                                                <a href="track-order.php?order_id=<?php echo $order_id; ?>" class="btn btn-dark rounded-pill px-4 btn-sm fw-bold">
                                                    Track
                                                </a>
                                            <?php endif; ?>

                                            <a href="../help.php" class="btn btn-outline-secondary rounded-pill px-4 btn-sm fw-bold">
                                                Help
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="card border-0 shadow-sm rounded-5 p-5 text-center">
                    <img src="https://cdn-icons-png.flaticon.com/512/11329/11329060.png" width="120" class="mb-4 mx-auto opacity-25" alt="No orders">
                    <h4 class="fw-bold">No orders yet</h4>
                    <p class="text-muted mb-0">Explore the menu and place your first order.</p>
                    <a href="index.php#menu" class="btn btn-danger rounded-pill px-5 py-2 fw-bold shadow mt-3">Go To Menu</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    .order-card { transition: all 0.25s ease; border: 1px solid rgba(0,0,0,0.02) !important; }
    .order-card:hover { transform: translateY(-4px); box-shadow: 0 15px 35px rgba(0,0,0,0.08) !important; }
    .bg-soft-warning { background-color: #fff9e6; }
    .bg-soft-success { background-color: #e6f7ef; }
    .bg-soft-danger { background-color: #fbe9eb; }
    .bg-soft-info { background-color: #e7f3ff; }
    .bg-soft-dark { background-color: #f3f4f6; }
    .status-dot { height: 8px; width: 8px; border-radius: 50%; display: inline-block; }
    .qb-pill { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 999px; font-weight: 800; font-size: 12px; }
    .qb-subcard { background: #f8f9fb; border: 1px solid rgba(0,0,0,0.06); }
    .qb-toolbar { display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; }
    .qb-tabs { display: flex; gap: 8px; flex-wrap: wrap; }
    .qb-tab {
        border: 1px solid rgba(0,0,0,0.10);
        background: #fff;
        padding: 8px 12px;
        border-radius: 999px;
        font-weight: 800;
        font-size: 13px;
        color: #2f3542;
        transition: 0.2s ease;
    }
    .qb-tab:hover { transform: translateY(-1px); box-shadow: 0 12px 24px rgba(0,0,0,0.06); }
    .qb-tab.active { border-color: rgba(255,71,87,0.55); box-shadow: 0 12px 24px rgba(255,71,87,0.10); }
    .qb-count { display: inline-block; margin-left: 6px; padding: 2px 8px; border-radius: 999px; background: rgba(255,71,87,0.12); color: #ff4757; }
    @media (min-width: 768px) { .border-start-md { border-left: 1px solid #eee !important; } }
</style>

<script>
    (function () {
        const tabs = document.querySelectorAll('.qb-tab');
        const cards = document.querySelectorAll('.qb-order');
        function apply(filter) {
            cards.forEach(c => {
                const group = c.getAttribute('data-group') || 'active';
                const show = (filter === 'all') || (group === filter);
                c.style.display = show ? '' : 'none';
            });
        }
        tabs.forEach(t => t.addEventListener('click', () => {
            tabs.forEach(x => x.classList.remove('active'));
            t.classList.add('active');
            apply(t.getAttribute('data-filter') || 'all');
        }));
        apply('all');
    })();
</script>

<?php if (isset($items_stmt) && $items_stmt) { mysqli_stmt_close($items_stmt); } ?>
<?php include('includes/footer.php'); ?>
