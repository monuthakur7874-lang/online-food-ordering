<?php
/**
 * QuickBite - Order & Payment Processing Logic
 * File: user/process-order.php
 */
require_once(__DIR__ . '/../config/db.php');
require_once(__DIR__ . '/includes/csrf.php');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1. Security Check: User logged in hai aur cart khali nahi hai?
if (!isset($_SESSION['user_id']) || empty($_SESSION['cart'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!qb_csrf_validate((string)($_POST['csrf_token'] ?? ''))) {
        header("Location: checkout.php?error=Security+check+failed");
        exit();
    }

    $user_id = (int)$_SESSION['user_id'];
    $delivery_address = trim((string)($_POST['delivery_address'] ?? ''));
    if ($delivery_address === '') {
        header("Location: checkout.php?error=Delivery+address+required");
        exit();
    }
    $payment_mode_raw = $_POST['payment_mode'] ?? 'COD';
    $payment_mode = ($payment_mode_raw === 'Online') ? 'Online' : 'COD';
    
    // Status initialization
    $order_status = "Pending";
    $payment_status = "Pending"; // COD is also pending until delivered

    // Recalculate total on server (client hidden field can be tampered)
    $subtotal = 0.0;
    foreach ($_SESSION['cart'] as $item) {
        $price = isset($item['price']) ? (float)$item['price'] : 0.0;
        $qty = isset($item['qty']) ? (int)$item['qty'] : 0;
        if ($qty > 0 && $price >= 0) {
            $subtotal += ($price * $qty);
        }
    }
    $delivery_fee = 40.0;
    $total_amount = $subtotal + $delivery_fee;
    
    // 2. MySQL Transaction Start (Taaki dono tables mein data sahi se jaye)
    mysqli_begin_transaction($conn);

    try {
        // 3. Insert into 'orders' table
        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO orders (user_id, total_amount, payment_mode, payment_status, order_status, delivery_address)
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        if (!$stmt) {
            throw new Exception("Order Placement Failed!");
        }
        mysqli_stmt_bind_param($stmt, "idssss", $user_id, $total_amount, $payment_mode, $payment_status, $order_status, $delivery_address);
        if (!mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            throw new Exception("Order Placement Failed!");
        }
        mysqli_stmt_close($stmt);

        $order_id = mysqli_insert_id($conn); // Nayi Order ID nikaalein

        // 4. Insert into 'order_items' table (Loop through Cart)
        $item_stmt = mysqli_prepare($conn, "INSERT INTO order_items (order_id, food_id, quantity, price) VALUES (?, ?, ?, ?)");
        if (!$item_stmt) {
            throw new Exception("Items Insertion Failed!");
        }

        foreach ($_SESSION['cart'] as $food_id => $item) {
            $food_id = (int)$food_id;
            $price = isset($item['price']) ? (float)$item['price'] : 0.0;
            $qty = isset($item['qty']) ? (int)$item['qty'] : 0;
            if ($food_id <= 0 || $qty <= 0) {
                continue;
            }

            mysqli_stmt_bind_param($item_stmt, "iiid", $order_id, $food_id, $qty, $price);
            if (!mysqli_stmt_execute($item_stmt)) {
                mysqli_stmt_close($item_stmt);
                throw new Exception("Items Insertion Failed!");
            }
        }
        mysqli_stmt_close($item_stmt);

        // Sab sahi raha toh save karein
        mysqli_commit($conn);

        // 5. Redirection Logic
        if ($payment_mode == 'Online') {
            // Online payment ke liye gateway par bhejein
            header("Location: payment-gateway.php?order_id=$order_id");
        } else {
            // COD ke liye cart khali karein aur success par bhejein
            unset($_SESSION['cart']);
            header("Location: order-success.php?order_id=$order_id&status=cod");
        }

    } catch (Exception $e) {
        // Agar kuch galat hua toh roll back karein
        mysqli_rollback($conn);
        header("Location: checkout.php?error=" . urlencode($e->getMessage()));
    }
} else {
    header("Location: checkout.php");
}
?>
