<?php
/**
 * QuickBite - Printable Invoice
 * File: user/invoice.php
 */
require_once(__DIR__ . '/../config/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$order_id = (int)($_GET['order_id'] ?? 0);
$user_id = (int)$_SESSION['user_id'];

if ($order_id <= 0) {
    header("Location: payment-history.php");
    exit();
}

$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

$invoice = null;
$stmt = mysqli_prepare(
    $conn,
    "SELECT o.id, o.user_id, o.total_amount, o.order_date, o.order_status, o.payment_mode, o.payment_status,
            o.transaction_id, o.delivery_address, u.name, u.email, u.phone
     FROM orders o
     INNER JOIN users u ON u.id = o.user_id
     WHERE o.id = ? AND o.user_id = ?
     LIMIT 1"
);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        $invoice = mysqli_fetch_assoc($result) ?: null;
    }
    mysqli_stmt_close($stmt);
}

if (!$invoice) {
    header("Location: payment-history.php");
    exit();
}

$is_paid_invoice = (($invoice['payment_status'] ?? '') === 'Paid')
    || ((($invoice['payment_mode'] ?? '') === 'COD') && (($invoice['order_status'] ?? '') === 'Delivered'));

if (!$is_paid_invoice) {
    header("Location: my-orders.php");
    exit();
}

$items = [];
$items_stmt = mysqli_prepare(
    $conn,
    "SELECT oi.quantity, oi.price, f.title
     FROM order_items oi
     INNER JOIN foods f ON f.id = oi.food_id
     WHERE oi.order_id = ?"
);
if ($items_stmt) {
    mysqli_stmt_bind_param($items_stmt, "i", $order_id);
    mysqli_stmt_execute($items_stmt);
    $result = mysqli_stmt_get_result($items_stmt);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $items[] = $row;
        }
    }
    mysqli_stmt_close($items_stmt);
}

$subtotal = 0.0;
foreach ($items as $item) {
    $subtotal += ((float)($item['price'] ?? 0) * (int)($item['quantity'] ?? 0));
}
$item_count = 0;
foreach ($items as $item) {
    $item_count += (int)($item['quantity'] ?? 0);
}
$total = (float)($invoice['total_amount'] ?? 0);
$delivery_fee = max(0, $total - $subtotal);
$txn = trim((string)($invoice['transaction_id'] ?? ''));
$reference = $txn !== '' ? $txn : 'COD-COLLECTED-' . qb_order_display_id($order_id);
$print_mode = isset($_GET['print']) && $_GET['print'] === '1';
$payment_mode = (string)($invoice['payment_mode'] ?? 'COD');
$payment_status = (string)($invoice['payment_status'] ?? (($payment_mode === 'COD') ? 'Cash Paid' : 'Paid'));
$order_status = (string)($invoice['order_status'] ?? 'Delivered');
$payment_label = ($payment_mode === 'COD') ? 'Cash Paid' : 'Online Paid';
$invoice_date = date('d M Y, h:i A', strtotime((string)($invoice['order_date'] ?? 'now')));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?php echo qb_order_display_id((int)$order_id); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(180deg, #fff5f3 0%, #f8f9fa 100%);
            color: #2f3542;
        }
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        .invoice-shell {
            max-width: 960px;
            margin: 24px auto;
            padding: 0 14px;
        }
        .invoice-card {
            background: #fff;
            border-radius: 30px;
            border: 1px solid rgba(47,53,66,0.08);
            box-shadow: 0 28px 60px rgba(47,53,66,0.10);
            overflow: hidden;
        }
        .invoice-head {
            background: linear-gradient(135deg, #ff4757, #ff7b72);
            color: #fff;
            padding: 24px 28px;
        }
        .brand-row {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            flex-wrap: wrap;
            align-items: center;
        }
        .invoice-brand {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .brand-icon {
            width: 58px;
            height: 58px;
            border-radius: 18px;
            background: rgba(255,255,255,0.18);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        .invoice-body { padding: 24px 28px 28px; }
        .invoice-meta {
            display: grid;
            grid-template-columns: minmax(0, 1.2fr) minmax(260px, 0.8fr);
            gap: 16px;
            margin-bottom: 18px;
        }
        .hero-panel,
        .status-panel {
            border-radius: 24px;
            border: 1px solid rgba(47,53,66,0.08);
            background: linear-gradient(180deg, #ffffff 0%, #fff8f7 100%);
            padding: 18px 20px;
        }
        .hero-panel {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            align-items: center;
        }
        .hero-kicker,
        .mini-label,
        .info-card span,
        .amount-line span {
            display: block;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #8b95a7;
            margin-bottom: 8px;
            font-weight: 700;
        }
        .hero-title {
            font-size: 28px;
            font-weight: 800;
            line-height: 1.15;
            margin-bottom: 6px;
            color: #1f2937;
        }
        .hero-copy {
            color: #6b7280;
            margin: 0;
            font-size: 14px;
        }
        .invoice-code {
            min-width: 150px;
            text-align: right;
        }
        .status-panel {
            display: flex;
            flex-direction: column;
            gap: 12px;
            justify-content: center;
        }
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            width: fit-content;
            border-radius: 999px;
            padding: 10px 16px;
            font-size: 13px;
            font-weight: 700;
        }
        .status-badge.success {
            background: #e8f7ef;
            color: #16824f;
            border: 1px solid rgba(22,130,79,0.16);
        }
        .status-badge .icon {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: currentColor;
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            flex-shrink: 0;
        }
        .status-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 10px 14px;
        }
        .status-grid strong {
            display: block;
            color: #1f2937;
            font-size: 15px;
            word-break: break-word;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
            margin-bottom: 18px;
        }
        .info-card {
            background: #fafbfc;
            border: 1px solid rgba(47,53,66,0.07);
            border-radius: 22px;
            padding: 16px 18px;
        }
        .info-card strong {
            display: block;
            font-size: 15px;
            word-break: break-word;
        }
        .info-line {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            padding: 8px 0;
            border-bottom: 1px dashed rgba(47,53,66,0.08);
            font-size: 14px;
        }
        .info-line:last-child {
            border-bottom: 0;
            padding-bottom: 0;
        }
        .info-line strong {
            font-size: 14px;
            text-align: right;
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 12px;
            color: #1f2937;
        }
        .section-title i {
            color: #d63045;
        }
        .section-title h3 {
            font-size: 17px;
            font-weight: 700;
            margin: 0;
        }
        .table-wrap {
            border: 1px solid rgba(47,53,66,0.07);
            border-radius: 22px;
            overflow: hidden;
        }
        .table thead th {
            background: #fff5f5;
            color: #d63045;
            border-bottom: 0;
            font-size: 12px;
            letter-spacing: 0.06em;
            text-transform: uppercase;
        }
        .table > :not(caption) > * > * {
            padding: 16px 18px;
            border-color: rgba(47,53,66,0.07);
        }
        .item-meta {
            display: block;
            margin-top: 4px;
            font-size: 12px;
            color: #8b95a7;
        }
        .summary-box {
            margin-left: auto;
            width: min(100%, 360px);
            background: #fff8f7;
            border: 1px solid rgba(255,71,87,0.12);
            border-radius: 22px;
            padding: 18px 20px;
            break-inside: avoid;
        }
        .amount-line {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            margin-bottom: 12px;
            align-items: end;
        }
        .amount-line strong {
            font-size: 16px;
        }
        .amount-line.total strong {
            font-size: 24px;
            color: #d63045;
        }
        .invoice-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 24px;
        }
        @media print {
            @page {
                size: A4;
                margin: 8mm;
            }
            body { background: #fff; }
            .invoice-shell { margin: 0; max-width: none; padding: 0; }
            .invoice-card { box-shadow: none; border-radius: 0; border: 0; }
            .invoice-actions { display: none !important; }
            .invoice-head { padding: 20px 22px; }
            .invoice-body { padding: 18px 22px 22px; }
            .hero-title { font-size: 24px; }
            .hero-copy, .info-card div, .info-line, .table { font-size: 13px; }
            .table > :not(caption) > * > * { padding: 12px 14px; }
            .summary-box { padding: 16px 18px; }
            .table-wrap, .summary-box, .info-card, .hero-panel, .status-panel { break-inside: avoid; }
        }
        @media (max-width: 767.98px) {
            .invoice-head, .invoice-body { padding: 22px; }
            .invoice-meta,
            .info-grid { grid-template-columns: 1fr; }
            .hero-panel {
                flex-direction: column;
                align-items: flex-start;
            }
            .invoice-code {
                text-align: left;
            }
            .status-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body<?php echo $print_mode ? ' onload="window.print()"' : ''; ?>>
    <div class="invoice-shell">
        <div class="invoice-card">
            <div class="invoice-head">
                <div class="brand-row">
                    <div class="invoice-brand">
                        <div class="brand-icon"><i class="fas fa-basket-shopping"></i></div>
                        <div>
                            <div class="fw-bold text-uppercase small mb-1">Food Monu</div>
                            <h2 class="fw-bold mb-1">Payment Invoice</h2>
                            <div class="opacity-75">Order, payment aur billing details ek hi print-ready invoice mein</div>
                        </div>
                    </div>
                    <div class="text-md-end">
                        <div class="small text-uppercase opacity-75">Invoice No</div>
                        <div class="fs-4 fw-bold">#<?php echo qb_order_display_id((int)$order_id); ?></div>
                    </div>
                </div>
            </div>

            <div class="invoice-body">
                <div class="invoice-meta">
                    <div class="hero-panel">
                        <div>
                            <span class="hero-kicker">Customer Invoice</span>
                            <div class="hero-title">Order #<?php echo qb_order_display_id((int)$order_id); ?></div>
                            <p class="hero-copy">Customer, order timing, item count aur payment reference sabhi details yahan clear format mein milengi.</p>
                        </div>
                        <div class="invoice-code">
                            <span class="mini-label">Generated On</span>
                            <strong><?php echo $h($invoice_date); ?></strong>
                        </div>
                    </div>
                    <div class="status-panel">
                        <span class="status-badge success">
                            <span class="icon"><i class="fas fa-check"></i></span>
                            <?php echo $h($payment_label); ?>
                        </span>
                        <div class="status-grid">
                            <div>
                                <span class="mini-label mb-1">Payment Mode</span>
                                <strong><?php echo $h($payment_mode); ?></strong>
                            </div>
                            <div>
                                <span class="mini-label mb-1">Order Status</span>
                                <strong><?php echo $h($order_status); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="info-grid">
                    <div class="info-card">
                        <span>Billed To</span>
                        <strong><?php echo $h($invoice['name'] ?? 'Customer'); ?></strong>
                        <div><?php echo $h($invoice['email'] ?? '-'); ?></div>
                        <div><?php echo $h($invoice['phone'] ?? '-'); ?></div>
                    </div>
                    <div class="info-card">
                        <span>Delivery Address</span>
                        <strong><?php echo $h($invoice['delivery_address'] ?? '-'); ?></strong>
                    </div>
                    <div class="info-card">
                        <span>Payment Details</span>
                        <div class="info-line">
                            <span>Method</span>
                            <strong><?php echo $h($payment_mode); ?></strong>
                        </div>
                        <div class="info-line">
                            <span>Status</span>
                            <strong><?php echo $h($payment_status ?: $payment_label); ?></strong>
                        </div>
                        <div class="info-line">
                            <span>Reference</span>
                            <strong><?php echo $h($reference); ?></strong>
                        </div>
                    </div>
                    <div class="info-card">
                        <span>Order Details</span>
                        <div class="info-line">
                            <span>Order Date</span>
                            <strong><?php echo $h($invoice_date); ?></strong>
                        </div>
                        <div class="info-line">
                            <span>Total Items</span>
                            <strong><?php echo (int)$item_count; ?></strong>
                        </div>
                        <div class="info-line">
                            <span>Order Status</span>
                            <strong><?php echo $h($order_status); ?></strong>
                        </div>
                    </div>
                </div>

                <div class="section-title">
                    <i class="fas fa-utensils"></i>
                    <h3>Ordered Items</h3>
                </div>
                <div class="table-wrap mb-4">
                    <table class="table mb-0 align-middle">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th class="text-center">Qty</th>
                                <th class="text-end">Price</th>
                                <th class="text-end">Line Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item):
                                $qty = (int)($item['quantity'] ?? 0);
                                $price = (float)($item['price'] ?? 0);
                                $line_total = $qty * $price;
                            ?>
                            <tr>
                                <td class="fw-semibold">
                                    <?php echo $h($item['title'] ?? 'Food Item'); ?>
                                    <span class="item-meta">Unit price: <?php echo '&#8377;' . $h(number_format($price, 2)); ?></span>
                                </td>
                                <td class="text-center"><?php echo $qty; ?></td>
                                <td class="text-end"><?php echo '&#8377;' . $h(number_format($price, 2)); ?></td>
                                <td class="text-end"><?php echo '&#8377;' . $h(number_format($line_total, 2)); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="summary-box">
                    <div class="amount-line">
                        <span>Subtotal</span>
                        <strong><?php echo '&#8377;' . $h(number_format($subtotal, 2)); ?></strong>
                    </div>
                    <div class="amount-line">
                        <span>Delivery Fee</span>
                        <strong><?php echo '&#8377;' . $h(number_format($delivery_fee, 2)); ?></strong>
                    </div>
                    <div class="amount-line total mb-0">
                        <span>Total Paid</span>
                        <strong><?php echo '&#8377;' . $h(number_format($total, 2)); ?></strong>
                    </div>
                </div>

                <div class="invoice-actions">
                    <a href="payment-history.php" class="btn btn-outline-dark rounded-pill px-4 fw-bold">
                        <i class="fas fa-arrow-left me-2"></i>Back
                    </a>
                    <a href="invoice.php?order_id=<?php echo $order_id; ?>&print=1" class="btn btn-danger rounded-pill px-4 fw-bold">
                        <i class="fas fa-print me-2"></i>Print Invoice
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
