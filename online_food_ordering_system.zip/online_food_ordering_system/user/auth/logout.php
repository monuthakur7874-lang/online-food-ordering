<?php
/**
 * QuickBite - Secure Logout System
 * File: user/auth/logout.php
 */

// Load project session settings (session name/path/lifetime) first
require_once(__DIR__ . '/../../config/db.php');

// Ensure session started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 2. Saare session variables ko khali (unset) karein
$_SESSION = array();

// 3. Agar session cookie exist karti hai, toh use expire karein (Extra Security)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    $cookie_name = session_name();
    $expires = time() - 42000;

    if (PHP_VERSION_ID >= 70300) {
        setcookie($cookie_name, '', [
            'expires' => $expires,
            'path' => $params['path'] ?? '/',
            'domain' => $params['domain'] ?? '',
            'secure' => (bool)($params['secure'] ?? false),
            'httponly' => (bool)($params['httponly'] ?? true),
            'samesite' => 'Lax',
        ]);
    } else {
        setcookie(
            $cookie_name,
            '',
            $expires,
            $params["path"] ?? '/',
            $params["domain"] ?? '',
            (bool)($params["secure"] ?? false),
            (bool)($params["httponly"] ?? true)
        );
    }
}

// 4. Session ko server se poori tarah destroy karein
session_destroy();

// 5. User ko login page par redirect karein ek message ke saath
header("Location: login.php?msg=You have been successfully logged out.");
exit();
?>
