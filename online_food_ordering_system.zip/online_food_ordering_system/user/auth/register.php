<?php
include('../../config/db.php');
require_once(__DIR__ . '/../includes/csrf.php');

$error = "";
$success = "";
$field_errors = [];
$form = ['name' => '', 'phone' => '', 'email' => '', 'address' => ''];

if (isset($_POST['register'])) {
    $form['name'] = trim((string)($_POST['name'] ?? ''));
    $form['phone'] = preg_replace('/\D+/', '', (string)($_POST['phone'] ?? ''));
    $form['email'] = strtolower(trim((string)($_POST['email'] ?? '')));
    $form['address'] = trim((string)($_POST['address'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirm_password = (string)($_POST['confirm_password'] ?? '');

    if (!qb_csrf_validate((string)($_POST['csrf_token'] ?? ''))) {
        $error = "Security check failed. Please refresh and try again.";
    } else {
        if ($form['name'] === '') {
            $field_errors['name'] = "Full name is required.";
        } elseif (!preg_match("/^[A-Za-z][A-Za-z .'-]{2,59}$/", $form['name'])) {
            $field_errors['name'] = "Use 3 to 60 characters with letters and basic separators only.";
        }

        if ($form['phone'] === '') {
            $field_errors['phone'] = "Phone number is required.";
        } elseif (!preg_match('/^[6-9][0-9]{9}$/', $form['phone'])) {
            $field_errors['phone'] = "Enter a valid 10-digit Indian mobile number.";
        }

        if ($form['email'] === '') {
            $field_errors['email'] = "Email address is required.";
        } elseif (!filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
            $field_errors['email'] = "Enter a valid email address.";
        }

        if ($form['address'] === '') {
            $field_errors['address'] = "Delivery address is required.";
        } elseif (mb_strlen($form['address']) < 12) {
            $field_errors['address'] = "Address must be at least 12 characters.";
        } elseif (mb_strlen($form['address']) > 220) {
            $field_errors['address'] = "Address is too long.";
        }

        if ($password === '') {
            $field_errors['password'] = "Password is required.";
        } else {
            $password_rules = [
                'length' => strlen($password) >= 8,
                'upper' => preg_match('/[A-Z]/', $password),
                'lower' => preg_match('/[a-z]/', $password),
                'digit' => preg_match('/[0-9]/', $password),
                'special' => preg_match('/[^A-Za-z0-9]/', $password),
            ];
            if (in_array(false, $password_rules, true)) {
                $field_errors['password'] = "Use 8+ chars with upper, lower, number and special character.";
            }
        }

        if ($confirm_password === '') {
            $field_errors['confirm_password'] = "Please confirm your password.";
        } elseif ($password !== $confirm_password) {
            $field_errors['confirm_password'] = "Passwords do not match.";
        }

        if (!$field_errors) {
            $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ? LIMIT 1");
            if (!$stmt) {
                $error = "We could not create your account right now. Please try again.";
            } else {
                mysqli_stmt_bind_param($stmt, "s", $form['email']);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_bind_result($stmt, $existing_id);
                $exists = mysqli_stmt_fetch($stmt);
                mysqli_stmt_close($stmt);

                if ($exists) {
                    $field_errors['email'] = "An account with this email already exists.";
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = mysqli_prepare($conn, "INSERT INTO users (name, email, password, phone, address, role, status) VALUES (?, ?, ?, ?, ?, 'user', 'Active')");
                    if (!$stmt) {
                        $error = "We could not create your account right now. Please try again.";
                    } else {
                        mysqli_stmt_bind_param($stmt, "sssss", $form['name'], $form['email'], $hashed_password, $form['phone'], $form['address']);
                        if (mysqli_stmt_execute($stmt)) {
                            $success = "Registration successful. Redirecting to login...";
                            header("refresh:2;url=login.php");
                            $form = ['name' => '', 'phone' => '', 'email' => '', 'address' => ''];
                        } else {
                            $error = "Something went wrong while saving your account. Please try again.";
                        }
                        mysqli_stmt_close($stmt);
                    }
                }
            }
        }

        if (!$error && $field_errors) {
            $error = "Please fix the highlighted fields and try again.";
        }
    }
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | Food Monu</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --fm-red:#ff4757; --fm-red-dark:#e03143; --fm-ink:#273043; --fm-muted:#6c7688; --fm-border:#e6eaf0; --fm-bg:#f6f8fb; --fm-danger:#d92d20; --fm-success:#16a34a; }
        * { box-sizing:border-box; }
        body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center; padding:24px; font-family:'Poppins',sans-serif; color:var(--fm-ink); background:radial-gradient(circle at top left, rgba(255,71,87,.14), transparent 28%), linear-gradient(180deg, #fff8f8 0%, var(--fm-bg) 38%, #eff3f8 100%); }
        .auth-shell { width:100%; max-width:620px; }
        .auth-card { background:rgba(255,255,255,.96); border:1px solid rgba(255,71,87,.08); border-radius:32px; padding:34px; box-shadow:0 24px 60px rgba(39,48,67,.10); }
        .brand-logo { text-align:center; color:var(--fm-red); font-size:1.95rem; font-weight:800; line-height:1; margin-bottom:10px; }
        .auth-title { text-align:center; font-size:1.65rem; font-weight:800; margin-bottom:8px; }
        .auth-subtitle { text-align:center; color:var(--fm-muted); margin-bottom:28px; }
        .field-group { margin-bottom:18px; }
        .field-label { display:flex; align-items:center; justify-content:space-between; margin-bottom:8px; font-size:.92rem; font-weight:700; color:#5d6779; }
        .form-control { border-radius:18px; border:1px solid var(--fm-border); background:#fcfdff; padding:14px 16px; min-height:56px; box-shadow:none !important; transition:border-color .18s ease, background .18s ease; }
        textarea.form-control { min-height:110px; resize:vertical; }
        .form-control:focus { border-color:rgba(255,71,87,.55); background:#fff; }
        .password-wrap { position:relative; }
        .toggle-password { position:absolute; right:14px; top:50%; transform:translateY(-50%); border:0; background:transparent; color:#8a94a6; padding:6px; }
        .field-error,.field-help { display:block; font-size:.82rem; margin-top:8px; }
        .field-help { color:var(--fm-muted); }
        .field-error { color:var(--fm-danger); min-height:18px; }
        .field-error:empty { display:none; }
        .form-control.is-invalid { border-color:rgba(217,45,32,.5); background:#fff8f7; }
        .form-control.is-valid { border-color:rgba(22,163,74,.42); background:#f7fff9; }
        .password-checklist { margin:10px 0 0; padding:0; list-style:none; display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:6px 12px; }
        .password-checklist li { font-size:.8rem; color:var(--fm-muted); }
        .password-checklist li.valid { color:var(--fm-success); font-weight:600; }
        .alert { border:0; border-radius:18px; padding:14px 16px; font-size:.92rem; }
        .btn-reg { width:100%; border:0; border-radius:18px; min-height:58px; background:linear-gradient(135deg, var(--fm-red), var(--fm-red-dark)); color:#fff; font-weight:800; letter-spacing:.03em; transition:transform .18s ease, box-shadow .18s ease; box-shadow:0 18px 30px rgba(255,71,87,.20); }
        .btn-reg:hover { transform:translateY(-1px); }
        .auth-footer { text-align:center; margin-top:24px; color:var(--fm-muted); }
        .auth-footer a { color:var(--fm-red-dark); font-weight:700; text-decoration:none; }
        @media (max-width:575.98px) { .auth-card { padding:24px; } .password-checklist { grid-template-columns:1fr; } }
    </style>
</head>
<body>
<div class="auth-shell">
    <div class="auth-card">
        <div class="brand-logo"><i class="fas fa-utensils me-2"></i>Food Monu</div>
        <div class="auth-title">Create Your Account</div>
        <p class="auth-subtitle">Use a real email, strong password, and complete delivery details.</p>

        <?php if ($error !== ""): ?>
            <div class="alert alert-danger mb-4"><i class="fas fa-circle-exclamation me-2"></i><?php echo e($error); ?></div>
        <?php endif; ?>
        <?php if ($success !== ""): ?>
            <div class="alert alert-success mb-4"><i class="fas fa-circle-check me-2"></i><?php echo e($success); ?></div>
        <?php endif; ?>

        <form action="<?php echo e((string)$_SERVER['PHP_SELF']); ?>" method="POST" id="regForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo e(qb_csrf_token()); ?>">

            <div class="row">
                <div class="col-md-6 field-group">
                    <label class="field-label" for="name">Full Name</label>
                    <input type="text" name="name" id="name" class="form-control <?php echo isset($field_errors['name']) ? 'is-invalid' : ''; ?>" value="<?php echo e($form['name']); ?>" placeholder="John Doe" autocomplete="name" required>
                    <span class="field-error" data-error-for="name"><?php echo e($field_errors['name'] ?? ''); ?></span>
                </div>
                <div class="col-md-6 field-group">
                    <label class="field-label" for="phone">Phone Number</label>
                    <input type="tel" name="phone" id="phone" class="form-control <?php echo isset($field_errors['phone']) ? 'is-invalid' : ''; ?>" value="<?php echo e($form['phone']); ?>" placeholder="9876543210" inputmode="numeric" maxlength="10" autocomplete="tel" required>
                    <span class="field-error" data-error-for="phone"><?php echo e($field_errors['phone'] ?? ''); ?></span>
                </div>
            </div>

            <div class="field-group">
                <label class="field-label" for="email">Email Address</label>
                <input type="email" name="email" id="email" class="form-control <?php echo isset($field_errors['email']) ? 'is-invalid' : ''; ?>" value="<?php echo e($form['email']); ?>" placeholder="name@example.com" autocomplete="email" required>
                <span class="field-error" data-error-for="email"><?php echo e($field_errors['email'] ?? ''); ?></span>
            </div>

            <div class="field-group">
                <label class="field-label" for="address">Delivery Address</label>
                <textarea name="address" id="address" class="form-control <?php echo isset($field_errors['address']) ? 'is-invalid' : ''; ?>" placeholder="House no, street, area, city, pincode" autocomplete="street-address" required><?php echo e($form['address']); ?></textarea>
                <span class="field-help">Add enough detail so delivery can reach you without a phone call.</span>
                <span class="field-error" data-error-for="address"><?php echo e($field_errors['address'] ?? ''); ?></span>
            </div>

            <div class="row">
                <div class="col-md-6 field-group">
                    <label class="field-label" for="password">Password</label>
                    <div class="password-wrap">
                        <input type="password" name="password" id="password" class="form-control <?php echo isset($field_errors['password']) ? 'is-invalid' : ''; ?>" placeholder="Create a strong password" autocomplete="new-password" required>
                        <button type="button" class="toggle-password" data-toggle-password="password" aria-label="Show password"><i class="fas fa-eye"></i></button>
                    </div>
                    <ul class="password-checklist" id="passwordChecklist">
                        <li data-rule="length">At least 8 characters</li>
                        <li data-rule="upper">One uppercase letter</li>
                        <li data-rule="lower">One lowercase letter</li>
                        <li data-rule="digit">One number</li>
                        <li data-rule="special">One special character</li>
                    </ul>
                    <span class="field-error" data-error-for="password"><?php echo e($field_errors['password'] ?? ''); ?></span>
                </div>
                <div class="col-md-6 field-group">
                    <label class="field-label" for="confirm_password">Confirm Password</label>
                    <div class="password-wrap">
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control <?php echo isset($field_errors['confirm_password']) ? 'is-invalid' : ''; ?>" placeholder="Re-enter password" autocomplete="new-password" required>
                        <button type="button" class="toggle-password" data-toggle-password="confirm_password" aria-label="Show confirm password"><i class="fas fa-eye"></i></button>
                    </div>
                    <span class="field-error" data-error-for="confirm_password"><?php echo e($field_errors['confirm_password'] ?? ''); ?></span>
                </div>
            </div>

            <button type="submit" name="register" class="btn-reg mt-2">CREATE ACCOUNT</button>

            <div class="auth-footer">
                Already have an account?<br>
                <a href="login.php">Login here</a>
            </div>
        </form>
    </div>
</div>

<script>
(() => {
    const form = document.getElementById('regForm');
    const nameInput = document.getElementById('name');
    const phoneInput = document.getElementById('phone');
    const emailInput = document.getElementById('email');
    const addressInput = document.getElementById('address');
    const passwordInput = document.getElementById('password');
    const confirmInput = document.getElementById('confirm_password');

    function setFieldState(input, message) {
        const errorNode = form.querySelector('[data-error-for="' + input.name + '"]');
        input.classList.remove('is-invalid', 'is-valid');
        if (message) {
            input.classList.add('is-invalid');
            if (errorNode) errorNode.textContent = message;
            return false;
        }
        if (input.value.trim() !== '') input.classList.add('is-valid');
        if (errorNode) errorNode.textContent = '';
        return true;
    }

    function validateName() {
        const value = nameInput.value.trim();
        if (!value) return setFieldState(nameInput, 'Full name is required.');
        if (!/^[A-Za-z][A-Za-z .'-]{2,59}$/.test(value)) return setFieldState(nameInput, 'Use 3 to 60 characters with letters and basic separators only.');
        return setFieldState(nameInput, '');
    }

    function validatePhone() {
        phoneInput.value = phoneInput.value.replace(/\D+/g, '').slice(0, 10);
        const value = phoneInput.value;
        if (!value) return setFieldState(phoneInput, 'Phone number is required.');
        if (!/^[6-9][0-9]{9}$/.test(value)) return setFieldState(phoneInput, 'Enter a valid 10-digit Indian mobile number.');
        return setFieldState(phoneInput, '');
    }

    function validateEmail() {
        const value = emailInput.value.trim();
        if (!value) return setFieldState(emailInput, 'Email address is required.');
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return setFieldState(emailInput, 'Enter a valid email address.');
        return setFieldState(emailInput, '');
    }

    function validateAddress() {
        const value = addressInput.value.trim();
        if (!value) return setFieldState(addressInput, 'Delivery address is required.');
        if (value.length < 12) return setFieldState(addressInput, 'Address must be at least 12 characters.');
        if (value.length > 220) return setFieldState(addressInput, 'Address is too long.');
        return setFieldState(addressInput, '');
    }

    function passwordRules(value) {
        return {
            length: value.length >= 8,
            upper: /[A-Z]/.test(value),
            lower: /[a-z]/.test(value),
            digit: /[0-9]/.test(value),
            special: /[^A-Za-z0-9]/.test(value)
        };
    }

    function updatePasswordChecklist() {
        const rules = passwordRules(passwordInput.value);
        document.querySelectorAll('#passwordChecklist [data-rule]').forEach((item) => {
            item.classList.toggle('valid', !!rules[item.getAttribute('data-rule')]);
        });
        return rules;
    }

    function validatePassword() {
        const value = passwordInput.value;
        const rules = updatePasswordChecklist();
        if (!value) return setFieldState(passwordInput, 'Password is required.');
        if (Object.values(rules).includes(false)) return setFieldState(passwordInput, 'Use 8+ chars with upper, lower, number and special character.');
        return setFieldState(passwordInput, '');
    }

    function validateConfirmPassword() {
        const value = confirmInput.value;
        if (!value) return setFieldState(confirmInput, 'Please confirm your password.');
        if (value !== passwordInput.value) return setFieldState(confirmInput, 'Passwords do not match.');
        return setFieldState(confirmInput, '');
    }

    nameInput.addEventListener('input', validateName);
    phoneInput.addEventListener('input', validatePhone);
    emailInput.addEventListener('input', validateEmail);
    addressInput.addEventListener('input', validateAddress);
    passwordInput.addEventListener('input', () => {
        validatePassword();
        if (confirmInput.value !== '') validateConfirmPassword();
    });
    confirmInput.addEventListener('input', validateConfirmPassword);

    form.addEventListener('submit', (event) => {
        const checks = [validateName(), validatePhone(), validateEmail(), validateAddress(), validatePassword(), validateConfirmPassword()];
        if (checks.includes(false)) event.preventDefault();
    });

    document.querySelectorAll('[data-toggle-password]').forEach((button) => {
        button.addEventListener('click', () => {
            const target = document.getElementById(button.getAttribute('data-toggle-password'));
            const icon = button.querySelector('i');
            const showing = target.type === 'text';
            target.type = showing ? 'password' : 'text';
            icon.className = showing ? 'fas fa-eye' : 'fas fa-eye-slash';
        });
    });

    updatePasswordChecklist();
})();
</script>
</body>
</html>
