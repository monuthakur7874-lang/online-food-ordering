<?php
include('../../config/db.php');
require_once(__DIR__ . '/../includes/csrf.php');

$error = "";
$form = ['email' => ''];

if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['user_role'] ?? 'user';
    if ($role === 'admin') {
        header("Location: ../../admin/");
    } elseif ($role === 'delivery') {
        header("Location: ../../delivery/");
    } else {
        header("Location: ../index.php");
    }
    exit();
}

if (!isset($_SESSION['login_attempts']) || !is_array($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = ['count' => 0, 'locked_until' => 0];
}

$login_attempts = &$_SESSION['login_attempts'];
$remaining_lock_seconds = max(0, (int)$login_attempts['locked_until'] - time());

if (isset($_POST['login'])) {
    $form['email'] = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if (!qb_csrf_validate((string)($_POST['csrf_token'] ?? ''))) {
        $error = "Security check failed. Please refresh and try again.";
    } elseif ($remaining_lock_seconds > 0) {
        $error = "Too many login attempts. Try again in {$remaining_lock_seconds} seconds.";
    } elseif ($form['email'] === '' || $password === '') {
        $error = "Email and password are required.";
    } elseif (!filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
        $error = "Enter a valid email address.";
    } else {
        $email = strtolower($form['email']);
        $stmt = mysqli_prepare($conn, "SELECT id, name, role, status, password FROM users WHERE email = ? LIMIT 1");

        if (!$stmt) {
            $error = "We could not process your login right now. Please try again.";
        } else {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $uid, $uname, $urole, $ustatus, $upass_hash);
            $user_found = mysqli_stmt_fetch($stmt);
            mysqli_stmt_close($stmt);

            $is_valid = false;
            if ($user_found && is_string($upass_hash)) {
                if (password_verify($password, $upass_hash) || $password === $upass_hash) {
                    $is_valid = true;
                }
            }

            if (!$user_found || !$is_valid || $ustatus !== 'Active') {
                $login_attempts['count'] = (int)$login_attempts['count'] + 1;

                if ($login_attempts['count'] >= 5) {
                    $login_attempts['locked_until'] = time() + 120;
                    $login_attempts['count'] = 0;
                    $error = "Too many failed attempts. Login is locked for 2 minutes.";
                } else {
                    $left = 5 - (int)$login_attempts['count'];
                    $error = "Invalid email or password. {$left} attempt(s) left.";
                }
            } else {
                $login_attempts = ['count' => 0, 'locked_until' => 0];

                if ($urole === 'admin') {
                    header("Location: ../../admin/?msg=Please+login+from+Admin+panel");
                    exit();
                }
                if ($urole === 'delivery') {
                    header("Location: ../../delivery/?msg=Please+login+from+Delivery+panel");
                    exit();
                }

                $_SESSION['user_id'] = (int)$uid;
                $_SESSION['user_name'] = (string)$uname;
                $_SESSION['user_role'] = 'user';
                session_regenerate_id(true);

                if (is_string($upass_hash) && $password === $upass_hash) {
                    $new_hash = password_hash($password, PASSWORD_DEFAULT);
                    $upgrade_stmt = mysqli_prepare($conn, "UPDATE users SET password = ? WHERE id = ? LIMIT 1");
                    if ($upgrade_stmt) {
                        mysqli_stmt_bind_param($upgrade_stmt, "si", $new_hash, $uid);
                        mysqli_stmt_execute($upgrade_stmt);
                        mysqli_stmt_close($upgrade_stmt);
                    }
                }

                header("Location: ../index.php");
                exit();
            }
        }
    }
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | QuickBite</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { --fm-red:#ff4757; --fm-red-dark:#e03143; --fm-ink:#273043; --fm-muted:#6c7688; --fm-border:#e6eaf0; --fm-bg:#f6f8fb; --fm-danger:#d92d20; --fm-success:#16a34a; }
        * { box-sizing:border-box; }
        body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center; padding:24px; font-family:'Poppins',sans-serif; color:var(--fm-ink); background:radial-gradient(circle at top left, rgba(255,71,87,.14), transparent 28%), linear-gradient(180deg, #fff8f8 0%, var(--fm-bg) 38%, #eff3f8 100%); }
        .auth-shell { width:100%; max-width:470px; }
        .auth-card { background:rgba(255,255,255,.96); border:1px solid rgba(255,71,87,.08); border-radius:32px; padding:34px; box-shadow:0 24px 60px rgba(39,48,67,.10); }
        .brand-logo { text-align:center; color:var(--fm-red); font-size:2.1rem; font-weight:800; line-height:1; margin-bottom:10px; }
        .auth-subtitle { text-align:center; color:var(--fm-muted); margin-bottom:28px; }
        .field-group { margin-bottom:18px; }
        .field-label { display:flex; align-items:center; justify-content:space-between; margin-bottom:8px; font-size:.92rem; font-weight:700; color:#5d6779; }
        .form-control { border-radius:18px; border:1px solid var(--fm-border); background:#fcfdff; padding:14px 16px; min-height:56px; box-shadow:none !important; transition:border-color .18s ease, background .18s ease; }
        .form-control:focus { border-color:rgba(255,71,87,.55); background:#fff; }
        .password-wrap { position:relative; }
        .toggle-password { position:absolute; right:14px; top:50%; transform:translateY(-50%); border:0; background:transparent; color:#8a94a6; padding:6px; }
        .field-help,.field-error { display:block; font-size:.82rem; margin-top:8px; }
        .field-help { color:var(--fm-muted); }
        .field-error { color:var(--fm-danger); min-height:18px; }
        .field-error:empty { display:none; }
        .form-control.is-invalid { border-color:rgba(217,45,32,.5); background:#fff8f7; }
        .form-control.is-valid { border-color:rgba(22,163,74,.42); background:#f7fff9; }
        .alert { border:0; border-radius:18px; padding:14px 16px; font-size:.92rem; }
        .btn-login { width:100%; border:0; border-radius:18px; min-height:58px; background:linear-gradient(135deg, var(--fm-red), var(--fm-red-dark)); color:#fff; font-weight:800; letter-spacing:.03em; transition:transform .18s ease, box-shadow .18s ease, opacity .18s ease; box-shadow:0 18px 30px rgba(255,71,87,.20); }
        .btn-login:hover { transform:translateY(-1px); }
        .auth-footer { text-align:center; margin-top:24px; color:var(--fm-muted); }
        .auth-footer a { color:var(--fm-red-dark); font-weight:700; text-decoration:none; }
    </style>
</head>
<body>
<div class="auth-shell">
    <div class="auth-card">
        <div class="brand-logo"><i class="fas fa-utensils me-2"></i>QuickBite</div>
        <p class="auth-subtitle">Login to manage your orders with a secure account flow.</p>

        <?php if ($error !== ""): ?>
            <div class="alert alert-danger mb-4"><i class="fas fa-circle-exclamation me-2"></i><?php echo e($error); ?></div>
        <?php endif; ?>

        <form action="<?php echo e((string)$_SERVER['PHP_SELF']); ?>" method="POST" id="loginForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo e(qb_csrf_token()); ?>">

            <div class="field-group">
                <label class="field-label" for="email">Email Address</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="name@example.com" value="<?php echo e($form['email']); ?>" autocomplete="email" required>
                <span class="field-error" data-error-for="email"></span>
            </div>

            <div class="field-group">
                <label class="field-label" for="password">Password</label>
                <div class="password-wrap">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" autocomplete="current-password" required>
                    <button type="button" class="toggle-password" data-toggle-password="password" aria-label="Show password"><i class="fas fa-eye"></i></button>
                </div>
                <span class="field-help">Use the same password you created during registration.</span>
                <span class="field-error" data-error-for="password"></span>
            </div>

            <button type="submit" name="login" class="btn-login mt-2">LOG IN</button>

            <div class="auth-footer">
                New here?<br>
                <a href="register.php">Create an account</a>
            </div>
        </form>
    </div>
</div>

<script>
(() => {
    const form = document.getElementById('loginForm');
    const email = document.getElementById('email');
    const password = document.getElementById('password');

    function setFieldState(input, message) {
        const errorNode = form.querySelector('[data-error-for="' + input.name + '"]');
        input.classList.remove('is-invalid', 'is-valid');
        if (message) {
            input.classList.add('is-invalid');
            if (errorNode) errorNode.textContent = message;
            return false;
        }
        if (input.value.trim() !== '') input.classList.add('is-valid');
        if (errorNode) errorNode.textContent = '';
        return true;
    }

    function validateEmail() {
        const value = email.value.trim();
        if (!value) return setFieldState(email, 'Email address is required.');
        return setFieldState(email, /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? '' : 'Enter a valid email address.');
    }

    function validatePassword() {
        const value = password.value;
        if (!value) return setFieldState(password, 'Password is required.');
        return setFieldState(password, '');
    }

    email.addEventListener('input', validateEmail);
    password.addEventListener('input', validatePassword);

    form.addEventListener('submit', (event) => {
        if (!validateEmail() || !validatePassword()) {
            event.preventDefault();
        }
    });

    document.querySelectorAll('[data-toggle-password]').forEach((button) => {
        button.addEventListener('click', () => {
            const target = document.getElementById(button.getAttribute('data-toggle-password'));
            const icon = button.querySelector('i');
            const showing = target.type === 'text';
            target.type = showing ? 'password' : 'text';
            icon.className = showing ? 'fas fa-eye' : 'fas fa-eye-slash';
        });
    });
})();
</script>
</body>
</html>
