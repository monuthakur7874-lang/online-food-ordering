<?php
/**
 * QuickBite - Payment History
 * File: user/payment-history.php
 */
require_once(__DIR__ . '/../config/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

$sql = "SELECT o.id, o.total_amount, o.order_date, o.order_status, o.payment_mode, o.payment_status,
               o.transaction_id, o.delivery_address, COUNT(oi.id) AS item_count
        FROM orders o
        LEFT JOIN order_items oi ON oi.order_id = o.id
        WHERE o.user_id = ?
          AND (
                o.payment_status = 'Paid'
                OR (o.payment_mode = 'COD' AND o.order_status = 'Delivered')
              )
        GROUP BY o.id
        ORDER BY o.id DESC";

$payments = [];
$stmt = mysqli_prepare($conn, $sql);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $payments[] = $row;
        }
    }
    mysqli_stmt_close($stmt);
}

$total_paid = 0.0;
$online_paid = 0;
$cod_paid = 0;
foreach ($payments as $payment) {
    $total_paid += (float)($payment['total_amount'] ?? 0);
    if (($payment['payment_mode'] ?? '') === 'Online') {
        $online_paid++;
    } else {
        $cod_paid++;
    }
}

include('includes/header.php');
?>

<div class="container py-4 py-lg-5">
    <div class="history-hero mb-4">
        <div>
            <span class="history-kicker"><i class="fas fa-file-invoice-dollar me-2"></i>Customer Payments</span>
            <h1 class="fw-bold mb-2">Payment History</h1>
            <p class="mb-0 text-muted">Jitne bhi paid orders hain, unka complete payment record aur invoice yahan milega.</p>
        </div>
        <a href="index.php#menu" class="btn btn-danger rounded-pill px-4 fw-bold shadow-sm">
            <i class="fas fa-plus me-2"></i>Order More
        </a>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="summary-card">
                <span>Total Paid</span>
                <strong><?php echo '&#8377;' . $h(number_format($total_paid, 2)); ?></strong>
                <small>All successful customer payments</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="summary-card">
                <span>Online Paid</span>
                <strong><?php echo (int)$online_paid; ?></strong>
                <small>UPI / wallet / card successful orders</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="summary-card">
                <span>Cash Collected</span>
                <strong><?php echo (int)$cod_paid; ?></strong>
                <small>Delivered COD orders marked as paid</small>
            </div>
        </div>
    </div>

    <?php if (!empty($payments)): ?>
        <div class="row g-4">
            <?php foreach ($payments as $payment):
                $order_id = (int)($payment['id'] ?? 0);
                $txn = trim((string)($payment['transaction_id'] ?? ''));
                $payment_mode = (string)($payment['payment_mode'] ?? 'COD');
                $status = (string)($payment['order_status'] ?? 'Pending');
                $payment_label = ($payment_mode === 'COD') ? 'Cash Paid' : 'Online Paid';
                $txn_label = $txn !== '' ? $txn : 'COD-COLLECTED-' . qb_order_display_id($order_id);
            ?>
            <div class="col-12">
                <div class="payment-card">
                    <div class="row g-4 align-items-center">
                        <div class="col-lg-8">
                            <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
                                <h5 class="fw-bold mb-0">Invoice for Order #<?php echo qb_order_display_id($order_id); ?></h5>
                                <span class="pay-pill pay-pill-success"><i class="fas fa-circle-check me-1"></i><?php echo $h($payment_label); ?></span>
                                <span class="pay-pill pay-pill-soft"><?php echo $h($payment_mode); ?></span>
                                <span class="pay-pill pay-pill-soft"><?php echo $h($status); ?></span>
                            </div>

                            <div class="row g-3 small">
                                <div class="col-md-4">
                                    <div class="meta-box">
                                        <span>Paid On</span>
                                        <strong><?php echo $h(date('d M Y, h:i A', strtotime((string)$payment['order_date']))); ?></strong>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="meta-box">
                                        <span>Items</span>
                                        <strong><?php echo (int)($payment['item_count'] ?? 0); ?> item(s)</strong>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="meta-box">
                                        <span>Transaction Ref</span>
                                        <strong><?php echo $h($txn_label); ?></strong>
                                    </div>
                                </div>
                            </div>

                            <div class="address-strip mt-3">
                                <i class="fas fa-location-dot text-danger me-2"></i>
                                <?php echo $h((string)($payment['delivery_address'] ?? 'Address not available')); ?>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="amount-box">
                                <span>Amount Paid</span>
                                <strong><?php echo '&#8377;' . $h(number_format((float)$payment['total_amount'], 2)); ?></strong>
                                <div class="d-grid gap-2 mt-3">
                                    <a href="invoice.php?order_id=<?php echo $order_id; ?>" class="btn btn-danger rounded-pill fw-bold">
                                        <i class="fas fa-file-lines me-2"></i>View Invoice
                                    </a>
                                    <a href="invoice.php?order_id=<?php echo $order_id; ?>&print=1" class="btn btn-outline-dark rounded-pill fw-bold">
                                        <i class="fas fa-print me-2"></i>Print Invoice
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="card border-0 shadow-sm rounded-5 p-5 text-center">
            <img src="https://cdn-icons-png.flaticon.com/512/4076/4076507.png" width="110" class="mx-auto mb-4 opacity-50" alt="No payments">
            <h4 class="fw-bold">Abhi koi paid order nahi mila</h4>
            <p class="text-muted mb-3">Jab customer payment complete karega, uski history aur invoice yahin show hogi.</p>
            <a href="index.php#menu" class="btn btn-danger rounded-pill px-4 fw-bold">Browse Menu</a>
        </div>
    <?php endif; ?>
</div>

<style>
    .history-hero {
        background: linear-gradient(135deg, rgba(255, 71, 87, 0.10), rgba(255,255,255,0.95));
        border: 1px solid rgba(255, 71, 87, 0.12);
        border-radius: 32px;
        padding: 28px 30px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 18px;
        box-shadow: 0 20px 40px rgba(47,53,66,0.07);
    }
    .history-kicker {
        display: inline-flex;
        align-items: center;
        font-size: 13px;
        font-weight: 700;
        color: #d63045;
        background: rgba(255,255,255,0.9);
        border-radius: 999px;
        padding: 8px 14px;
        margin-bottom: 14px;
    }
    .summary-card,
    .payment-card {
        background: rgba(255,255,255,0.94);
        border: 1px solid rgba(47,53,66,0.07);
        border-radius: 28px;
        padding: 24px;
        box-shadow: 0 18px 35px rgba(47,53,66,0.07);
    }
    .summary-card span,
    .meta-box span,
    .amount-box span {
        display: block;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #8a94a6;
        margin-bottom: 8px;
        font-weight: 700;
    }
    .summary-card strong,
    .amount-box strong {
        display: block;
        font-size: 28px;
        font-weight: 800;
        color: #1f2937;
    }
    .summary-card small {
        color: #7c8797;
    }
    .payment-card:hover {
        transform: translateY(-2px);
        transition: 0.2s ease;
    }
    .pay-pill {
        display: inline-flex;
        align-items: center;
        padding: 7px 12px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 700;
    }
    .pay-pill-success {
        background: #e8f7ef;
        color: #16824f;
    }
    .pay-pill-soft {
        background: #f3f4f6;
        color: #556070;
    }
    .meta-box {
        background: #fafbfc;
        border: 1px solid rgba(47,53,66,0.06);
        border-radius: 20px;
        padding: 16px;
        height: 100%;
    }
    .meta-box strong {
        display: block;
        color: #2f3542;
        word-break: break-word;
    }
    .address-strip {
        background: #fff5f5;
        border-radius: 18px;
        padding: 14px 16px;
        color: #596273;
    }
    .amount-box {
        background: linear-gradient(180deg, #fff7f6, #ffffff);
        border-radius: 24px;
        border: 1px solid rgba(255, 71, 87, 0.12);
        padding: 24px;
        text-align: center;
    }
    @media (max-width: 767.98px) {
        .history-hero {
            padding: 22px;
            border-radius: 24px;
            flex-direction: column;
            align-items: flex-start;
        }
    }
</style>

<?php include('includes/footer.php'); ?>
