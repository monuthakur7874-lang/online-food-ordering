<?php
/**
 * QuickBite - Cart Management System
 * File: user/cart.php
 */
require_once(__DIR__ . '/../config/db.php');
require_once(__DIR__ . '/includes/csrf.php');

// 1. Cart Logic: Add, Remove, and Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!qb_csrf_validate((string)($_POST['csrf_token'] ?? ''))) {
        http_response_code(400);
        exit('Invalid CSRF token');
    }

    $action = (string)($_POST['action'] ?? '');
    if (!in_array($action, ['add', 'remove', 'update'], true)) {
        http_response_code(400);
        exit('Invalid action');
    }

    $food_id = (int)($_POST['food_id'] ?? 0);
    if ($food_id <= 0) {
        http_response_code(400);
        exit('Invalid food id');
    }

    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if ($action === 'add') {
        if (isset($_SESSION['cart'][(string)$food_id])) {
            $_SESSION['cart'][(string)$food_id]['qty'] = (int)$_SESSION['cart'][(string)$food_id]['qty'] + 1;
        } else {
            $stmt = mysqli_prepare($conn, "SELECT title, price, image FROM foods WHERE id = ? AND is_available='Yes' LIMIT 1");
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "i", $food_id);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_bind_result($stmt, $ftitle, $fprice, $fimage);
                if (mysqli_stmt_fetch($stmt)) {
                    $_SESSION['cart'][(string)$food_id] = [
                        'title' => (string)$ftitle,
                        'price' => (float)$fprice,
                        'image' => (string)$fimage,
                        'qty' => 1
                    ];
                }
                mysqli_stmt_close($stmt);
            }
        }
    } elseif ($action === 'remove') {
        unset($_SESSION['cart'][(string)$food_id]);
    } elseif ($action === 'update') {
        $new_qty = (int)($_POST['qty'] ?? 0);
        if ($new_qty > 0) {
            if (isset($_SESSION['cart'][(string)$food_id])) {
                $_SESSION['cart'][(string)$food_id]['qty'] = $new_qty;
            }
        } else {
            unset($_SESSION['cart'][(string)$food_id]);
        }
    }

    header("Location: cart.php");
    exit();
}

$subtotal = 0;
$delivery_fee = 40;

include('includes/header.php');
$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
?>

<div class="container mt-5 mb-5">
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 p-4">
                <h4 class="fw-bold mb-4">Shopping Cart (<?php echo count($_SESSION['cart'] ?? []); ?> Items)</h4>
                
                <?php if (!empty($_SESSION['cart'])): ?>
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr class="text-muted small">
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($_SESSION['cart'] as $id => $item): 
                                    $item_qty = (int)($item['qty'] ?? 0);
                                    $item_price = (float)($item['price'] ?? 0);
                                    $item_total = $item_price * $item_qty;
                                    $subtotal += $item_total;

                                    $img_file = basename((string)($item['image'] ?? ''));
                                    $img_path = "../assets/img/food/" . $img_file;
                                ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo $img_path; ?>" 
                                                 class="rounded-3 me-3" 
                                                 style="width: 60px; height: 60px; object-fit: cover;"
                                                 onerror="this.src='https://placehold.co/100x100?text=Food'">
                                            <h6 class="fw-bold mb-0"><?php echo $h($item['title'] ?? ''); ?></h6>
                                        </div>
                                    </td>
                                    <td class="fw-bold">₹<?php echo $h($item_price); ?></td>
                                    <td>
                                        <form action="" method="POST" class="d-flex align-items-center">
                                            <input type="hidden" name="csrf_token" value="<?php echo $h($qb_csrf_token); ?>">
                                            <input type="hidden" name="food_id" value="<?php echo (int)$id; ?>">
                                            <input type="hidden" name="action" value="update">
                                            <input type="number" name="qty" value="<?php echo (int)$item_qty; ?>" class="form-control form-control-sm text-center fw-bold rounded-pill" style="width: 60px;" onchange="this.form.submit()">
                                        </form>
                                    </td>
                                    <td class="fw-bold text-danger">₹<?php echo $h($item_total); ?></td>
                                    <td>
                                        <form action="" method="POST">
                                            <input type="hidden" name="csrf_token" value="<?php echo $h($qb_csrf_token); ?>">
                                            <input type="hidden" name="food_id" value="<?php echo (int)$id; ?>">
                                            <input type="hidden" name="action" value="remove">
                                            <button type="submit" class="btn btn-sm btn-light rounded-circle text-muted"><i class="fas fa-times"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <img src="https://cdn-icons-png.flaticon.com/512/11329/11329060.png" width="120" class="mb-3 opacity-50">
                        <h5 class="text-muted">Your cart is empty!</h5>
                        <a href="index.php" class="btn btn-danger rounded-pill px-4 mt-2">Order Something Delicious</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!empty($_SESSION['cart'])): ?>
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm rounded-4 p-4 sticky-top" style="top: 100px;">
                <h5 class="fw-bold mb-4">Order Summary</h5>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Subtotal</span>
                    <span class="fw-bold">₹<?php echo $h($subtotal); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-4">
                    <span class="text-muted">Delivery Fee</span>
                    <span class="fw-bold text-success">₹<?php echo $h($delivery_fee); ?></span>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-4">
                    <h5 class="fw-bold">Total</h5>
                    <h4 class="fw-bold text-danger">₹<?php echo $h($subtotal + $delivery_fee); ?></h4>
                </div>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="checkout.php" class="btn btn-danger w-100 py-3 rounded-pill fw-bold shadow">PROCEED TO CHECKOUT</a>
                <?php else: ?>
                    <a href="auth/login.php" class="btn btn-dark w-100 py-3 rounded-pill fw-bold shadow">LOGIN TO ORDER</a>
                <?php endif; ?>
                
                <p class="text-center small text-muted mt-3 mb-0"><i class="fas fa-shield-alt me-1"></i> Secure checkout for Food Monu</p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php include('includes/footer.php'); ?>
