<?php
/**
 * QuickBite - Main Food Menu (Home)
 * File: user/index.php
 */
include('includes/header.php'); 
$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
?>

<style>
    /* Hero Section */
    .hero-banner {
        background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1000&q=80');
        background-size: cover;
        background-position: center;
        border-radius: 30px;
        padding: 60px 20px;
        color: white;
        text-align: center;
        margin-bottom: 40px;
    }

    /* Category Scroll */
    .cat-item {
        transition: 0.3s;
        cursor: pointer;
        min-width: 100px;
    }
    .cat-item:hover { transform: translateY(-5px); }
    .cat-img {
        width: 70px; height: 70px;
        object-fit: cover;
        border-radius: 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    }

    /* Food Cards */
    .food-card {
        border: none;
        border-radius: 25px;
        overflow: hidden;
        transition: 0.3s;
        background: #fff;
    }
    .food-card:hover { 
        transform: translateY(-10px); 
        box-shadow: 0 15px 30px rgba(0,0,0,0.1) !important; 
    }
    .food-badge {
        position: absolute;
        top: 15px; left: 15px;
        background: rgba(255,255,255,0.9);
        padding: 5px 12px;
        border-radius: 15px;
        font-weight: 700;
        font-size: 12px;
        color: #ff4757;
    }
</style>

<div class="container mt-4">
    <div class="hero-banner shadow-sm">
        <h1 class="fw-bold display-5">QuickBite Food Delivery</h1>
        <p class="lead opacity-75 mb-0">Fresh meals, easy ordering, and smooth delivery tracking in one place.</p>
        <div class="mt-4">
            <a href="#menu" class="btn btn-danger btn-lg rounded-pill px-5 fw-bold shadow">Explore Menu</a>
        </div>
    </div>

    <div class="mb-5">
        <h5 class="fw-bold mb-4">What's on your mind?</h5>
        <div class="d-flex overflow-auto pb-3 no-scrollbar gap-4">
            <?php
            $cat_res = mysqli_query($conn, "SELECT * FROM categories WHERE is_active='Yes'");
            while($cat = mysqli_fetch_assoc($cat_res)) {
                $cat_img = "../assets/img/category/" . $cat['image'];
            ?>
                <a href="?cat=<?php echo (int)$cat['id']; ?>#menu" class="text-decoration-none text-center cat-item">
                    <img src="<?php echo $cat_img; ?>" class="cat-img mb-2" onerror="this.src='https://placehold.co/100x100?text=Food'">
                    <p class="small fw-bold text-dark mb-0"><?php echo $h($cat['name']); ?></p>
                </a>
            <?php } ?>
        </div>
    </div>

    <div id="menu" class="row align-items-center mb-4">
        <div class="col-8">
            <h4 class="fw-bold mb-0">Popular Dishes</h4>
        </div>
        <div class="col-4 text-end">
            <a href="index.php" class="btn btn-sm btn-outline-secondary rounded-pill">View All</a>
        </div>
    </div>

    <div class="row g-4 mb-5">
        <?php
        $where = "";
        if(isset($_GET['cat'])) {
            $cat_id = (int)$_GET['cat'];
            if ($cat_id > 0) {
                $where = " AND cat_id = $cat_id";
            }
        }
        
        $food_res = mysqli_query($conn, "SELECT * FROM foods WHERE is_available='Yes' $where ORDER BY id DESC");
        
        if(mysqli_num_rows($food_res) > 0) {
            while($food = mysqli_fetch_assoc($food_res)) {
                // FIXED: Food Image Path (Matching Admin Logic)
                $food_img = "../assets/img/food/".$food['image'];
            ?>
            <div class="col-6 col-md-4 col-lg-3">
                <div class="card food-card shadow-sm h-100 position-relative">
                    <span class="food-badge shadow-sm"><i class="fas fa-star me-1"></i> 4.5</span>
                    
                    <img src="<?php echo $food_img; ?>" class="card-img-top" style="height: 180px; object-fit: cover;" onerror="this.src='https://placehold.co/300x200?text=<?php echo urlencode($food['title']); ?>'">
                    
                    <div class="card-body p-3">
                        <h6 class="fw-bold text-dark mb-1 text-truncate"><?php echo $h($food['title']); ?></h6>
                        <p class="text-muted small mb-3 text-truncate"><?php echo $h($food['description']); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold text-danger mb-0">Rs. <?php echo number_format((float)$food['price'], 2); ?></h5>
                            <form action="cart.php" method="POST">
                                <input type="hidden" name="csrf_token" value="<?php echo $h($qb_csrf_token); ?>">
                                <input type="hidden" name="food_id" value="<?php echo (int)$food['id']; ?>">
                                <input type="hidden" name="action" value="add">
                                <button type="submit" class="btn btn-danger btn-sm rounded-pill px-3 fw-bold">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
            }
        } else {
            echo "<div class='text-center py-5'><img src='https://cdn-icons-png.flaticon.com/512/2748/2748614.png' width='100'><p class='mt-3 text-muted'>No food items found in this category.</p></div>";
        }
        ?>
    </div>
</div>

<?php include('includes/footer.php'); ?>
