<?php
/**
 * QuickBite - Order Confirmation Screen
 * File: user/order-success.php
 */
require_once(__DIR__ . '/../config/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// 1. Security Check: Order ID hona zaroori hai
if (!isset($_GET['order_id'])) {
    header("Location: index.php");
    exit();
}

$order_id = (int)($_GET['order_id'] ?? 0);
$user_id = (int)$_SESSION['user_id'];
$payment_mode = null;
$order_user_id = null;

if ($order_id <= 0) {
    header("Location: index.php");
    exit();
}

$stmt = mysqli_prepare($conn, "SELECT user_id, payment_mode FROM orders WHERE id = ? LIMIT 1");
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $order_user_id, $payment_mode);
    $found = mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    if (!$found || (int)$order_user_id !== $user_id) {
        header("Location: index.php");
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}

$status = strtolower($_GET['status'] ?? 'cod');
$is_paid = ($payment_mode === 'Online') && in_array($status, ['paid', 'success'], true);
$is_failed = ($payment_mode === 'Online') && ($status === 'failed');

// 2. Database Update Logic (Online success only)
if ($is_paid && $payment_mode === 'Online') {
    $stmt = mysqli_prepare($conn, "UPDATE orders SET payment_status='Paid', order_status='Confirmed' WHERE id=? AND user_id=? AND payment_mode='Online'");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
}

// 3. Cart ko empty karein
if(isset($_SESSION['cart'])) {
    unset($_SESSION['cart']);
}

include('includes/header.php');
$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
?>

<div class="container mt-5 mb-5 text-center">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card border-0 shadow-lg rounded-5 p-5 bg-white">
                <div class="mb-4">
                    <div class="success-checkmark">
                        <i class="fas fa-check-circle text-success" style="font-size: 80px;"></i>
                    </div>
                </div>

                <h2 class="fw-bold mb-2"><?php echo $payment_mode === 'Online' ? 'Order Confirmed!' : 'Order Placed!'; ?></h2>
                <p class="text-muted mb-4">
                    <?php echo $payment_mode === 'Online'
                        ? 'Your payment is complete and the order has been confirmed successfully.'
                        : 'Hooray! Your delicious meal is being prepared. We have received your order and notified the restaurant.'; ?>
                </p>

                <?php if ($is_failed): ?>
                    <div class="alert alert-danger border-0 rounded-4 small">
                        Payment failed. Please try again from the payment page.
                    </div>
                <?php endif; ?>

                <div class="bg-light rounded-4 p-4 mb-4 text-start">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Order ID:</span>
                        <span class="fw-bold text-dark">#<?php echo qb_order_display_id((int)$order_id); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted small">Payment Method:</span>
                        <?php
                            $badge = 'bg-warning text-dark';
                            $label = 'Cash on Delivery';
                            if ($payment_mode === 'Online') {
                                if ($is_paid) { $badge = 'bg-success'; $label = 'Online Paid'; }
                                elseif ($is_failed) { $badge = 'bg-danger'; $label = 'Payment Failed'; }
                                else { $badge = 'bg-info text-dark'; $label = 'Online (Pending)'; }
                            }
                        ?>
                        <span class="badge <?php echo $badge; ?> rounded-pill"><?php echo htmlspecialchars($label); ?></span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="text-muted small">Estimated Delivery:</span>
                        <span class="fw-bold">35-45 Mins</span>
                    </div>
                </div>

                <div class="d-grid gap-3">
                    <a href="track-order.php?order_id=<?php echo $order_id; ?>" class="btn btn-danger py-3 rounded-pill fw-bold shadow">
                        <i class="fas fa-map-marker-alt me-2"></i> TRACK MY ORDER
                    </a>
                    <?php if ($is_paid || $payment_mode === 'COD'): ?>
                        <a href="invoice.php?order_id=<?php echo $order_id; ?>" class="btn btn-outline-dark py-3 rounded-pill fw-bold">
                            <i class="fas fa-file-invoice me-2"></i> VIEW INVOICE
                        </a>
                    <?php endif; ?>
                    <?php if ($is_failed): ?>
                        <a href="payment-gateway.php?order_id=<?php echo $order_id; ?>" class="btn btn-dark py-3 rounded-pill fw-bold">
                            <i class="fas fa-redo me-2"></i> RETRY PAYMENT
                        </a>
                    <?php endif; ?>
                    <a href="index.php" class="btn btn-outline-secondary py-3 rounded-pill fw-bold">
                        ORDER MORE FOOD
                    </a>
                </div>

                <p class="mt-4 small text-muted">Need help? <a href="profile.php" class="text-danger fw-bold text-decoration-none">Contact Support</a></p>
            </div>
        </div>
    </div>
</div>

<style>
    body { background-color: #f8f9fa; }
    .success-checkmark {
        animation: scaleIn 0.6s cubic-bezier(0.165, 0.84, 0.44, 1) forwards;
    }
    @keyframes scaleIn {
        0% { transform: scale(0); opacity: 0; }
        80% { transform: scale(1.1); }
        100% { transform: scale(1); opacity: 1; }
    }
</style>

<?php include('includes/footer.php'); ?>
