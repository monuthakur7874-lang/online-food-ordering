<?php
/**
 * QuickBite - Global Header & Navbar
 * File: user/includes/header.php
 */
require_once(__DIR__ . '/../../config/db.php');
require_once(__DIR__ . '/csrf.php');

if (isset($_SESSION['user_id']) && function_exists('qb_backfill_delivered_cod_payments')) {
    qb_backfill_delivered_cod_payments($conn, ['user_id' => (int)$_SESSION['user_id']]);
}

$session_user_name = $_SESSION['user_name'] ?? '';
$avatar_name = urlencode($session_user_name);
$avatar_label = trim((string)$session_user_name);
$avatar_initials = 'C';
if ($avatar_label !== '') {
    $avatar_words = preg_split('/\s+/', $avatar_label) ?: [];
    $avatar_letters = '';
    foreach (array_slice($avatar_words, 0, 2) as $word) {
        $first_char = function_exists('mb_substr') ? mb_substr($word, 0, 1) : substr($word, 0, 1);
        if ($first_char !== false && $first_char !== '') {
            $avatar_letters .= $first_char;
        }
    }
    if ($avatar_letters !== '') {
        $avatar_initials = strtoupper($avatar_letters);
    }
}

// Cart Count Logic (Agar session mein cart hai toh items count karein)
$cart_count = 0;
if(isset($_SESSION['cart'])) {
    $cart_count = count($_SESSION['cart']);
}

$qb_csrf_token = qb_csrf_token();
$current_user_page = basename($_SERVER['PHP_SELF'] ?? '');
$is_user_home_page = ($current_user_page === 'index.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickBite | Delicious Food Delivered</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --qb-red: #ff4757;
            --qb-red-dark: #e03143;
            --qb-dark: #2f3542;
            --qb-soft: #fff1f2;
            --qb-border: rgba(47, 53, 66, 0.08);
        }
        body {
            font-family: 'Poppins', sans-serif;
            background:
                radial-gradient(circle at top left, rgba(255, 71, 87, 0.08), transparent 28%),
                linear-gradient(180deg, #fff6f4 0%, #f8f9fa 26%, #f8f9fa 100%);
            color: var(--qb-dark);
        }

        .navbar {
            background: rgba(255,255,255,0.92);
            backdrop-filter: blur(14px);
            box-shadow: 0 12px 35px rgba(47,53,66,0.08);
            padding: 18px 0;
            border-bottom: 1px solid rgba(255,255,255,0.5);
        }
        .navbar-shell {
            background: rgba(255,255,255,0.96);
            border: 1px solid rgba(255, 71, 87, 0.14);
            border-radius: 28px;
            padding: 12px 16px;
            box-shadow: 0 18px 36px rgba(255, 71, 87, 0.08);
        }
        .navbar-brand {
            font-weight: 800;
            color: var(--qb-dark) !important;
            font-size: 22px;
            display: flex;
            align-items: center;
            gap: 14px;
            margin-right: 8px;
            flex: 0 0 auto;
        }
        .brand-mark {
            width: 54px;
            height: 54px;
            border-radius: 18px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--qb-red), var(--qb-red-dark));
            color: #fff;
            box-shadow: 0 12px 28px rgba(255, 71, 87, 0.28);
            font-size: 22px;
        }
        .brand-copy { line-height: 1.05; }
        .brand-copy strong {
            display: block;
            font-size: 15px;
            font-weight: 800;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            color: #9b5d5d;
        }
        .brand-copy span {
            display: block;
            font-size: 30px;
            font-weight: 800;
            color: var(--qb-dark);
        }
        .guest-shell {
            padding: 10px 18px;
        }
        .guest-shell .navbar-brand {
            margin-right: 18px;
        }
        .guest-shell .nav-center {
            margin-inline: auto;
        }
        .guest-shell .nav-link {
            padding: 12px 26px !important;
        }
        .auth-shell .navbar-collapse {
            display: flex;
            align-items: center;
            gap: 20px;
            flex: 1 1 auto;
            margin-left: 26px;
        }
        .auth-shell .nav-center {
            min-width: 640px;
            margin-left: 0 !important;
            margin-right: auto !important;
            justify-content: center;
        }
        .auth-shell .nav-item {
            flex: 0 0 auto;
        }
        .guest-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 20px;
        }
        .guest-actions .btn {
            min-width: 112px;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        .nav-link {
            font-weight: 700;
            color: #556070;
            margin: 0 4px;
            padding: 12px 20px !important;
            border-radius: 999px;
            transition: 0.25s ease;
        }
        .nav-link:hover,
        .nav-link.active {
            color: var(--qb-red);
            background: var(--qb-soft);
        }
        .nav-center {
            background: rgba(248, 249, 250, 0.9);
            border: 1px solid var(--qb-border);
            border-radius: 999px;
            padding: 6px;
            flex-wrap: nowrap;
        }

        .quick-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: auto;
            flex: 0 0 auto;
        }
        .cart-chip,
        .profile-trigger {
            border: 1px solid rgba(255, 71, 87, 0.18);
            background: rgba(255,255,255,0.95);
            border-radius: 999px;
            padding: 10px 14px;
            font-weight: 700;
            color: var(--qb-dark);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 9px;
            box-shadow: 0 8px 22px rgba(47,53,66,0.06);
            transition: 0.2s ease;
            min-height: 56px;
        }
        .cart-chip:hover,
        .profile-trigger:hover {
            color: var(--qb-red);
            border-color: rgba(255, 71, 87, 0.35);
            transform: translateY(-1px);
        }
        .cart-icon { position: relative; color: inherit; }
        .cart-badge { 
            position: static;
            background: var(--qb-red); color: white; 
            font-size: 11px; min-width: 28px; height: 28px;
            display: inline-flex; align-items: center; justify-content: center;
            padding: 0 8px; border-radius: 999px;
        }
        .user-profile-img {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            border: 2px solid rgba(255, 71, 87, 0.22);
            background: linear-gradient(135deg, var(--qb-red), var(--qb-red-dark));
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: 800;
            letter-spacing: 0.04em;
            flex: 0 0 auto;
        }
        .profile-trigger {
            padding-right: 16px;
            min-width: 112px;
            justify-content: center;
        }
        .profile-caret {
            font-size: 13px;
            color: var(--qb-red);
        }
        .profile-trigger.dropdown-toggle::after { display: none; }
        .dropdown-menu.qb-user-menu {
            width: 320px;
            min-width: 320px;
            padding: 16px 18px;
            border: 1px solid rgba(255, 71, 87, 0.14);
            border-radius: 28px;
            box-shadow: 0 24px 42px rgba(47,53,66,0.14);
            margin-top: 18px !important;
        }
        .menu-user-meta {
            padding: 8px 10px 16px;
            margin-bottom: 10px;
            border-bottom: 1px solid rgba(47,53,66,0.08);
        }
        .menu-user-meta strong { display: block; font-size: 16px; }
        .dropdown-item.qb-user-link {
            border-radius: 18px;
            font-weight: 600;
            padding: 14px 16px;
            margin-bottom: 6px;
            font-size: 15px;
        }
        .dropdown-item.qb-user-link i { width: 22px; }
        .dropdown-item.qb-user-link:hover { background: var(--qb-soft); color: var(--qb-red); }
        .dropdown-item.qb-user-link.text-danger:hover { background: #fff5f5; }

        @media (max-width: 991.98px) {
            .navbar-shell { border-radius: 24px; }
            .nav-center {
                background: transparent;
                border: 0;
                padding: 10px 0 0;
                flex-wrap: wrap;
            }
            .nav-link { margin: 3px 0; }
            .quick-actions {
                padding-top: 12px;
                justify-content: flex-start;
                flex-wrap: wrap;
            }
            .guest-actions {
                margin-left: 0;
                padding-top: 12px;
            }
            .guest-actions .btn {
                min-width: 0;
            }
            .guest-shell {
                padding: 12px 16px;
            }
            .auth-shell .navbar-collapse {
                margin-left: 0;
                gap: 10px;
            }
            .auth-shell .nav-center {
                min-width: 0;
                margin-right: 0 !important;
            }
            .dropdown-menu.qb-user-menu {
                width: min(320px, calc(100vw - 34px));
                min-width: 0;
            }
            .brand-copy span { font-size: 24px; }
            .brand-copy strong { font-size: 12px; }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <div class="navbar-shell w-100 <?php echo isset($_SESSION['user_id']) ? 'auth-shell' : 'guest-shell'; ?>">
            <a class="navbar-brand" href="index.php">
                <span class="brand-mark"><i class="fas fa-basket-shopping"></i></span>
                <span class="brand-copy">
                    <span>QuickBite</span>
                    <strong>Premium Food Delivery</strong>
                </span>
            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto nav-center">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="nav-link <?php echo $is_user_home_page ? 'active' : ''; ?>" href="index.php" data-user-nav="home">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="index.php#menu" data-user-nav="menu">Menu</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $current_user_page === 'my-orders.php' ? 'active' : ''; ?>" href="my-orders.php" data-user-nav="orders">My Orders</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $current_user_page === 'payment-history.php' || $current_user_page === 'invoice.php' ? 'active' : ''; ?>" href="payment-history.php" data-user-nav="payments">Payment History</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link <?php echo $current_user_page === 'index.php' ? 'active' : ''; ?>" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $current_user_page === 'about.php' ? 'active' : ''; ?>" href="../about.php">About</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo $current_user_page === 'help.php' ? 'active' : ''; ?>" href="../help.php">Help</a></li>
                    <?php endif; ?>
                </ul>

                <?php if(isset($_SESSION['user_id'])): ?>
                    <div class="quick-actions">
                        <a href="cart.php" class="cart-chip" title="Cart">
                            <span class="cart-icon"><i class="fas fa-bag-shopping"></i></span>
                            <span>Cart</span>
                            <span class="cart-badge"><?php echo (int)$cart_count; ?></span>
                        </a>

                        <div class="dropdown">
                            <a href="#" class="profile-trigger dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="user-profile-img" aria-label="<?php echo htmlspecialchars($avatar_label ?: 'Customer', ENT_QUOTES, 'UTF-8'); ?>">
                                    <?php echo htmlspecialchars($avatar_initials, ENT_QUOTES, 'UTF-8'); ?>
                                </span>
                                <i class="fas fa-angle-up profile-caret"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end qb-user-menu mt-3">
                                <li class="menu-user-meta">
                                    <strong><?php echo htmlspecialchars($session_user_name ?: 'Customer', ENT_QUOTES, 'UTF-8'); ?></strong>
                                </li>
                                <li><a class="dropdown-item qb-user-link" href="profile.php"><i class="fas fa-user me-2"></i> Profile</a></li>
                                <li><a class="dropdown-item qb-user-link" href="profile.php#change-password"><i class="fas fa-key me-2"></i> Change Password</a></li>
                                <li><hr class="dropdown-divider my-2"></li>
                                <li><a class="dropdown-item qb-user-link text-danger fw-bold" href="auth/logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                            </ul>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="guest-actions">
                        <a href="auth/login.php" class="btn btn-outline-danger btn-sm px-4 rounded-pill fw-bold">Login</a>
                        <a href="auth/register.php" class="btn btn-danger btn-sm px-4 rounded-pill fw-bold">Register</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<div class="main-wrapper">

<script>
(() => {
    const navLinks = Array.from(document.querySelectorAll('[data-user-nav]'));
    if (!navLinks.length) return;

    const currentPage = (window.location.pathname.split('/').pop() || 'index.php').toLowerCase();
    const menuSection = document.getElementById('menu');

    function setActive(target) {
        navLinks.forEach((link) => {
            link.classList.toggle('active', link.getAttribute('data-user-nav') === target);
        });
    }

    function updateActiveNav() {
        if (currentPage === 'my-orders.php') {
            setActive('orders');
            return;
        }

        if (currentPage === 'payment-history.php' || currentPage === 'invoice.php') {
            setActive('payments');
            return;
        }

        if (currentPage !== 'index.php') {
            return;
        }

        const hash = (window.location.hash || '').toLowerCase();
        if (hash === '#menu') {
            setActive('menu');
            return;
        }

        if (menuSection) {
            const rect = menuSection.getBoundingClientRect();
            const inMenuView = rect.top <= 180 && rect.bottom > 180;
            setActive(inMenuView ? 'menu' : 'home');
            return;
        }

        setActive('home');
    }

    window.addEventListener('hashchange', updateActiveNav);
    window.addEventListener('scroll', updateActiveNav, { passive: true });
    window.addEventListener('load', updateActiveNav);
    updateActiveNav();
})();
</script>
