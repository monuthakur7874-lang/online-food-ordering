<?php
/**
 * QuickBite - CSRF helpers (User panel)
 * File: user/includes/csrf.php
 */

if (session_status() === PHP_SESSION_NONE) {
    // Ensure session is started with project settings (cookie path/name/etc.)
    require_once(__DIR__ . '/../../config/db.php');
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function qb_csrf_token(): string
{
    if (empty($_SESSION['qb_csrf_token']) || !is_string($_SESSION['qb_csrf_token'])) {
        $_SESSION['qb_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['qb_csrf_token'];
}

function qb_csrf_validate(string $token): bool
{
    $session_token = $_SESSION['qb_csrf_token'] ?? '';
    if (!is_string($session_token) || $session_token === '') {
        return false;
    }
    return hash_equals($session_token, $token);
}
