<?php
/**
 * QuickBite - Global Footer & Scripts
 * File: user/includes/footer.php
 */
?>
</div> <footer class="bg-white pt-5 pb-4 mt-5 border-top">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4">
                <h5 class="fw-bold text-danger mb-3"><i class="fas fa-utensils me-2"></i>FOOD MONU</h5>
                <p class="text-muted small">
                    Test me best Monu is best of Food Order<br>
                    "Online Food Order Kiya Kya!"
                </p>
                <div class="social-links mt-3">
                    <a href="#" class="text-dark me-3"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-dark me-3"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-dark me-3"><i class="fab fa-twitter"></i></a>
                </div>
            </div>

            <div class="col-lg-2 col-md-6 mb-4">
                <h6 class="fw-bold mb-3">Quick Links</h6>
                <ul class="list-unstyled small">
                    <li class="mb-2"><a href="index.php" class="text-muted text-decoration-none">Home</a></li>
                    <li class="mb-2"><a href="my-orders.php" class="text-muted text-decoration-none">My Orders</a></li>
                    <li class="mb-2"><a href="payment-history.php" class="text-muted text-decoration-none">Payment History</a></li>
                    <li class="mb-2"><a href="cart.php" class="text-muted text-decoration-none">View Cart</a></li>
                    <li class="mb-2"><a href="profile.php" class="text-muted text-decoration-none">Profile</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-md-6 mb-4">
                <h6 class="fw-bold mb-3">Support</h6>
                <ul class="list-unstyled small">
                    <li class="mb-2"><a href="../help.php" class="text-muted text-decoration-none">Help Center</a></li>
                    <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Terms of Use</a></li>
                    <li class="mb-2"><a href="#" class="text-muted text-decoration-none">Privacy Policy</a></li>
                </ul>
            </div>

        </div>

        <hr class="my-4 text-muted">

        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0 small text-muted">&copy; <?php echo date('Y'); ?> Food Monu Food Service. All Rights Reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end mt-2 mt-md-0">
                <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" height="20" class="me-3 opacity-50">
                <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo-vector.svg" height="15" class="opacity-50">
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    // Example: Order Success Toast Notification
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('msg')) {
        alert(urlParams.get('msg')); // Replace with a pretty Toast later
    }

    // Scroll-to-top feature or Navbar shadow on scroll
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('.navbar').addClass('shadow-sm border-bottom');
        } else {
            $('.navbar').removeClass('shadow-sm border-bottom');
        }
    });
</script>

</body>
</html>
