<?php
/**
 * QuickBite - Checkout & Payment Selection
 * File: user/checkout.php
 */
require_once(__DIR__ . '/../config/db.php');
require_once(__DIR__ . '/includes/csrf.php');

// Agar cart khali hai toh wapas bhej dein
if (empty($_SESSION['cart'])) {
    header("Location: index.php");
    exit();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

// User ka current address fetch karein database se
$user_id = (int)$_SESSION['user_id'];
$user_data = ['address' => '', 'phone' => ''];
$stmt = mysqli_prepare($conn, "SELECT address, phone FROM users WHERE id = ? LIMIT 1");
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $address_db, $phone_db);
    if (mysqli_stmt_fetch($stmt)) {
        $user_data['address'] = (string)$address_db;
        $user_data['phone'] = (string)$phone_db;
    }
    mysqli_stmt_close($stmt);
}

$subtotal = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += ($item['price'] * $item['qty']);
}
$delivery_fee = 40;
$grand_total = $subtotal + $delivery_fee;

include('includes/header.php');
$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };
?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <h4 class="fw-bold mb-4"><i class="fas fa-shopping-bag me-2 text-danger"></i>Finalize Your Order</h4>
            
            <form action="process-order.php" method="POST" id="checkoutForm">
                <input type="hidden" name="csrf_token" value="<?php echo $h($qb_csrf_token); ?>">
                <div class="row g-4">
                    <div class="col-md-7">
                        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                            <h6 class="fw-bold mb-3">Delivery Address</h6>
                            <div class="mb-3">
                                <textarea name="delivery_address" class="form-control rounded-3" rows="3" required><?php echo $h($user_data['address']); ?></textarea>
                                <small class="text-muted">You can update the address for this specific delivery.</small>
                            </div>
                            <div class="mb-0">
                                <label class="small fw-bold text-muted">Contact Number</label>
                                <input type="text" name="phone" class="form-control rounded-3" value="<?php echo $h($user_data['phone']); ?>" required>
                            </div>
                        </div>

                        <div class="card border-0 shadow-sm rounded-4 p-4">
                            <h6 class="fw-bold mb-3">Order Items</h6>
                            <?php foreach ($_SESSION['cart'] as $item): ?>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="small"><?php echo (int)$item['qty']; ?>x <?php echo $h($item['title']); ?></span>
                                <span class="fw-bold small">₹<?php echo $h($item['price'] * $item['qty']); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="card border-0 shadow-sm rounded-4 p-4 sticky-top" style="top: 100px;">
                            <h6 class="fw-bold mb-4">Payment Method</h6>
                            
                            <div class="payment-options mb-4">
                                <label class="w-100 mb-3 border p-3 rounded-4 d-flex align-items-center cursor-pointer">
                                    <input type="radio" name="payment_mode" value="COD" checked class="form-check-input me-3">
                                    <div>
                                        <span class="fw-bold d-block">Cash on Delivery</span>
                                        <small class="text-muted">Pay when you receive food</small>
                                    </div>
                                </label>

                                <label class="w-100 mb-3 border p-3 rounded-4 d-flex align-items-center cursor-pointer">
                                    <input type="radio" name="payment_mode" value="Online" class="form-check-input me-3">
                                    <div>
                                        <span class="fw-bold d-block">Online Payment</span>
                                        <small class="text-muted">Pay via UPI, Cards or Wallet</small>
                                    </div>
                                </label>
                            </div>

                            <div id="onlineFeatures" class="border rounded-4 p-3 mb-4" style="display:none;">
                                <div class="d-flex align-items-center justify-content-between mb-2">
                                    <span class="fw-bold small text-uppercase text-muted">Online Options</span>
                                    <span class="badge bg-light text-dark border">Dummy Payment</span>
                                </div>
                                <div class="d-flex flex-wrap gap-2">
                                    <span class="badge bg-dark"><i class="fas fa-bolt me-1"></i>UPI</span>
                                    <span class="badge bg-primary"><i class="fas fa-wallet me-1"></i>Paytm</span>
                                    <span class="badge bg-success"><i class="fab fa-android me-1"></i>PhonePe</span>
                                    <span class="badge bg-info text-dark"><i class="fas fa-credit-card me-1"></i>Debit Card</span>
                                </div>
                                <small class="text-muted d-block mt-2">Next page par aap dummy UPI / wallet / card details choose kar sakte ho.</small>
                            </div>

                            <div class="price-breakdown mb-4">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">Subtotal</span>
                                    <span>₹<?php echo $subtotal; ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="text-muted">Delivery Fee</span>
                                    <span class="text-success">₹<?php echo $delivery_fee; ?></span>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between">
                                    <h5 class="fw-bold">Grand Total</h5>
                                    <h5 class="fw-bold text-danger">₹<?php echo $grand_total; ?></h5>
                                </div>
                            </div>

                            <input type="hidden" name="total_amount" value="<?php echo $grand_total; ?>">
                            <button type="submit" id="checkoutSubmitBtn" class="btn btn-danger w-100 py-3 rounded-pill fw-bold shadow">PLACE ORDER</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .cursor-pointer { cursor: pointer; transition: 0.2s; }
    .cursor-pointer:hover { background-color: #fdf2f2; border-color: #ff4757 !important; }
    input[type="radio"]:checked + div { color: #ff4757; }
</style>

<?php include('includes/footer.php'); ?>

<script>
    (function () {
        const features = document.getElementById('onlineFeatures');
        const radios = document.querySelectorAll('input[name="payment_mode"]');
        const submitBtn = document.getElementById('checkoutSubmitBtn');
        function refresh() {
            const selected = document.querySelector('input[name="payment_mode"]:checked')?.value || 'COD';
            features.style.display = (selected === 'Online') ? 'block' : 'none';
            if (submitBtn) {
                submitBtn.textContent = (selected === 'Online') ? 'CONFIRM ONLINE' : 'PLACE ORDER';
            }
        }
        radios.forEach(r => r.addEventListener('change', refresh));
        refresh();
    })();
</script>
