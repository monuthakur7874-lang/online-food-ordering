<?php
/**
 * QuickBite - Live Order Tracking (Final Updated Version)
 */
require_once(__DIR__ . '/../config/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: auth/login.php");
    exit();
}

$order_id = (int)($_GET['order_id'] ?? 0);
if ($order_id <= 0) {
    header("Location: my-orders.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];

// Order + rider details (must belong to this user)
$order = null;
$order_id_sql = (int)$order_id;
$user_id_sql = (int)$user_id;
$sql = "SELECT o.*, r.name AS rider_name, r.phone AS rider_phone
        FROM orders o
        LEFT JOIN users r ON o.rider_id = r.id
        WHERE o.id = $order_id_sql AND o.user_id = $user_id_sql
        LIMIT 1";
$res = mysqli_query($conn, $sql);
if ($res) {
    $order = mysqli_fetch_assoc($res);
}

if (!$order) {
    header("Location: my-orders.php?msg=Order+not+found");
    exit();
}

include('includes/header.php');
$h = function ($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); };

$status = $order['order_status'];
$steps = ['Pending', 'Confirmed', 'On the Way', 'Delivered'];
$current_step = array_search($status, $steps);
?>

<div class="container mt-5 mb-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <h4 class="fw-bold mb-4">
                <i class="fas fa-map-marker-alt text-danger me-2"></i>
                Track Order #<?php echo qb_order_display_id((int)$order_id); ?>
            </h4>
            
            <div class="row g-4">
                <div class="col-md-5">
                    <div class="card border-0 shadow-sm rounded-4 p-4 h-100">
                        <h6 class="fw-bold mb-4 text-uppercase small text-muted">Order Progress</h6>
                        <div class="tracking-list">
                            <?php foreach ($steps as $index => $step_name): ?>
                                <div class="tracking-item <?php echo ($index <= $current_step) ? 'active' : ''; ?>">
                                    <div class="tracking-icon">
                                        <i class="fas <?php 
                                            if($index == 0) echo 'fa-receipt';
                                            if($index == 1) echo 'fa-utensils';
                                            if($index == 2) echo 'fa-motorcycle';
                                            if($index == 3) echo 'fa-check-circle';
                                        ?>"></i>
                                    </div>
                                    <div class="tracking-content">
                                        <h6 class="fw-bold mb-0"><?php echo $step_name; ?></h6>
                                        <p class="text-muted small mb-0">
                                            <?php 
                                            if($index == 0) echo "Order received & payment verified.";
                                            if($index == 1) echo "Chef is preparing your fresh meal.";
                                            if($index == 2) echo "Rider is heading to your location.";
                                            if($index == 3) echo "Food delivered! Hope you enjoy it.";
                                            ?>
                                        </p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="col-md-7">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4 position-relative">
                        <div class="map-overlay-top p-3 position-absolute w-100" style="z-index: 2; background: linear-gradient(to bottom, rgba(255,255,255,0.9), transparent);">
                            <span class="badge bg-danger rounded-pill px-3 shadow-sm">
                                <span class="spinner-grow spinner-grow-sm me-1"></span> Live Tracking
                            </span>
                        </div>

                        <div class="tracking-map-wrap position-relative">
                            <iframe
                                title="Ankleshwar Gujarat Map"
                                src="https://www.google.com/maps?q=Ankleshwar,Gujarat,India&z=11&output=embed"
                                class="tracking-map-frame"
                                loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade">
                            </iframe>

                            <div class="map-location-chip">
                                <i class="fas fa-location-dot text-danger me-2"></i>
                                Ankleshwar, Gujarat, India
                            </div>
                        </div>

                        <div class="map-rider-marker" style="position: absolute; top: 42%; left: 48%;">
                            <div class="marker-container text-center">
                                <img src="https://cdn-icons-png.flaticon.com/512/3195/3195878.png" width="45" class="rider-icon-move">
                                <div class="marker-shadow mx-auto"></div>
                            </div>
                        </div>

                        <div class="position-absolute bottom-0 w-100 p-3 bg-white border-top shadow-sm">
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="small fw-bold"><i class="fas fa-bicycle text-danger me-2"></i> Rider is moving near your location</span>
                                <span class="text-muted small">ETA: 12 Mins</span>
                            </div>
                        </div>
                    </div>

                    <?php if ($order['rider_id']): ?>
                        <div class="card border-0 shadow-sm rounded-4 p-3 bg-dark text-white">
                            <div class="d-flex align-items-center">
                                <div class="position-relative me-3">
                                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($order['rider_name']); ?>&background=ff4757&color=fff" 
                                         class="rounded-circle border border-2 border-danger" width="60">
                                    <span class="position-absolute bottom-0 end-0 bg-success border border-2 border-dark rounded-circle p-1"></span>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="fw-bold mb-0 text-white"><?php echo $h($order['rider_name']); ?></h6>
                                    <small class="text-danger fw-bold d-block mb-1">+91 <?php echo $h($order['rider_phone']); ?></small>
                                    <small class="text-white-50">Delivery Partner</small>
                                </div>
                                <div class="d-flex gap-2">
                                    <a href="tel:<?php echo preg_replace('/[^0-9]/', '', (string)$order['rider_phone']); ?>" class="btn btn-danger rounded-pill shadow-sm">
                                        <i class="fas fa-phone-alt"></i>
                                    </a>
                                    <a href="https://wa.me/91<?php echo preg_replace('/[^0-9]/', '', (string)$order['rider_phone']); ?>" target="_blank" class="btn btn-outline-success border-0 rounded-pill shadow-sm">
                                        <i class="fab fa-whatsapp"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card border-0 shadow-sm rounded-4 p-4 text-center bg-light">
                            <div class="spinner-border text-danger mb-3" role="status"></div>
                            <h6 class="fw-bold mb-1">Waiting for Rider Assignment</h6>
                            <p class="text-muted small mb-0">Don't worry, we are assigning a rider soon!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .tracking-list { position: relative; }
    .tracking-item { position: relative; display: flex; align-items: flex-start; margin-bottom: 25px; opacity: 0.3; transition: 0.4s; }
    .tracking-item.active { opacity: 1; }
    .tracking-icon { 
        min-width: 40px; height: 40px; border-radius: 50%; background: #eee; 
        display: flex; align-items: center; justify-content: center; margin-right: 15px; 
        z-index: 2; position: relative; color: #888;
    }
    .tracking-item.active .tracking-icon { background: #ff4757; color: #fff; box-shadow: 0 0 15px rgba(255, 71, 87, 0.4); }
    .tracking-item:not(:last-child)::after {
        content: ''; position: absolute; left: 19px; top: 40px; width: 2px; height: calc(100% - 15px);
        background: #eee; z-index: 1;
    }
    .tracking-item.active:not(:last-child)::after { background: #ff4757; }

    .tracking-map-wrap {
        height: 300px;
        background: #eef2f7;
    }
    .tracking-map-frame {
        width: 100%;
        height: 100%;
        border: 0;
        filter: saturate(1.05) contrast(1.02);
    }
    .map-location-chip {
        position: absolute;
        left: 16px;
        bottom: 16px;
        z-index: 2;
        background: rgba(255,255,255,0.94);
        color: #1f2937;
        border: 1px solid rgba(0,0,0,0.08);
        border-radius: 999px;
        padding: 8px 14px;
        font-size: 0.82rem;
        font-weight: 700;
        box-shadow: 0 10px 22px rgba(0,0,0,0.10);
    }
    .map-rider-marker {
        z-index: 3;
        transform: translate(-50%, -100%);
    }
    .rider-icon-move { animation: bounce 2s infinite ease-in-out; }
    @keyframes bounce {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
    }
    .marker-shadow { 
        width: 30px; height: 8px; background: rgba(0,0,0,0.15); border-radius: 50%; 
        filter: blur(3px); 
    }
</style>

<script>
    setTimeout(function(){ window.location.reload(); }, 30000); 
</script>

<?php include('includes/footer.php'); ?>
