-- Database constraints ko temporary disable karein taaki drop/create mein error na aaye
SET FOREIGN_KEY_CHECKS = 0;

-- Purani tables ko delete karein agar wo exist karti hain
DROP TABLE IF EXISTS help_queries;
DROP TABLE IF EXISTS payouts;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS foods;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

-- 1. Users Table (Admin, Customer, aur Delivery Boy ke liye)
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    role ENUM('admin', 'user', 'delivery') DEFAULT 'user',
    -- Delivery/Rider specific columns
    vehicle_no VARCHAR(50) NULL,
    is_online ENUM('Yes', 'No') DEFAULT 'No',
    lat VARCHAR(100) DEFAULT '0', -- Live Latitude
    lng VARCHAR(100) DEFAULT '0', -- Live Longitude
    wallet_balance DECIMAL(10, 2) DEFAULT 0.00,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',
    last_seen TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Categories Table
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    image VARCHAR(255),
    is_active ENUM('Yes', 'No') DEFAULT 'Yes'
);

-- 3. Foods Table
CREATE TABLE foods (
    id INT PRIMARY KEY AUTO_INCREMENT,
    cat_id INT,
    title VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255),
    description TEXT,
    is_available ENUM('Yes', 'No') DEFAULT 'Yes',
    CONSTRAINT fk_food_category FOREIGN KEY (cat_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- 4. Orders Table
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,           -- Kisne order kiya
    rider_id INT NULL,     -- Kaun delivery karega
    total_amount DECIMAL(10,2) NOT NULL,
    payment_mode ENUM('COD', 'Online') NOT NULL,
    payment_status ENUM('Pending', 'Paid', 'Failed') DEFAULT 'Pending',
    order_status ENUM('Pending', 'Confirmed', 'On the Way', 'Delivered', 'Cancelled') DEFAULT 'Pending',
    delivery_address TEXT NOT NULL,
    transaction_id VARCHAR(100) NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_order_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_order_rider FOREIGN KEY (rider_id) REFERENCES users(id) ON DELETE SET NULL
);

-- 4B. Payouts Table (For Delivery Boy Withdrawals/Transfers)
CREATE TABLE payouts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    rider_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('Pending', 'Completed', 'Failed') DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payout_rider FOREIGN KEY (rider_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 5. Order Items Table
CREATE TABLE order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    food_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_item_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_item_food FOREIGN KEY (food_id) REFERENCES foods(id) ON DELETE CASCADE
);

-- 6. Help/Support Table
CREATE TABLE help_queries (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    subject VARCHAR(255),
    message TEXT,
    status ENUM('Open', 'Resolved') DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_help_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Constraints ko wapas chalu karein
SET FOREIGN_KEY_CHECKS = 1;

-- Default Admin User Insert karein (Password: admin123)
-- Hash use kiya gaya hai security ke liye
INSERT INTO users (name, email, password, role, status) 
VALUES ('Main Admin', 'admin@gmail.com', '$2y$10$8Wv6pX/fWzD7I5P.fCqWReo/L2YpS0YmD/N.q5U7QoY0Q7zWvE9fS', 'admin', 'Active');





