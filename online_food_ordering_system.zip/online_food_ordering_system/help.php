<?php
// Database aur Header ko include karein
include('config/db.php');
include('includes/header.php');
require_once(__DIR__ . '/user/includes/csrf.php');

// Contact Details (Aap yahan apna number/email change kar sakte ho)
$support_phone = '7874042063';
$support_whatsapp = '7600565960';
$support_email = 'monu.help@gmail.com';

// Form Submission Logic
$message_sent = false;
$error_msg = '';
$ticket_id = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_query'])) {
    $csrf_token = (string)($_POST['csrf_token'] ?? '');
    if (!qb_csrf_validate($csrf_token)) {
        $error_msg = 'Invalid request. Please refresh the page and try again.';
    } else {
        $subject = trim((string)($_POST['subject'] ?? ''));
        $message = trim((string)($_POST['message'] ?? ''));

        // Optional contact details (without DB change: we prepend into message)
        $contact_name = trim((string)($_POST['contact_name'] ?? ''));
        $contact_email = trim((string)($_POST['contact_email'] ?? ''));
        $contact_phone = trim((string)($_POST['contact_phone'] ?? ''));

        if ($contact_email !== '' && !filter_var($contact_email, FILTER_VALIDATE_EMAIL)) {
            $error_msg = 'Please enter a valid email address.';
        }

        if ($subject === '' || $message === '') {
            if ($error_msg === '') {
                $error_msg = 'Subject and message are required.';
            }
        } elseif ($error_msg === '') {
            $full_message = $message;
            $meta_lines = [];
            if ($contact_name !== '') $meta_lines[] = 'Name: ' . $contact_name;
            if ($contact_email !== '') $meta_lines[] = 'Email: ' . $contact_email;
            if ($contact_phone !== '') $meta_lines[] = 'Phone: ' . $contact_phone;
            if (!empty($meta_lines)) {
                $full_message = implode("\n", $meta_lines) . "\n---\n" . $message;
            }

            $user_id = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;

            if ($user_id !== null && $user_id > 0) {
                $stmt = mysqli_prepare($conn, "INSERT INTO help_queries (user_id, subject, message) VALUES (?, ?, ?)");
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "iss", $user_id, $subject, $full_message);
                    $message_sent = mysqli_stmt_execute($stmt) ? true : false;
                    if ($message_sent) $ticket_id = mysqli_insert_id($conn);
                    mysqli_stmt_close($stmt);
                }
            } else {
                $stmt = mysqli_prepare($conn, "INSERT INTO help_queries (user_id, subject, message) VALUES (NULL, ?, ?)");
                if ($stmt) {
                    mysqli_stmt_bind_param($stmt, "ss", $subject, $full_message);
                    $message_sent = mysqli_stmt_execute($stmt) ? true : false;
                    if ($message_sent) $ticket_id = mysqli_insert_id($conn);
                    mysqli_stmt_close($stmt);
                }
            }

            if (!$message_sent && $error_msg === '') {
                $error_msg = 'Failed to submit query. Please try again.';
            }
        }
    }
}

$qb_csrf_token = qb_csrf_token();

$phone_digits = preg_replace('/\\D+/', '', $support_phone);
$wa_digits = preg_replace('/\\D+/', '', $support_whatsapp);
$tel_href = $phone_digits ? ('tel:' . $phone_digits) : '#';
$wa_href = $wa_digits ? ('https://wa.me/' . $wa_digits) : '#';
?>

<style>
    :root { --qb-red: #ff4757; --qb-dark: #2f3542; }
    .qb-help-hero {
        background: radial-gradient(1200px 600px at 15% 10%, rgba(255, 71, 87, 0.18), transparent 55%),
                    radial-gradient(900px 450px at 85% 25%, rgba(47, 53, 66, 0.12), transparent 55%),
                    linear-gradient(135deg, #ffffff 0%, #fff8f8 45%, #ffffff 100%);
        border-bottom: 1px solid rgba(0,0,0,0.06);
    }
    .qb-help-card {
        border: 1px solid rgba(0,0,0,0.06);
        border-radius: 18px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.06);
    }
    .qb-help-icon {
        width: 48px; height: 48px;
        display: inline-flex; align-items: center; justify-content: center;
        border-radius: 14px;
        background: rgba(255, 71, 87, 0.10);
        color: var(--qb-red);
        flex: 0 0 auto;
    }
    .qb-chip {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        border-radius: 999px;
        border: 1px solid rgba(0,0,0,0.08);
        background: rgba(255,255,255,0.75);
        backdrop-filter: blur(8px);
    }
    .qb-chip i { color: var(--qb-red); }
    .qb-soft { color: rgba(47, 53, 66, 0.75); }
    .qb-kpi {
        border-radius: 16px;
        border: 1px solid rgba(0,0,0,0.06);
        background: #fff;
    }
    .accordion-button:focus { box-shadow: none; }
    .accordion-button:not(.collapsed) { background: rgba(255, 71, 87, 0.08); color: var(--qb-dark); }
</style>

<section class="qb-help-hero py-5">
    <div class="container">
        <div class="row align-items-center g-4">
            <div class="col-lg-7">
                <div class="d-flex flex-wrap gap-2 mb-3">
                    <span class="qb-chip"><i class="fas fa-headset"></i> Support</span>
                    <span class="qb-chip"><i class="fas fa-clock"></i> Response: 5-30 min</span>
                    <span class="qb-chip"><i class="fas fa-shield-halved"></i> Secure</span>
                </div>
                <h1 class="fw-bold display-6 mb-2">Help &amp; Support</h1>
                <p class="lead qb-soft mb-4">
                    Order, payment, delivery, ya account se related koi bhi problem ho &mdash; yahan se support mil jayega.
                </p>

                <div class="row g-3">
                    <div class="col-sm-6">
                        <div class="qb-kpi p-3">
                            <div class="fw-bold">Support Hours</div>
                            <div class="small qb-soft">Mon-Sun, 9:00 AM - 9:00 PM</div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="qb-kpi p-3">
                            <div class="fw-bold">Ticket System</div>
                            <div class="small qb-soft">Submit form to get Ticket ID</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="qb-help-card bg-white p-4">
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <span class="qb-help-icon"><i class="fas fa-phone"></i></span>
                        <div>
                            <div class="fw-bold">Call Us</div>
                            <a class="text-decoration-none<?php echo $tel_href === '#' ? ' disabled' : ''; ?>" <?php echo $tel_href === '#' ? 'aria-disabled="true"' : ''; ?> href="<?php echo htmlspecialchars($tel_href); ?>">
                                <?php echo htmlspecialchars($support_phone); ?>
                            </a>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-3 mb-3">
                        <span class="qb-help-icon"><i class="fab fa-whatsapp"></i></span>
                        <div>
                            <div class="fw-bold">WhatsApp</div>
                            <a class="text-decoration-none<?php echo $wa_href === '#' ? ' disabled' : ''; ?>" <?php echo $wa_href === '#' ? 'aria-disabled="true"' : ''; ?> target="_blank" rel="noopener" href="<?php echo htmlspecialchars($wa_href); ?>">
                                <?php echo htmlspecialchars($support_whatsapp); ?>
                            </a>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-3">
                        <span class="qb-help-icon"><i class="fas fa-envelope"></i></span>
                        <div>
                            <div class="fw-bold">Gmail</div>
                            <a class="text-decoration-none" href="mailto:<?php echo htmlspecialchars($support_email); ?>">
                                <?php echo htmlspecialchars($support_email); ?>
                            </a>
                        </div>
                    </div>

                    <hr class="my-4">
                    <div class="fw-bold mb-2">Quick Actions</div>
                    <div class="d-flex flex-wrap gap-2">
                        <a class="btn btn-outline-dark btn-sm rounded-pill px-3 fw-bold" href="<?php echo SITEURL; ?>user/index.php#menu">Menu</a>
                        <a class="btn btn-outline-dark btn-sm rounded-pill px-3 fw-bold" href="<?php echo SITEURL; ?>user/my-orders.php">My Orders</a>
                        <a class="btn btn-outline-dark btn-sm rounded-pill px-3 fw-bold" href="<?php echo SITEURL; ?>user/track-order.php">Track</a>
                        <a class="btn btn-danger btn-sm rounded-pill px-3 fw-bold" href="<?php echo SITEURL; ?>user/auth/login.php">Login</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container my-5">
    <div class="row g-4">
        <div class="col-lg-6">
            <h3 class="mb-3 fw-bold">Frequently Asked Questions</h3>
            <div class="accordion qb-help-card overflow-hidden" id="faqAccordion">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                            How do I track my order?
                        </button>
                    </h2>
                    <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Login karne ke baad <b>My Orders</b> section mein jayein. Agar aapka order <b>On the Way</b> hai,
                            toh <b>Track</b> button par click karke rider ki live location dekh sakte hain.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                            What payment methods are available?
                        </button>
                    </h2>
                    <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Hum <b>Cash on Delivery (COD)</b> aur <b>Online Payment</b> (UPI / Wallet / Debit / Credit Card) options support karte hain.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                            Can I cancel my order?
                        </button>
                    </h2>
                    <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Aap tab tak cancel kar sakte hain jab tak order prepare/dispatch nahi hua. Agar order already confirm ho chuka ho,
                            toh help form se request bhej dein.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                            Login/Logout issue ho raha hai, kya karein?
                        </button>
                    </h2>
                    <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            Browser ka cache/cookies clear karke dubara login try karein. Agar phir bhi issue aaye, form me details bhej dein.
                        </div>
                    </div>
                </div>

                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                            Payment success ke baad order confirm nahi dikh raha?
                        </button>
                    </h2>
                    <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <b>My Orders</b> page refresh karein. Agar payment done hai par status update nahi hua, toh "Payment Problem" select karke
                            order id/number ke saath message bhej dein.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="qb-help-card bg-white p-4 p-md-5">
                <h3 class="mb-4 fw-bold">Send us a Message</h3>

                <?php if ($message_sent): ?>
                    <div class="alert alert-success mb-4">
                        Your query has been submitted successfully.
                        <?php if (!empty($ticket_id)): ?>
                            <div class="mt-1"><b>Ticket ID:</b> #<?php echo (int)$ticket_id; ?></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <?php if (!$message_sent && $error_msg): ?>
                    <div class="alert alert-danger mb-4"><?php echo htmlspecialchars($error_msg); ?></div>
                <?php endif; ?>

                <form action="" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($qb_csrf_token); ?>">

                    <div class="row g-3 mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Name (Optional)</label>
                            <input type="text" name="contact_name" class="form-control" placeholder="Your name" maxlength="80">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Email (Optional)</label>
                            <input type="email" name="contact_email" class="form-control" placeholder="you@gmail.com" maxlength="120">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Phone (Optional)</label>
                            <input type="text" name="contact_phone" class="form-control" placeholder="+91 9XXXX XXXXX" maxlength="30">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <select name="subject" class="form-select" required>
                            <option value="">Choose a reason...</option>
                            <option value="Order Issue">Order Issue</option>
                            <option value="Payment Problem">Payment Problem</option>
                            <option value="Delivery Delay">Delivery Delay</option>
                            <option value="Login/Logout Issue">Login/Logout Issue</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Message</label>
                        <textarea name="message" class="form-control" rows="6" placeholder="Order ID / Mobile / Issue details..." required></textarea>
                        <div class="form-text">Tip: Order ID/number + exact problem likho, to jaldi solution milega.</div>
                    </div>

                    <button type="submit" name="submit_query" class="btn btn-danger w-100 fw-bold rounded-pill py-2">
                        Submit Query
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
