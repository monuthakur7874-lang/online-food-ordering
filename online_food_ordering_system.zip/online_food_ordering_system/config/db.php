<?php
/**
 * QuickBite - Database Configuration
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    // --- Session hardening + avoid cross-panel logout (separate sessions per panel) ---
    // Note: This will require re-login once because cookie name changes.
    $script_name = $_SERVER['SCRIPT_NAME'] ?? '';
    if (strpos($script_name, '/admin/') !== false) {
        session_name('QB_ADMIN_SESSID');
    } elseif (strpos($script_name, '/delivery/') !== false) {
        session_name('QB_DELIVERY_SESSID');
    } else {
        // Default session for public + user area
        session_name('QB_USER_SESSID');
    }

    // Keep sessions longer to prevent "automatic logout"
    ini_set('session.gc_maxlifetime', '28800'); // 8 hours
    ini_set('session.cookie_lifetime', '28800'); // 8 hours

    // Cookie scope to this project folder (auto-detect base path)
    $script_name = $_SERVER['SCRIPT_NAME'] ?? '/';
    $qb_cookie_path = '/';
    foreach (['/user/', '/admin/', '/delivery/'] as $marker) {
        $pos = strpos($script_name, $marker);
        if ($pos !== false) {
            $qb_cookie_path = substr($script_name, 0, $pos + 1);
            break;
        }
    }
    if ($qb_cookie_path === '/' && $script_name !== '/') {
        $qb_cookie_path = rtrim(str_replace('\\', '/', dirname($script_name)), '/') . '/';
    }
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params([
            'lifetime' => 28800,
            'path' => $qb_cookie_path,
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on'),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } else {
        session_set_cookie_params(28800, $qb_cookie_path);
    }

    session_start();
}

// Database Credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food_db"; // Ensure this matches your phpMyAdmin DB name

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");
date_default_timezone_set('Asia/Kolkata');

if (!function_exists('qb_backfill_delivered_cod_payments')) {
    function qb_backfill_delivered_cod_payments(mysqli $conn, array $filters = []): void {
        $conditions = [
            "payment_mode = 'COD'",
            "order_status = 'Delivered'",
            "payment_status <> 'Paid'",
        ];

        if (isset($filters['user_id'])) {
            $conditions[] = 'user_id = ' . (int)$filters['user_id'];
        }

        if (isset($filters['rider_id'])) {
            $conditions[] = 'rider_id = ' . (int)$filters['rider_id'];
        }

        if (isset($filters['order_id'])) {
            $conditions[] = 'id = ' . (int)$filters['order_id'];
        }

        $sql = "UPDATE orders SET payment_status = 'Paid' WHERE " . implode(' AND ', $conditions);
        @mysqli_query($conn, $sql);
    }
}

if (!function_exists('qb_order_display_id')) {
    function qb_order_display_id(int $order_id): string {
        $safe_id = max(0, $order_id);
        $hashed = 1000 + ((($safe_id * 7919) + 4173) % 9000);
        return str_pad((string)$hashed, 4, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('qb_order_display_label')) {
    function qb_order_display_label(int $order_id, string $prefix = ''): string {
        return $prefix . qb_order_display_id($order_id);
    }
}

// --- Dynamic SITEURL Detection ---
if (!defined('SITEURL')) {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/');
    $project_folder = '/';

    foreach (['/admin/', '/user/', '/delivery/'] as $marker) {
        $pos = strpos($script_name, $marker);
        if ($pos !== false) {
            $project_folder = rtrim(substr($script_name, 0, $pos), '/') . '/';
            break;
        }
    }

    if ($project_folder === '/' && $script_name !== '/') {
        $dir = rtrim(dirname($script_name), '/');
        $project_folder = ($dir === '' || $dir === '.') ? '/' : $dir . '/';
    }

    define('SITEURL', $protocol . $host . $project_folder);
}

// Global Path Constants
if (!defined('ADMIN_URL')) define('ADMIN_URL', SITEURL . 'admin/');
if (!defined('ASSETS_URL')) define('ASSETS_URL', SITEURL . 'assets/');

// Image Paths (Paths corrected to match your folder structure)
if (!defined('FOOD_IMG')) define('FOOD_IMG', ASSETS_URL . 'img/food/');
if (!defined('CAT_IMG')) define('CAT_IMG', ASSETS_URL . 'img/category/');
