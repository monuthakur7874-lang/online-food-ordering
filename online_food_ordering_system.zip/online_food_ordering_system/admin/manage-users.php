<?php 
/**
 * QuickBite - Premium User & Rider Management (Ultimate Edition)
 * File: admin/manage-users.php
 */

include_once('includes/header.php'); 

// Security Check: Only Admin can access
if(!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    echo "<script>window.location='index.php';</script>";
    exit();
}

$csrf_token = function_exists('qb_csrf_token') ? qb_csrf_token() : ($_SESSION['csrf_token'] ?? '');

$msg = "";

// --- 1. UPDATE USER STATUS ---
if(isset($_GET['status_id']) && isset($_GET['current_status'])) {
    qb_require_csrf($_GET['csrf_token'] ?? '');
    $id = intval($_GET['status_id']);
    $new_status = ($_GET['current_status'] == 'Active') ? 'Inactive' : 'Active';
    
    $sql_status = "UPDATE users SET status = '$new_status' WHERE id = $id AND role != 'admin'";
    if(mysqli_query($conn, $sql_status)) {
        echo "<script>window.location='manage-users.php';</script>";
    }
}

// --- 2. DELETE USER LOGIC ---
if(isset($_GET['delete_id'])) {
    qb_require_csrf($_GET['csrf_token'] ?? '');
    $id = intval($_GET['delete_id']);
    $sql_del = "DELETE FROM users WHERE id = $id AND role != 'admin'";
    if(mysqli_query($conn, $sql_del)) {
        echo "<script>alert('Account Removed!'); window.location='manage-users.php';</script>";
    }
}
?>

<style>
    :root { --qb-primary: #de1f26; --qb-dark: #1a1a1a; }
    
    /* Stats & Cards */
    .stats-card { border: none; border-radius: 20px; background: #fff; box-shadow: 0 5px 20px rgba(0,0,0,0.05); transition: 0.3s; }
    .stats-card:hover { transform: translateY(-5px); }
    
    /* Avatars */
    .user-avatar { width: 48px; height: 48px; display: flex; align-items: center; justify-content: center; font-weight: bold; border-radius: 14px; }
    .role-customer { background: #e3f2fd; color: #1976d2; }
    .role-delivery { background: #fff3e0; color: #f57c00; }
    
    /* Navigation & Search */
    .nav-pills .nav-link { color: #6c757d; font-weight: 600; border-radius: 12px; padding: 10px 20px; border: 1px solid transparent; }
    .nav-pills .nav-link.active { background-color: var(--qb-dark); color: #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .search-input { border-radius: 12px; padding-left: 45px; border: 1px solid #eee; height: 45px; box-shadow: none !important; }
    .search-icon { position: absolute; left: 18px; top: 13px; color: #bbb; }
    
    /* Table Styling */
    .table thead th { font-size: 0.7rem; text-transform: uppercase; letter-spacing: 1px; color: #999; border: none; padding: 15px 10px; }
    .user-row { transition: 0.2s; }
    .user-row:hover { background-color: #fcfcfc !important; }
    
    /* Custom Map Button */
    .map-btn { border: 1px solid; padding: 6px 14px; border-radius: 10px; font-size: 12px; font-weight: 600; transition: 0.2s; display: inline-flex; align-items: center; text-decoration: none !important; }
    .btn-gps { background: #f0fdf4; color: #16a34a; border-color: #dcfce7; }
    .btn-gps:hover { background: #16a34a; color: #fff; }
    .btn-address { background: #eff6ff; color: #2563eb; border-color: #dbeafe; }
    .btn-address:hover { background: #2563eb; color: #fff; }
</style>

<div class="container-fluid px-4 py-4">
    <div class="row align-items-center mb-4">
        <div class="col-md-6">
            <h3 class="fw-bold text-dark mb-1">Community Control</h3>
            <p class="text-muted small">Manage and track your customers and delivery riders.</p>
        </div>
        <div class="col-md-6 text-md-end">
            <button class="btn btn-white shadow-sm border-0 rounded-3 px-3 fw-bold" onclick="location.reload()">
                <i class="fas fa-sync-alt me-2 text-primary"></i>Refresh Data
            </button>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="stats-card p-3 d-flex align-items-center">
                <div class="user-avatar role-customer me-3"><i class="fas fa-users"></i></div>
                <div>
                    <h4 class="fw-bold mb-0"><?php echo mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(id) as total FROM users WHERE role='user'"))['total']; ?></h4>
                    <small class="text-muted fw-semibold">Total Customers</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card p-3 d-flex align-items-center">
                <div class="user-avatar role-delivery me-3"><i class="fas fa-motorcycle"></i></div>
                <div>
                    <h4 class="fw-bold mb-0"><?php echo mysqli_fetch_assoc(mysqli_query($conn, "SELECT count(id) as total FROM users WHERE role='delivery'"))['total']; ?></h4>
                    <small class="text-muted fw-semibold">Fleet Riders</small>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4 align-items-center g-3">
        <div class="col-lg-6">
            <ul class="nav nav-pills gap-2" id="userFilter">
                <li class="nav-item"><a class="nav-link active" href="#" data-filter="all">All Members</a></li>
                <li class="nav-item"><a class="nav-link" href="#" data-filter="user">Customers</a></li>
                <li class="nav-item"><a class="nav-link" href="#" data-filter="delivery">Riders</a></li>
            </ul>
        </div>
        <div class="col-lg-6">
            <div class="position-relative">
                <i class="fas fa-search search-icon"></i>
                <input type="text" id="userSearch" class="form-control search-input" placeholder="Search name, email, or role...">
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="table-responsive">
            <table class="table align-middle mb-0" id="userTable">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4">User Details</th>
                        <th>Role</th>
                        <th>Contact Information</th>
                        <th>Visit Location</th>
                        <th>Account Status</th>
                        <th class="text-end pe-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $sql = "SELECT * FROM users WHERE role != 'admin' ORDER BY id DESC";
                    $res = mysqli_query($conn, $sql);
                    
                    if(mysqli_num_rows($res) > 0) {
                        while($row = mysqli_fetch_assoc($res)) {
                            $is_rider = ($row['role'] == 'delivery');
                            $name = $row['name'] ?? 'User';
                            $initial = strtoupper(substr($name, 0, 1));
                            ?>
                            <tr class="user-row" data-role="<?php echo $row['role']; ?>">
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <div class="user-avatar <?php echo $is_rider ? 'role-delivery' : 'role-customer'; ?> me-3 shadow-sm">
                                            <?php echo $initial; ?>
                                        </div>
                                        <div>
                                            <div class="fw-bold text-dark mb-0"><?php echo $name; ?></div>
                                            <small class="text-muted" style="font-size: 11px;">#ID-<?php echo sprintf("%04d", $row['id']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge <?php echo $is_rider ? 'bg-warning-subtle text-warning' : 'bg-info-subtle text-info'; ?> rounded-pill px-3 py-2 border-0 small fw-bold">
                                        <i class="fas <?php echo $is_rider ? 'fa-motorcycle' : 'fa-shopping-bag'; ?> me-1"></i>
                                        <?php echo ucfirst($row['role']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="small fw-semibold text-dark"><i class="far fa-envelope me-1 text-muted"></i> <?php echo $row['email']; ?></div>
                                    <div class="small text-muted mt-1">
                                        <i class="fas fa-phone-alt me-1 opacity-50"></i> <?php echo $row['phone'] ?: 'N/A'; ?>
                                    </div>
                                </td>
                                <td>
                                    <?php 
                                    // LOGIC: Visit Location based on GPS or Address
                                    if(!empty($row['lat']) && !empty($row['lng'])): ?>
                                        <a href="https://www.google.com/maps?q=<?php echo $row['lat'].','.$row['lng']; ?>" target="_blank" class="map-btn btn-gps">
                                            <i class="fas fa-map-marker-alt me-2"></i> Visit GPS
                                        </a>
                                    <?php elseif(!empty($row['address'])): ?>
                                        <a href="https://www.google.com/maps/search/<?php echo urlencode($row['address']); ?>" target="_blank" class="map-btn btn-address">
                                            <i class="fas fa-search-location me-2"></i> Visit Address
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted small"><i class="fas fa-times-circle me-1"></i> No Location</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="?status_id=<?php echo $row['id']; ?>&current_status=<?php echo $row['status']; ?>&csrf_token=<?php echo urlencode($csrf_token); ?>" 
                                       class="badge rounded-pill text-decoration-none px-3 py-2 <?php echo ($row['status'] == 'Active') ? 'bg-success shadow-sm' : 'bg-secondary'; ?>">
                                        <?php echo $row['status']; ?>
                                    </a>
                                </td>
                                <td class="text-end pe-4">
                                    <a href="?delete_id=<?php echo $row['id']; ?>&csrf_token=<?php echo urlencode($csrf_token); ?>" class="btn btn-sm btn-light border rounded-3 text-danger px-3" 
                                       onclick="return confirm('Permanent Action: Delete this account?')">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center p-5 text-muted'>No community members found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// Filter Functionality
document.querySelectorAll('#userFilter .nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelectorAll('#userFilter .nav-link').forEach(l => l.classList.remove('active'));
        this.classList.add('active');
        
        let filter = this.getAttribute('data-filter');
        document.querySelectorAll('.user-row').forEach(row => {
            row.style.display = (filter === 'all' || row.getAttribute('data-role') === filter) ? '' : 'none';
        });
    });
});

// Live Search Functionality
document.getElementById('userSearch').addEventListener('keyup', function() {
    let value = this.value.toLowerCase();
    document.querySelectorAll('.user-row').forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = (text.indexOf(value) > -1) ? '' : 'none';
    });
});
</script>

<?php include_once('includes/footer.php'); ?>
