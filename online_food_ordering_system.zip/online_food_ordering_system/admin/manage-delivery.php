<?php 
/**
 * QuickBite Premium Fleet Management & Order Assignment
 * File: admin/manage-delivery.php
 */
include_once('includes/header.php'); 

// Security Check
if(!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    echo "<script>window.location='index.php';</script>";
    exit();
}

$csrf_token = function_exists('qb_csrf_token') ? qb_csrf_token() : ($_SESSION['csrf_token'] ?? '');

$msg = "";

// --- 1. NEW: ORDER ASSIGNMENT LOGIC ---
if(isset($_POST['assign_order'])) {
    qb_require_csrf();

    $order_id = (int)($_POST['order_id'] ?? 0);
    $rider_id = (int)($_POST['rider_id'] ?? 0);

    if ($order_id <= 0 || $rider_id <= 0) {
        $msg = "<div class='alert alert-danger border-0 shadow-sm py-3 small'>Invalid order or rider.</div>";
    } else {
        $rider_ok = mysqli_query($conn, "SELECT id FROM users WHERE id={$rider_id} AND role='delivery' AND status='Active' LIMIT 1");
        if (!$rider_ok || mysqli_num_rows($rider_ok) !== 1) {
            $msg = "<div class='alert alert-danger border-0 shadow-sm py-3 small'>Selected rider is invalid or inactive.</div>";
        } else {
            $assign_sql = "UPDATE orders SET rider_id = {$rider_id}, order_status = 'Confirmed' WHERE id = {$order_id}";
            if(mysqli_query($conn, $assign_sql)) {
                $msg = "<div class='alert alert-success border-0 shadow-sm py-3 small animate__animated animate__fadeIn'>Order #" . qb_order_display_id($order_id) . " successfully assigned to Rider!</div>";
            } else {
                $msg = "<div class='alert alert-danger border-0 shadow-sm py-3 small'>Database error while assigning order.</div>";
            }
        }
    }
}

// --- EXISTING LOGIC (Rider Management) ---
if(isset($_GET['action']) && $_GET['action'] == 'status') {
    qb_require_csrf($_GET['csrf_token'] ?? '');
    $id = (int)($_GET['id'] ?? 0);
    $new_status = (($_GET['status'] ?? '') == 'Active') ? 'Inactive' : 'Active';
    if ($id > 0) {
        mysqli_query($conn, "UPDATE users SET status='{$new_status}' WHERE id={$id} AND role='delivery'");
    }
    echo "<script>window.location='manage-delivery.php';</script>";
}

if(isset($_GET['action']) && $_GET['action'] == 'delete') {
    qb_require_csrf($_GET['csrf_token'] ?? '');
    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        mysqli_query($conn, "DELETE FROM users WHERE id={$id} AND role='delivery'");
    }
    $msg = "<div class='alert alert-success border-0 shadow-sm py-3 small animate__animated animate__fadeIn'>Rider removed from system.</div>";
}

if(isset($_POST['add_rider'])) {
    qb_require_csrf();
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $check = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
    if(mysqli_num_rows($check) > 0) {
        $msg = "<div class='alert alert-danger border-0 shadow-sm py-3 small animate__animated animate__shakeX'>Email already registered!</div>";
    } else {
        $sql = "INSERT INTO users (name, email, phone, password, role, status) VALUES ('$name', '$email', '$phone', '$password', 'delivery', 'Active')";
        if(mysqli_query($conn, $sql)) {
            $msg = "<div class='alert alert-success border-0 shadow-sm py-3 small animate__animated animate__fadeIn'>New rider onboarded successfully!</div>";
        }
    }
}

if (isset($_POST['update_rider'])) {
    qb_require_csrf();

    $rider_id = (int)($_POST['rider_id'] ?? 0);
    $name = mysqli_real_escape_string($conn, trim((string)($_POST['name'] ?? '')));
    $email = mysqli_real_escape_string($conn, trim((string)($_POST['email'] ?? '')));
    $phone = mysqli_real_escape_string($conn, trim((string)($_POST['phone'] ?? '')));
    $status = (($_POST['status'] ?? 'Active') === 'Inactive') ? 'Inactive' : 'Active';
    $new_password = (string)($_POST['password'] ?? '');

    if ($rider_id <= 0 || $name === '' || $email === '') {
        $msg = "<div class='alert alert-danger border-0 shadow-sm py-3 small'>Rider details are incomplete.</div>";
    } else {
        $dup_res = mysqli_query($conn, "SELECT id FROM users WHERE email='{$email}' AND id != {$rider_id} LIMIT 1");
        if ($dup_res && mysqli_num_rows($dup_res) > 0) {
            $msg = "<div class='alert alert-danger border-0 shadow-sm py-3 small'>Email already belongs to another account.</div>";
        } else {
            $update_sql = "UPDATE users SET name='{$name}', email='{$email}', phone='{$phone}', status='{$status}'";
            if ($new_password !== '') {
                $safe_password = mysqli_real_escape_string($conn, password_hash($new_password, PASSWORD_DEFAULT));
                $update_sql .= ", password='{$safe_password}'";
            }
            $update_sql .= " WHERE id={$rider_id} AND role='delivery' LIMIT 1";

            if (mysqli_query($conn, $update_sql)) {
                $msg = "<div class='alert alert-success border-0 shadow-sm py-3 small animate__animated animate__fadeIn'>Rider profile updated successfully.</div>";
            } else {
                $msg = "<div class='alert alert-danger border-0 shadow-sm py-3 small'>Database error while updating rider.</div>";
            }
        }
    }
}
?>

<style>
    :root { --qb-primary: #de1f26; }
    .fleet-card { border: none; border-radius: 16px; background: #ffffff; box-shadow: 0 10px 30px rgba(0,0,0,0.05); margin-bottom: 25px; }
    .stat-icon { width: 52px; height: 52px; border-radius: 14px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; transition: 0.3s; }
    .rider-profile { width: 45px; height: 45px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; }
    .badge-active { background: #e8f5e9; color: #2e7d32; border: 1px solid #c8e6c9; }
    .badge-inactive { background: #ffebee; color: #c62828; border: 1px solid #ffcdd2; }
    .order-item { border-left: 4px solid var(--qb-primary); background: #fdfdfd; transition: 0.2s; }
    .order-item:hover { background: #fff; transform: translateX(5px); }
    #ridersMap { height: 360px; border-radius: 16px; overflow: hidden; }
</style>

<div class="container-fluid py-4">
    <?php echo $msg; ?>

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-1">Fleet & Delivery Control</h3>
            <p class="text-muted small">Manage partners and assign incoming orders</p>
        </div>
        <div class="d-flex gap-2">
            <button class="btn btn-primary shadow-sm rounded-3 px-3 fw-bold" data-bs-toggle="modal" data-bs-target="#addRiderModal">
                <i class="fas fa-plus me-2"></i>Onboard Rider
            </button>
        </div>
    </div>

    <!-- Live Rider Location Map -->
    <div class="fleet-card p-3 p-md-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <div>
                <h5 class="fw-bold mb-1"><i class="fas fa-location-crosshairs text-danger me-2"></i>Live Rider Locations</h5>
                <div class="small text-muted">Real-time GPS (updates every 10 seconds)</div>
            </div>
            <div class="small text-muted" id="ridersMapMeta">Loading…</div>
        </div>

        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <div id="ridersMap" class="border"></div>
    </div>

    <div class="row">
        <div class="col-xl-4 col-lg-5">
            <div class="fleet-card">
                <div class="p-4 border-bottom bg-light rounded-top-4">
                    <h5 class="fw-bold mb-0 text-primary"><i class="fas fa-utensils me-2"></i>Pending Assignments</h5>
                </div>
                <div class="p-3" style="max-height: 600px; overflow-y: auto;">
                    <?php 
                    // Sirf wahi orders fetch karein jinka rider_id NULL hai
                    $pending_orders = mysqli_query($conn, "SELECT * FROM orders WHERE rider_id IS NULL OR rider_id = 0 ORDER BY id DESC LIMIT 10");
                    if(mysqli_num_rows($pending_orders) > 0) {
                        while($order = mysqli_fetch_assoc($pending_orders)) {
                    ?>
                        <div class="p-3 mb-3 rounded-3 shadow-sm order-item border">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <span class="fw-bold text-dark">Order #<?php echo qb_order_display_id((int)$order['id']); ?></span>
                                <span class="badge bg-soft-warning text-warning small">Awaiting Rider</span>
                            </div>
                            <p class="small text-muted mb-3"><i class="fas fa-map-marker-alt me-1 text-danger"></i> <?php echo substr($order['delivery_address'], 0, 45).'...'; ?></p>
                            
                            <form action="" method="POST" class="d-flex gap-2">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
                                <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                <select name="rider_id" class="form-select form-select-sm rounded-2" required>
                                    <option value="">Select Rider</option>
                                    <?php 
                                    $available_riders = mysqli_query($conn, "SELECT id, name FROM users WHERE role='delivery' AND status='Active'");
                                    while($ar = mysqli_fetch_assoc($available_riders)) {
                                        echo "<option value='".$ar['id']."'>".$ar['name']."</option>";
                                    }
                                    ?>
                                </select>
                                <button type="submit" name="assign_order" class="btn btn-sm btn-primary px-3 rounded-2">Assign</button>
                            </form>
                        </div>
                    <?php 
                        }
                    } else {
                        echo "<div class='text-center py-5'><i class='fas fa-check-circle text-success mb-2' style='font-size: 2rem;'></i><p class='text-muted small'>All orders are currently assigned!</p></div>";
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="col-xl-8 col-lg-7">
            <div class="fleet-card overflow-hidden">
                <div class="p-4 border-bottom d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <h5 class="fw-bold mb-0">Delivery Partner Directory</h5>
                    <div class="position-relative">
                        <input type="text" id="riderSearch" class="form-control form-control-sm rounded-pill px-4" placeholder="Search riders..." style="width: 200px;">
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="riderTable">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4 py-3 small fw-bold text-muted">PARTNER</th>
                                <th class="small fw-bold text-muted text-center">STATUS</th>
                                <th class="small fw-bold text-muted">CONTACT</th>
                                <th class="text-end pe-4 small fw-bold text-muted">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $riders = mysqli_query($conn, "SELECT * FROM users WHERE role='delivery' ORDER BY id DESC");
                            while($row = mysqli_fetch_assoc($riders)) {
                                $initials = strtoupper(substr($row['name'], 0, 1));
                            ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <div class="rider-profile bg-primary text-white fw-bold me-3 shadow-sm"><?php echo $initials; ?></div>
                                        <div>
                                            <div class="fw-bold text-dark mb-0 small"><?php echo $row['name']; ?></div>
                                            <small class="text-muted">ID: QB-R-<?php echo $row['id']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                    <a href="?action=status&id=<?php echo $row['id']; ?>&status=<?php echo $row['status']; ?>&csrf_token=<?php echo urlencode($csrf_token); ?>">
                                        <span class="badge rounded-pill <?php echo ($row['status'] == 'Active') ? 'badge-active' : 'badge-inactive'; ?> small">
                                            <?php echo $row['status']; ?>
                                        </span>
                                    </a>
                                </td>
                                <td>
                                    <div class="small fw-bold text-dark"><i class="fas fa-phone-alt me-1 text-muted"></i> <?php echo $row['phone']; ?></div>
                                </td>
                                <td class="text-end pe-4">
                                    <button type="button" class="btn btn-sm btn-light text-primary me-1" onclick='openEditModal(<?php echo json_encode($row, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?>)'><i class="fas fa-edit"></i></button>
                                    <a href="?action=delete&id=<?php echo $row['id']; ?>&csrf_token=<?php echo urlencode($csrf_token); ?>" class="btn btn-sm btn-light text-danger" onclick="return confirm('Remove rider?')"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
(() => {
  const el = document.getElementById('ridersMap');
  const meta = document.getElementById('ridersMapMeta');
  if (!el || typeof L === 'undefined') return;

  const ankleshwarLat = 21.6264;
  const ankleshwarLng = 73.0152;
  const defaultZoom = 13;
  const map = L.map('ridersMap', { scrollWheelZoom: true }).setView([ankleshwarLat, ankleshwarLng], defaultZoom);
  window.adminRidersMap = map;
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap'
  }).addTo(map);

  const fallbackMarker = L.marker([ankleshwarLat, ankleshwarLng]).addTo(map);
  fallbackMarker.bindPopup('<b>Ankleshwar, Gujarat, India</b><br>Default delivery area').openPopup();
  L.circle([ankleshwarLat, ankleshwarLng], {
    radius: 1800,
    color: '#e23744',
    fillColor: '#ff7e8b',
    fillOpacity: 0.14,
    weight: 2
  }).addTo(map);

  const markers = new Map();

  function markerFor(r) {
    const lat = parseFloat(r.lat);
    const lng = parseFloat(r.lng);
    if (!isFinite(lat) || !isFinite(lng) || lat === 0 || lng === 0) return null;

    const online = (r.is_online === 'Yes');
    const color = online ? '#22c55e' : '#64748b';
    const fill = online ? 'rgba(34,197,94,0.25)' : 'rgba(100,116,139,0.18)';

    const m = L.circleMarker([lat, lng], {
      radius: online ? 9 : 7,
      color,
      weight: 2,
      fillColor: fill,
      fillOpacity: 1
    });

    const safeName = (r.name || 'Rider').toString().replace(/[<>]/g, '');
    const safePhone = (r.phone || '').toString().replace(/[<>]/g, '');
    const safeSeen = (r.last_seen || '—').toString().replace(/[<>]/g, '');
    const gmaps = `https://www.google.com/maps?q=${lat},${lng}`;

    m.bindPopup(`
      <div style="min-width:220px">
        <div style="font-weight:700">${safeName}</div>
        <div style="font-size:12px; color:#6b7280">Phone: ${safePhone || '—'}</div>
        <div style="font-size:12px; color:#6b7280">Last seen: ${safeSeen}</div>
        <div style="margin-top:8px">
          <a class="btn btn-sm btn-dark" target="_blank" href="${gmaps}">Open in Maps</a>
        </div>
      </div>
    `);
    return m;
  }

  function refresh() {
    fetch('ajax/riders_locations.php', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(rows => {
        const list = Array.isArray(rows) ? rows : [];
        let onlineCount = 0;
        const bounds = [];

        const seenIds = new Set();
        list.forEach(r => {
          const id = Number(r.id);
          if (!id) return;
          seenIds.add(id);
          if (r.is_online === 'Yes') onlineCount++;

          let m = markers.get(id);
          if (m) {
            // Remove and re-add to update style/popup quickly
            map.removeLayer(m);
            markers.delete(id);
            m = null;
          }
          const nm = markerFor(r);
          if (!nm) return;
          nm.addTo(map);
          markers.set(id, nm);
          bounds.push(nm.getLatLng());
        });

        // Remove markers for riders no longer returned
        for (const [id, m] of markers.entries()) {
          if (!seenIds.has(id)) {
            map.removeLayer(m);
            markers.delete(id);
          }
        }

        if (meta) {
          meta.textContent = `Online: ${onlineCount} • Riders: ${list.length} • Updated: ${new Date().toLocaleTimeString()}`;
        }

        if (bounds.length > 0) {
          const b = L.latLngBounds(bounds);
          map.fitBounds(b.pad(0.2), { animate: false });
        }
      })
      .catch(() => {
        if (meta) meta.textContent = 'Failed to load live locations';
      });
  }

  refresh();
  setInterval(refresh, 10000);
})();
</script>

<script>
(() => {
  const ankleshwarLat = 21.6264;
  const ankleshwarLng = 73.0152;
  const defaultZoom = 13;

  function applyAnkleshwarFallback() {
    const meta = document.getElementById('ridersMapMeta');
    const map = window.adminRidersMap;
    if (meta && /Loading|Failed/i.test(meta.textContent || '')) {
      meta.textContent = 'Showing default area: Ankleshwar, Gujarat';
    }
    if (map) {
      map.setView([ankleshwarLat, ankleshwarLng], defaultZoom, { animate: false });
    }
  }

  window.setTimeout(applyAnkleshwarFallback, 1200);
})();
</script>

<script>
function openEditModal(rider) {
  const modalEl = document.getElementById('editRiderModal');
  if (!modalEl || !rider) return;

  document.getElementById('editRiderId').value = Number(rider.id || 0);
  document.getElementById('editRiderName').value = rider.name || '';
  document.getElementById('editRiderEmail').value = rider.email || '';
  document.getElementById('editRiderPhone').value = rider.phone || '';
  document.getElementById('editRiderStatus').value = rider.status === 'Inactive' ? 'Inactive' : 'Active';
  document.getElementById('editRiderPassword').value = '';

  bootstrap.Modal.getOrCreateInstance(modalEl).show();
}
</script>

<!-- Add Rider Modal (was referenced by button but missing) -->
<div class="modal fade" id="addRiderModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h5 class="fw-bold mb-0">Onboard New Rider</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Name</label>
                        <input type="text" name="name" class="form-control rounded-3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Email</label>
                        <input type="email" name="email" class="form-control rounded-3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Phone</label>
                        <input type="text" name="phone" class="form-control rounded-3">
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-bold">Password</label>
                        <input type="password" name="password" class="form-control rounded-3" required>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="add_rider" class="btn btn-primary rounded-3 px-4">Create Rider</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="editRiderModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h5 class="fw-bold mb-0">Edit Rider</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="hidden" name="rider_id" id="editRiderId">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Name</label>
                        <input type="text" name="name" id="editRiderName" class="form-control rounded-3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Email</label>
                        <input type="email" name="email" id="editRiderEmail" class="form-control rounded-3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Phone</label>
                        <input type="text" name="phone" id="editRiderPhone" class="form-control rounded-3">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Status</label>
                        <select name="status" id="editRiderStatus" class="form-select rounded-3">
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                        </select>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-bold">New Password</label>
                        <input type="password" name="password" id="editRiderPassword" class="form-control rounded-3" placeholder="Leave blank to keep current password">
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="update_rider" class="btn btn-primary rounded-3 px-4">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include_once('includes/footer.php'); ?>
