<?php 
require_once(__DIR__ . '/../config/db.php');
require_once(__DIR__ . '/includes/check-admin.php');

// Security: Only logged-in admins can create new accounts from admin panel
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: index.php');
    exit();
}

$csrf_token = function_exists('qb_csrf_token') ? qb_csrf_token() : ($_SESSION['csrf_token'] ?? '');

$error = "";
$success = "";

if(isset($_POST['submit'])) {
    if (function_exists('qb_require_csrf')) qb_require_csrf();
    // Data sanitize karna (Security)
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $role = $_POST['role'] ?? 'user';
    if (!in_array($role, ['user', 'delivery', 'admin'], true)) {
        $role = 'user';
    }
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    // --- Validations ---
    
    // 1. Check if passwords match
    if($password !== $cpassword) {
        $error = "Passwords do not match!";
    } 
    // 2. Check if email is valid format
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format!";
    }
    else {
        // 3. Check if email already exists in Database
        $check_email = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
        if(mysqli_num_rows($check_email) > 0) {
            $error = "This email is already registered. Please login.";
        } else {
            // Password Hashing (College project mein security dikhane ke liye best hai)
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // 4. Insert Query
            $sql = "INSERT INTO users (name, email, phone, password, role) 
                    VALUES ('$name', '$email', '$phone', '$hashed_password', '$role')";
            
            if(mysqli_query($conn, $sql)) {
                $success = "Account created successfully! <a href='index.php' class='alert-link'>Go to Admin Login</a>";
            } else {
                $error = "Database Error: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | FoodieExpress</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f4f7f6; min-height: 100vh; display: flex; align-items: center; }
        .register-card { width: 100%; max-width: 550px; margin: 30px auto; padding: 40px; background: #fff; border-radius: 20px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); border-top: 5px solid #ff4757; }
        .form-control:focus { border-color: #ff4757; box-shadow: 0 0 0 0.2rem rgba(255, 71, 87, 0.25); }
        .btn-danger { background-color: #ff4757; border: none; padding: 12px; font-weight: 600; }
    </style>
</head>
<body>

<div class="container">
    <div class="register-card">
        <div class="text-center mb-4">
            <h2 class="fw-bold text-dark">Join <span class="text-danger">FoodieExpress</span></h2>
            <p class="text-muted">Create your account to get started</p>
        </div>

        <?php if($error): ?>
            <div class="alert alert-danger py-2 small text-center"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if($success): ?>
            <div class="alert alert-success py-2 small text-center"><?php echo $success; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
            <div class="row">
                <div class="col-md-12 mb-3">
                    <label class="form-label small fw-bold">Full Name</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter your name" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label small fw-bold">Email ID</label>
                    <input type="email" name="email" class="form-control" placeholder="name@example.com" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label small fw-bold">Phone Number</label>
                    <input type="text" name="phone" class="form-control" placeholder="10-digit mobile" required>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label small fw-bold">Register As (Role)</label>
                <select name="role" class="form-select" required>
                    <option value="user">Customer (User)</option>
                    <option value="delivery">Delivery Partner</option>
                    <option value="admin">System Admin</option>
                </select>
                <div class="form-text text-muted" style="font-size: 0.75rem;">Select 'Admin' if you want to manage the portal.</div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label small fw-bold">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label small fw-bold">Confirm Password</label>
                    <input type="password" name="cpassword" class="form-control" placeholder="••••••••" required>
                </div>
            </div>

            <button type="submit" name="submit" class="btn btn-danger w-100 mt-2 shadow-sm">Create Account</button>
        </form>

        <div class="text-center mt-4">
            <p class="mb-0 small text-muted">Already have an account? <a href="index.php" class="text-danger fw-bold text-decoration-none">Login Here</a></p>
        </div>
    </div>
</div>

</body>
</html>
