<?php 
/**
 * QuickBite Admin Login - Final Fixed Version
 * Path: admin/index.php
 */

// 1. Precise Path to Database Connection
// __DIR__ use karne se ye hamesha sahi folder se db.php uthayega
$db_path = dirname(__DIR__) . '/config/db.php';

if (file_exists($db_path)) {
    include_once($db_path);
} else {
    // Local backup path
    include_once('../config/db.php');
}

// 2. Session Start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    try {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } catch (Throwable $e) {
        $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
    }
}

// 3. Already Logged In Check
// Agar pehle se admin logged in hai toh dashboard bhej do
if(isset($_SESSION['user_id']) && isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    header('location: dashboard.php');
    exit();
}

$error = "";
$logout_notice = "";

if (isset($_GET['msg']) && $_GET['msg'] === 'logged_out') {
    $logout_notice = "You have been logged out successfully.";
} elseif (isset($_GET['msg']) && $_GET['msg'] !== '') {
    $logout_notice = trim((string)$_GET['msg']);
}

// 4. Login Logic
if(isset($_POST['submit'])) {
    $csrf_ok = hash_equals((string)($_SESSION['csrf_token'] ?? ''), (string)($_POST['csrf_token'] ?? ''));
    if (!$csrf_ok) {
        $error = "Security check failed. Please refresh and try again.";
    } else {
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = $_POST['password']; 

        // Admin role aur Active status check
        $sql = "SELECT * FROM users WHERE email='$email' AND role='admin' AND status='Active'";
        $res = mysqli_query($conn, $sql);

        if($res && mysqli_num_rows($res) == 1) {
            $row = mysqli_fetch_assoc($res);
            $db_password = $row['password'];
            
            // Password verification logic
            $is_valid = false;
            if (password_verify($password, $db_password)) {
                $is_valid = true;
            } elseif ($password === $db_password) {
                $is_valid = true;
            }

            if($is_valid) {
                // Prevent session fixation
                session_regenerate_id(true);

                // If a legacy plaintext password exists, upgrade it to a hash
                if ($password === $db_password && !password_verify($password, $db_password)) {
                    $new_hash = password_hash($password, PASSWORD_DEFAULT);
                    $safe_hash = mysqli_real_escape_string($conn, $new_hash);
                    $uid = (int)$row['id'];
                    @mysqli_query($conn, "UPDATE users SET password='{$safe_hash}' WHERE id={$uid} LIMIT 1");
                }

                // Session Variables Set
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_name'] = $row['full_name'] ?? ($row['name'] ?? 'Admin');
                $_SESSION['user_role'] = $row['role'];

                header('location: dashboard.php');
                exit();
            } else {
                $error = "Invalid Password. Please try again.";
            }
        } else {
            $error = "No Admin account found or account is Inactive.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | QuickBite</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            background: #1e272e; 
            height: 100vh; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-family: 'Inter', sans-serif; 
        }
        .login-card { 
            width: 100%; 
            max-width: 400px; 
            background: #fff; 
            padding: 40px; 
            border-radius: 20px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.5); 
            border-top: 5px solid #ff4757; 
        }
        .btn-login { 
            background: #ff4757; 
            color: white; 
            font-weight: 600; 
            border: none; 
            padding: 12px; 
            transition: 0.3s; 
        }
        .btn-login:hover { background: #e84118; transform: translateY(-2px); }
        .form-control { padding: 12px; }
        .form-control:focus { border-color: #ff4757; box-shadow: 0 0 0 0.25rem rgba(255, 71, 87, 0.25); }
    </style>
</head>
<body>

<div class="container">
    <div class="login-card mx-auto">
        <div class="text-center mb-4">
            <h3 class="fw-bold text-dark">QuickBite Admin</h3>
            <p class="text-muted small">Please sign in to access the dashboard</p>
        </div>

        <?php 
        // Display Session message (from check-admin.php)
        if(isset($_SESSION['login_msg'])) {
            echo $_SESSION['login_msg'];
            unset($_SESSION['login_msg']);
        }
        if(isset($_SESSION['login_error'])) {
            echo "<div class=\"alert alert-danger py-2 small text-center border-0\">{$_SESSION['login_error']}</div>";
            unset($_SESSION['login_error']);
        }
        if($logout_notice != "") {
            echo "<div class=\"alert alert-success py-2 small text-center border-0\">{$logout_notice}</div>";
        }
        
        if($error != ""): ?>
            <div class="alert alert-danger py-2 small text-center border-0"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars((string)($_SESSION['csrf_token'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
            <div class="mb-3">
                <label class="form-label small fw-bold text-uppercase text-muted" style="font-size: 11px;">Email Address</label>
                <input type="email" name="email" class="form-control rounded-3" placeholder="admin@example.com" required>
            </div>
            <div class="mb-4">
                <label class="form-label small fw-bold text-uppercase text-muted" style="font-size: 11px;">Password</label>
                <input type="password" name="password" class="form-control rounded-3" placeholder="••••••••" required>
            </div>
            <button type="submit" name="submit" class="btn btn-login w-100 rounded-3">SIGN IN</button>
        </form>
    </div>
</div>

</body>
</html>
