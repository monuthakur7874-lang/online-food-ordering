<?php
/**
 * Admin Logout - Session Termination
 * File: admin/logout.php
 */

// 1. Database connection include karein (Ismein session_start() hota hai)
include_once('../config/db.php');

// 2. Saare session variables ko khali karein
$_SESSION = array();

// 3. Agar session cookie exist karti hai toh use expire karein
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. Server se session ko puri tarah destroy karein
session_destroy();

// 5. User ko Admin Login page par wapas bhej dein
header("Location: index.php?msg=logged_out");
exit();
?>