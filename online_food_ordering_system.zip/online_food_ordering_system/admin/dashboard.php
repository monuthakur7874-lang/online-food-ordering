<?php
/**
 * QuickBite Admin Dashboard (Professional)
 * File: admin/dashboard.php
 */

include_once('includes/header.php');

// KPIs
$revenue_total = (float)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) AS t FROM orders WHERE order_status='Delivered'"))['t'] ?? 0);
$pending = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM orders WHERE order_status='Pending'"))['c'] ?? 0);
$confirmed = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM orders WHERE order_status='Confirmed'"))['c'] ?? 0);
$on_way = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM orders WHERE order_status='On the Way'"))['c'] ?? 0);
$delivered = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM orders WHERE order_status='Delivered'"))['c'] ?? 0);
$cancelled = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM orders WHERE order_status='Cancelled'"))['c'] ?? 0);
$food_count = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM foods"))['c'] ?? 0);
$user_count = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM users WHERE role='user'"))['c'] ?? 0);
$rider_count = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM users WHERE role='delivery'"))['c'] ?? 0);
$riders_online = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM users WHERE role='delivery' AND is_online='Yes'"))['c'] ?? 0);
$orders_today = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM orders WHERE DATE(order_date)=CURDATE()"))['c'] ?? 0);
$avg_order_value = $delivered > 0 ? round($revenue_total / $delivered) : 0;

// Revenue trend (today vs yesterday)
$today_rev = (float)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) AS t FROM orders WHERE order_status='Delivered' AND DATE(order_date)=CURDATE()"))['t'] ?? 0);
$yes_rev = (float)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) AS t FROM orders WHERE order_status='Delivered' AND DATE(order_date)=DATE_SUB(CURDATE(), INTERVAL 1 DAY)"))['t'] ?? 0);
$rev_change = ($yes_rev > 0) ? round((($today_rev - $yes_rev) / $yes_rev) * 100) : 0;

// New customers today
$new_users_today = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM users WHERE role='user' AND DATE(created_at)=CURDATE()"))['c'] ?? 0);

// Order status distribution (for chart)
$status_labels = ['Pending', 'Confirmed', 'On the Way', 'Delivered', 'Cancelled'];
$status_counts = [$pending, $confirmed, $on_way, $delivered, $cancelled];

// Revenue chart - last 7 days (Delivered only)
$chart_labels = [];
$chart_data = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chart_labels[] = date('D', strtotime($date));
    $day_total = (float)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) AS t FROM orders WHERE order_status='Delivered' AND DATE(order_date)='{$date}'"))['t'] ?? 0);
    $chart_data[] = (float)$day_total;
}

// Greeting
$hour = (int)date('H');
$greeting = $hour < 12 ? 'Good Morning' : ($hour < 17 ? 'Good Afternoon' : 'Good Evening');
$admin_name = $_SESSION['user_name'] ?? 'Admin';
$ops_message = $pending > 0
    ? $pending . ' pending order' . ($pending > 1 ? 's need' : ' needs') . ' attention right now.'
    : 'All new orders are under control right now.';
$fleet_message = $riders_online > 0
    ? $riders_online . ' rider' . ($riders_online > 1 ? 's are' : ' is') . ' currently online and available for dispatch.'
    : 'No rider is currently online. Dispatch activity may slow down.';

// Recent orders
$recent_orders = mysqli_query(
    $conn,
    "SELECT o.id, o.total_amount, o.order_status, o.order_date, u.name
     FROM orders o
     JOIN users u ON o.user_id = u.id
     ORDER BY o.id DESC
     LIMIT 8"
);

// Activity feed
$activity = mysqli_query(
    $conn,
    "SELECT o.id, o.order_status, o.total_amount, o.order_date, u.name
     FROM orders o
     JOIN users u ON o.user_id = u.id
     ORDER BY o.id DESC
     LIMIT 12"
);
?>

<style>
  .qb-db {
    padding: 22px;
    min-height: 100vh;
    background:
      radial-gradient(circle at top left, rgba(99,102,241,0.08), transparent 28%),
      radial-gradient(circle at top right, rgba(14,165,233,0.08), transparent 30%),
      #f6f7fb;
  }
  .qb-hero {
    position: relative;
    overflow: hidden;
    margin-bottom: 18px;
    padding: 24px;
    border-radius: 24px;
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 42%, #0f766e 100%);
    color: #fff;
    box-shadow: 0 26px 60px rgba(15, 23, 42, 0.18);
  }
  .qb-hero::after {
    content: '';
    position: absolute;
    right: -90px;
    bottom: -120px;
    width: 280px;
    height: 280px;
    border-radius: 50%;
    background: rgba(255,255,255,0.08);
  }
  .qb-hero-grid {
    position: relative;
    z-index: 1;
    display: grid;
    grid-template-columns: minmax(0, 1.45fr) minmax(280px, 0.95fr);
    gap: 16px;
    align-items: center;
  }
  .qb-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 7px 12px;
    border-radius: 999px;
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.16);
    font-size: 11px;
    font-weight: 700;
    letter-spacing: .08em;
    text-transform: uppercase;
  }
  .qb-hero h2 {
    margin: 14px 0 8px;
    font-size: clamp(24px, 3vw, 34px);
    font-weight: 800;
    color: #fff;
    line-height: 1.08;
  }
  .qb-hero p {
    margin: 0;
    color: rgba(255,255,255,0.78);
    font-size: 14px;
    max-width: 680px;
  }
  .qb-hero-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: 18px;
  }
  .qb-hero-actions .qb-btn {
    padding: 8px 14px;
    border-radius: 12px;
    border-color: rgba(255,255,255,0.18);
    background: rgba(255,255,255,0.12);
    color: #fff;
    font-weight: 700;
  }
  .qb-hero-actions .qb-btn:hover {
    background: rgba(255,255,255,0.18);
    color: #fff;
  }
  .qb-hero-side { display:grid; gap:12px; }
  .qb-hero-panel {
    padding: 16px;
    border-radius: 18px;
    background: rgba(255,255,255,0.10);
    border: 1px solid rgba(255,255,255,0.16);
    backdrop-filter: blur(12px);
  }
  .qb-hero-panel .k { font-size: 11px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: rgba(255,255,255,0.68); }
  .qb-hero-panel .v { margin-top: 6px; font-size: 28px; font-weight: 800; line-height: 1; }
  .qb-hero-panel .t { margin-top: 6px; font-size: 12px; color: rgba(255,255,255,0.75); }
  .qb-top { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:18px; }
  .qb-top h2 { margin:0; font-size:20px; font-weight:700; color:#111827; }
  .qb-top p { margin:4px 0 0; font-size:13px; color:#6b7280; }
  .qb-pill { background:#fff; border:1px solid #e5e7eb; border-radius:999px; padding:8px 14px; font-size:12px; color:#374151; display:flex; align-items:center; gap:8px; }
  .qb-strip { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:14px; margin-bottom:14px; }
  .qb-strip-card { background: linear-gradient(180deg, rgba(255,255,255,0.98), rgba(248,250,252,0.95)); border:1px solid #e5e7eb; border-radius:18px; padding:14px 16px; box-shadow:0 16px 34px rgba(15,23,42,.06); }
  .qb-strip-card .k { font-size:10px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; color:#94a3b8; }
  .qb-strip-card .v { margin-top:6px; font-size:24px; font-weight:800; color:#0f172a; line-height:1; }
  .qb-strip-card .t { margin-top:4px; font-size:12px; color:#64748b; }
  .qb-alerts { display:grid; grid-template-columns:minmax(0,1.2fr) minmax(0,.8fr); gap:14px; margin-bottom:14px; }
  .qb-alert { background: linear-gradient(135deg, rgba(99,102,241,.10), rgba(14,165,233,.10)); border:1px solid rgba(99,102,241,.14); border-radius:18px; padding:14px 16px; }
  .qb-alert .h { font-size:13px; font-weight:800; color:#0f172a; }
  .qb-alert .p { margin-top:4px; font-size:12px; color:#475569; }
  .qb-grid { display:grid; grid-template-columns:repeat(12,1fr); gap:14px; }
  .qb-card { background:#fff; border:1px solid #e5e7eb; border-radius:16px; overflow:hidden; }
  .qb-card-h { padding:14px 18px; border-bottom:1px solid #f3f4f6; display:flex; align-items:center; justify-content:space-between; gap:10px; }
  .qb-card-h h5 { margin:0; font-size:13px; font-weight:700; color:#111827; }
  .qb-btn { font-size:11px; padding:5px 12px; border-radius:999px; border:1px solid #d1d5db; background:#fff; color:#374151; text-decoration:none; }
  .qb-btn:hover { background:#f9fafb; }

  .kpi { padding:16px 18px; position:relative; }
  .kpi .ic { width:42px; height:42px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:18px; margin-bottom:12px; }
  .ic-g { background:#dcfce7; color:#15803d; }
  .ic-a { background:#fef9c3; color:#b45309; }
  .ic-b { background:#dbeafe; color:#1d4ed8; }
  .ic-p { background:#ede9fe; color:#6d28d9; }
  .ic-r { background:#fee2e2; color:#b91c1c; }
  .kpi .val { font-size:24px; font-weight:800; color:#111827; line-height:1; }
  .kpi .lbl { margin-top:6px; font-size:11px; letter-spacing:.8px; color:#9ca3af; font-weight:700; }
  .kpi .badge { position:absolute; top:14px; right:14px; font-size:10px; font-weight:800; padding:3px 9px; border-radius:999px; }
  .b-up { background:#dcfce7; color:#15803d; }
  .b-dn { background:#fee2e2; color:#b91c1c; }
  .b-live { background:#fee2e2; color:#b91c1c; animation: qbBlink 1.5s infinite; }
  @keyframes qbBlink { 0%,100%{opacity:1} 50%{opacity:.55} }

  .chart-pad { padding:14px 18px 10px; }
  .chart-box { height: 180px; }
  .right-stack { display:grid; grid-template-rows:auto 1fr; gap:14px; }

  .qb-table { width:100%; border-collapse:collapse; }
  .qb-table th { font-size:10px; text-transform:uppercase; letter-spacing:.8px; color:#9ca3af; padding:8px 18px; background:#f9fafb; border-bottom:1px solid #f3f4f6; }
  .qb-table td { font-size:12px; color:#374151; padding:10px 18px; border-bottom:1px solid #f9fafb; vertical-align:middle; }
  .qb-table tr:hover td { background:#fafafa; }
  .qb-table tr:last-child td { border-bottom:none; }
  .st { font-size:10px; font-weight:800; padding:4px 10px; border-radius:999px; display:inline-block; }
  .st-p { background:#fef9c3; color:#b45309; }
  .st-c { background:#ede9fe; color:#6d28d9; }
  .st-w { background:#dbeafe; color:#1d4ed8; }
  .st-d { background:#dcfce7; color:#15803d; }
  .st-x { background:#fee2e2; color:#b91c1c; }
  .eye { width:30px; height:30px; border-radius:50%; border:1px solid #e5e7eb; background:#fff; display:inline-flex; align-items:center; justify-content:center; text-decoration:none; }
  .eye:hover { background:#f3f4f6; }
  .eye i { font-size:11px; color:#6366f1; }

  .act { max-height: 420px; overflow:auto; }
  .act-i { display:flex; gap:12px; padding:12px 16px; border-bottom:1px solid #f9fafb; }
  .act-i:last-child { border-bottom:none; }
  .dot { width:9px; height:9px; border-radius:50%; margin-top:4px; flex:0 0 auto; }
  .dg { background:#22c55e; } .db { background:#3b82f6; } .da { background:#f59e0b; } .dr { background:#ef4444; }
  .act-m { font-size:12px; color:#374151; line-height:1.4; }
  .act-t { font-size:10px; color:#9ca3af; margin-top:3px; }

  @media (max-width: 1200px) {
    .chart-box { height: 200px; }
    .qb-hero-grid, .qb-strip, .qb-alerts { grid-template-columns:1fr; }
  }
  @media (max-width: 768px) {
    .qb-db { padding: 14px; }
    .qb-hero { padding: 18px; }
  }
</style>

<div class="qb-db">
  <div class="qb-hero">
    <div class="qb-hero-grid">
      <div>
        <span class="qb-eyebrow"><i class="fas fa-chart-line"></i> Admin Control Center</span>
        <h2><?= $greeting; ?>, <?= htmlspecialchars($admin_name); ?>!</h2>
        <p>Monitor revenue, delivery operations, customer growth, and live order flow from one professional dashboard.</p>
        <div class="qb-hero-actions">
          <a class="qb-btn" href="manage-orders.php"><i class="fas fa-shopping-bag me-1"></i> Manage Orders</a>
          <a class="qb-btn" href="manage-delivery.php"><i class="fas fa-truck-fast me-1"></i> Dispatch Riders</a>
          <a class="qb-btn" href="manage-food.php"><i class="fas fa-utensils me-1"></i> Update Menu</a>
        </div>
      </div>
      <div class="qb-hero-side">
        <div class="qb-hero-panel">
          <div class="k">Today's Orders</div>
          <div class="v"><?= number_format($orders_today); ?></div>
          <div class="t">Live order activity recorded for <?= date('d M Y'); ?></div>
        </div>
        <div class="qb-hero-panel">
          <div class="k">Fleet Availability</div>
          <div class="v"><?= number_format($riders_online); ?>/<?= number_format($rider_count); ?></div>
          <div class="t">Riders online versus total registered delivery staff.</div>
        </div>
      </div>
    </div>
  </div>

  <div class="qb-strip">
    <div class="qb-strip-card">
      <div class="k">Average Order Value</div>
      <div class="v">&#8377;<?= number_format($avg_order_value); ?></div>
      <div class="t">Average revenue per delivered order.</div>
    </div>
    <div class="qb-strip-card">
      <div class="k">Menu Items</div>
      <div class="v"><?= number_format($food_count); ?></div>
      <div class="t">Active food listings currently available.</div>
    </div>
    <div class="qb-strip-card">
      <div class="k">Customer Growth</div>
      <div class="v">+<?= number_format($new_users_today); ?></div>
      <div class="t">New customers registered today.</div>
    </div>
    <div class="qb-strip-card">
      <div class="k">Order Completion</div>
      <div class="v"><?= ($delivered + $cancelled) > 0 ? round(($delivered / max(1, $delivered + $cancelled)) * 100) : 100; ?>%</div>
      <div class="t">Delivered orders as a share of closed orders.</div>
    </div>
  </div>

  <div class="qb-alerts">
    <div class="qb-alert">
      <div class="h">Operations Pulse</div>
      <div class="p"><?= htmlspecialchars($ops_message); ?></div>
    </div>
    <div class="qb-alert">
      <div class="h">Fleet Pulse</div>
      <div class="p"><?= htmlspecialchars($fleet_message); ?></div>
    </div>
  </div>

  <div class="qb-top">
    <div>
      <h2>Business Overview</h2>
      <p>Overview of orders, revenue, fleet, and customer operations.</p>
    </div>
    <div class="d-flex gap-2 flex-wrap align-items-center">
      <a class="qb-btn" href="manage-orders.php"><i class="fas fa-shopping-bag me-1"></i> Orders</a>
      <a class="qb-btn" href="manage-delivery.php"><i class="fas fa-truck-fast me-1"></i> Delivery</a>
      <a class="qb-btn" href="manage-food.php"><i class="fas fa-utensils me-1"></i> Menu</a>
      <div class="qb-pill"><i class="far fa-calendar-alt text-danger"></i> <?= date('d M, Y'); ?> &middot; <?= date('h:i A'); ?></div>
    </div>
  </div>

  <div class="qb-grid">
    <div class="qb-card" style="grid-column: span 3;">
      <div class="kpi">
        <div class="ic ic-g"><i class="fas fa-indian-rupee-sign"></i></div>
        <div class="val" id="js-revenue">&#8377;<?= number_format($revenue_total); ?></div>
        <div class="lbl">TOTAL REVENUE</div>
        <?php if($rev_change !== 0): ?>
          <span class="badge <?= $rev_change >= 0 ? 'b-up' : 'b-dn'; ?>"><?= ($rev_change >= 0 ? '+' : '').$rev_change; ?>% Today</span>
        <?php endif; ?>
      </div>
    </div>

    <div class="qb-card" style="grid-column: span 3;">
      <div class="kpi">
        <div class="ic ic-a"><i class="fas fa-clock"></i></div>
        <div class="val" id="js-pending"><?= $pending; ?></div>
        <div class="lbl">PENDING ORDERS</div>
        <?php if($pending > 0): ?><span class="badge b-live">Needs Action</span><?php endif; ?>
      </div>
    </div>

    <div class="qb-card" style="grid-column: span 3;">
      <div class="kpi">
        <div class="ic ic-r"><i class="fas fa-truck-fast"></i></div>
        <div class="val" id="js-onway"><?= $on_way; ?></div>
        <div class="lbl">ON THE WAY</div>
        <?php if($on_way > 0): ?><span class="badge b-live">Live</span><?php endif; ?>
      </div>
    </div>

    <div class="qb-card" style="grid-column: span 3;">
      <div class="kpi">
        <div class="ic ic-p"><i class="fas fa-users"></i></div>
        <div class="val"><?= number_format($user_count); ?></div>
        <div class="lbl">CUSTOMERS</div>
        <?php if($new_users_today > 0): ?><span class="badge b-up">+<?= $new_users_today; ?> Today</span><?php endif; ?>
      </div>
    </div>

    <div class="qb-card" style="grid-column: span 8;">
      <div class="qb-card-h">
        <h5><i class="fas fa-chart-bar me-2 text-primary"></i> Revenue (Last 7 Days)</h5>
        <span id="last-refreshed" class="text-muted" style="font-size:10px;">Auto-refreshes every 60s</span>
      </div>
      <div class="chart-pad">
        <div class="chart-box"><canvas id="revChart"></canvas></div>
      </div>

      <div class="qb-card-h">
        <h5><i class="fas fa-history me-2 text-danger"></i> Recent Orders</h5>
        <a class="qb-btn" href="manage-orders.php">View All</a>
      </div>
      <div class="table-responsive">
        <table class="qb-table">
          <thead>
            <tr>
              <th>Order</th>
              <th>Customer</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Status</th>
              <th class="text-end pe-4">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if($recent_orders && mysqli_num_rows($recent_orders) > 0): ?>
              <?php while($o = mysqli_fetch_assoc($recent_orders)):
                $s = (string)$o['order_status'];
                $stCls = $s === 'Delivered' ? 'st-d' : ($s === 'Pending' ? 'st-p' : ($s === 'Confirmed' ? 'st-c' : ($s === 'On the Way' ? 'st-w' : 'st-x')));
              ?>
              <tr>
                <td><strong>#<?= qb_order_display_id((int)$o['id']); ?></strong></td>
                <td><?= htmlspecialchars((string)$o['name']); ?></td>
                <td><?= date('d M', strtotime((string)$o['order_date'])); ?></td>
                <td><strong>&#8377;<?= number_format((float)$o['total_amount']); ?></strong></td>
                <td><span class="st <?= $stCls; ?>"><?= htmlspecialchars($s); ?></span></td>
                <td class="text-end pe-4">
                  <a class="eye" href="manage-orders.php?id=<?= (int)$o['id']; ?>"><i class="fas fa-eye"></i></a>
                </td>
              </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="6" class="text-center text-muted p-4">No orders found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div style="grid-column: span 4;">
      <div class="right-stack">
        <div class="qb-card">
          <div class="qb-card-h">
            <h5><i class="fas fa-chart-pie me-2 text-success"></i> Order Status</h5>
            <a class="qb-btn" href="manage-orders.php">Open</a>
          </div>
          <div class="chart-pad">
            <div class="chart-box" style="height: 210px;"><canvas id="statusChart"></canvas></div>
          </div>
          <div class="px-3 pb-3 text-muted" style="font-size:10px;">
            Pending: <?= $pending; ?> &middot; Confirmed: <?= $confirmed; ?> &middot; On the Way: <?= $on_way; ?>
          </div>
        </div>

        <div class="qb-card">
          <div class="qb-card-h">
            <h5><i class="fas fa-bolt me-2 text-warning"></i> Live Activity</h5>
            <span class="badge b-live" style="position:static;">LIVE</span>
          </div>
          <div class="act" id="act-feed">
            <?php if($activity && mysqli_num_rows($activity) > 0): ?>
              <?php while($a = mysqli_fetch_assoc($activity)):
                $s = (string)$a['order_status'];
                $dot = $s === 'Delivered' ? 'dg' : ($s === 'On the Way' ? 'db' : ($s === 'Pending' ? 'da' : 'dr'));
                $name = (string)($a['name'] ?? 'Customer');
                $display_order_id = qb_order_display_id((int)$a['id']);
                $msg = $s === 'Delivered' ? "Order #{$display_order_id} delivered to {$name}" :
                       ($s === 'On the Way' ? "Order #{$display_order_id} is on the way to {$name}" :
                       ($s === 'Pending' ? "New order #{$display_order_id} placed by {$name}" :
                       "Order #{$display_order_id} cancelled by {$name}"));
                $diff = time() - strtotime((string)$a['order_date']);
                $ago = $diff < 60 ? 'Just now' : ($diff < 3600 ? round($diff/60).'m ago' : ($diff < 86400 ? round($diff/3600).'h ago' : date('d M', strtotime((string)$a['order_date']))));
              ?>
              <div class="act-i">
                <div class="dot <?= $dot; ?>"></div>
                <div>
                  <div class="act-m"><?= htmlspecialchars($msg); ?></div>
                  <div class="act-t"><?= $ago; ?> &nbsp;&middot;&nbsp; &#8377;<?= number_format((float)$a['total_amount']); ?></div>
                </div>
              </div>
              <?php endwhile; ?>
            <?php else: ?>
              <div class="p-4 text-center text-muted small">No activity yet.</div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
  // Revenue chart
  const revCtx = document.getElementById('revChart').getContext('2d');
  new Chart(revCtx, {
    type: 'bar',
    data: {
      labels: <?= json_encode($chart_labels); ?>,
      datasets: [{
        label: 'Revenue (₹)',
        data: <?= json_encode($chart_data); ?>,
        backgroundColor: 'rgba(99,102,241,0.15)',
        borderColor: '#6366f1',
        borderWidth: 2,
        borderRadius: 6,
        hoverBackgroundColor: 'rgba(99,102,241,0.30)',
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: ctx => ' \u20B9' + Number(ctx.raw).toLocaleString('en-IN') } }
      },
      scales: {
        x: { grid: { display: false }, ticks: { font: { size: 11 } } },
        y: { grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { font: { size: 11 }, callback: v => '\u20B9' + v } }
      }
    }
  });

  // Status chart
  const stCtx = document.getElementById('statusChart').getContext('2d');
  new Chart(stCtx, {
    type: 'doughnut',
    data: {
      labels: <?= json_encode($status_labels); ?>,
      datasets: [{
        data: <?= json_encode($status_counts); ?>,
        backgroundColor: [
          'rgba(245,158,11,0.22)',
          'rgba(99,102,241,0.22)',
          'rgba(59,130,246,0.22)',
          'rgba(34,197,94,0.22)',
          'rgba(239,68,68,0.22)'
        ],
        borderColor: ['#f59e0b','#6366f1','#3b82f6','#22c55e','#ef4444'],
        borderWidth: 2,
        hoverOffset: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '68%',
      plugins: {
        legend: { position: 'bottom', labels: { boxWidth: 10, boxHeight: 10, padding: 10, font: { size: 11 } } }
      }
    }
  });

  // Live refresh (read-only)
  function liveRefresh() {
    fetch('ajax/dashboard_stats.php', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!data) return;
        if (data.on_way !== undefined) document.getElementById('js-onway').textContent = data.on_way;
        if (data.pending !== undefined) document.getElementById('js-pending').textContent = data.pending;
        if (data.revenue_total !== undefined) {
          document.getElementById('js-revenue').innerHTML = '&#8377;' + Number(data.revenue_total).toLocaleString('en-IN');
        }
        document.getElementById('last-refreshed').textContent = 'Last updated: ' + new Date().toLocaleTimeString();
      })
      .catch(() => {});
  }
  setInterval(liveRefresh, 60000);
</script>

<?php include_once('includes/footer.php'); ?>
