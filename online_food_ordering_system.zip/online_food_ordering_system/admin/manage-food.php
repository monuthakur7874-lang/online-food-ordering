<?php 
/**
 * Manage Food Items - Professional CRUD
 * File: admin/manage-food.php
 */

include_once('includes/header.php'); 

// --- CONFIG: Folder Path ---
// Ensure this folder exists: htdocs/online_food_ordering_system/assets/img/food/
$upload_path = "../assets/img/food/";
$csrf_token = function_exists('qb_csrf_token') ? qb_csrf_token() : ($_SESSION['csrf_token'] ?? '');

// --- 1. DELETE LOGIC ---
if(isset($_GET['delete_id'])) {
    qb_require_csrf($_GET['csrf_token'] ?? '');
    $id = intval($_GET['delete_id']);
    if ($id <= 0) {
        echo "<script>alert('Invalid food id.'); window.location='manage-food.php';</script>";
        exit();
    }
    
    $sql_img = "SELECT image FROM foods WHERE id=$id";
    $res_img = mysqli_query($conn, $sql_img);
    $row_img = mysqli_fetch_assoc($res_img);
    
    if($row_img['image'] != "" && file_exists($upload_path.$row_img['image'])) {
        unlink($upload_path.$row_img['image']);
    }

    $sql_del = "DELETE FROM foods WHERE id=$id";
    if(mysqli_query($conn, $sql_del)) {
        echo "<script>alert('Food Item Deleted!'); window.location='manage-food.php';</script>";
    }
}

// --- 2. ADD / UPDATE LOGIC ---
if(isset($_POST['save_food'])) {
    qb_require_csrf();
    $cat_id = (int)($_POST['cat_id'] ?? 0);
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $price = (float)($_POST['price'] ?? 0);
    $desc = mysqli_real_escape_string($conn, $_POST['description']);
    $available = ($_POST['is_available'] ?? 'Yes');
    if (!in_array($available, ['Yes', 'No'], true)) $available = 'Yes';
    $food_id = (int)($_POST['food_id'] ?? 0); 

    $image_name = basename((string)($_POST['current_image'] ?? '')); 
    $upload_error = "";

    if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != "") {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $tmp = $_FILES['image']['tmp_name'] ?? '';
        $allowed_ext = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

        if (!in_array($ext, $allowed_ext, true) || empty($tmp) || !@getimagesize($tmp)) {
            $upload_error = "Please upload a valid image (jpg, jpeg, png, webp, gif).";
        } else {
            $image_name = "FOOD_" . bin2hex(random_bytes(8)) . "." . $ext;
            $dest = $upload_path.$image_name;
        
            // Folder create karein agar nahi hai toh
            if(!is_dir($upload_path)) mkdir($upload_path, 0777, true);
        
            if(move_uploaded_file($tmp, $dest)) {
                $old = basename((string)($_POST['current_image'] ?? ''));
                if($old != "" && $old !== $image_name && file_exists($upload_path.$old)) unlink($upload_path.$old);
            } else {
                $upload_error = "Image upload failed. Please try again.";
            }
        }
    }

    if ($upload_error !== "") {
        echo "<script>alert('".$upload_error."');</script>";
    } else {
        if($food_id <= 0) {
            $sql = "INSERT INTO foods (cat_id, title, price, image, description, is_available) 
                    VALUES ({$cat_id}, '$title', '{$price}', '$image_name', '$desc', '$available')";
        } else {
            $sql = "UPDATE foods SET 
                    cat_id={$cat_id}, title='$title', price='{$price}', 
                    image='$image_name', description='$desc', is_available='$available' 
                    WHERE id={$food_id}";
        }
        
        if(mysqli_query($conn, $sql)) {
            echo "<script>alert('Menu Updated Successfully!'); window.location='manage-food.php';</script>";
        }
    }
}
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0">Menu Management</h3>
            <p class="text-muted small">Manage your restaurant dishes and pricing</p>
        </div>
        <button type="button" class="btn btn-danger rounded-3 px-4 shadow-sm" onclick="openFoodModal()">
            <i class="fas fa-plus me-2"></i> Add New Dish
        </button>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="ps-4 py-3">Dish Details</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sql = "SELECT f.*, c.name as cat_name FROM foods f 
                                LEFT JOIN categories c ON f.cat_id = c.id 
                                ORDER BY f.id DESC";
                        $res = mysqli_query($conn, $sql);
                        
                        if(mysqli_num_rows($res) > 0) {
                            while($row = mysqli_fetch_assoc($res)) {
                                // FIXED: Correct Display Path
                                $img_src = ($row['image'] != "" && file_exists($upload_path.$row['image'])) 
                                           ? $upload_path.$row['image'] 
                                           : "https://via.placeholder.com/100?text=No+Image";
                                ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo $img_src; ?>" class="rounded-3 me-3" width="60" height="60" style="object-fit:cover; border: 1px solid #eee;">
                                            <div>
                                                <div class="fw-bold text-dark"><?php echo $row['title']; ?></div>
                                                <small class="text-muted d-block" style="max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                                    <?php echo $row['description']; ?>
                                                </small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><span class="badge rounded-pill bg-light text-dark border px-3"><?php echo $row['cat_name']; ?></span></td>
                                    <td><span class="fw-bold text-success">₹<?php echo $row['price']; ?></span></td>
                                    <td>
                                        <?php if($row['is_available'] == 'Yes'): ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle px-3">Available</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-3">Sold Out</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-sm btn-light border edit-btn" 
                                            data-id="<?php echo $row['id']; ?>"
                                            data-title="<?php echo $row['title']; ?>"
                                            data-cat="<?php echo $row['cat_id']; ?>"
                                            data-price="<?php echo $row['price']; ?>"
                                            data-desc="<?php echo $row['description']; ?>"
                                            data-avail="<?php echo $row['is_available']; ?>"
                                            data-img="<?php echo $row['image']; ?>">
                                            <i class="fas fa-edit text-primary"></i>
                                        </button>
                                        <a href="?delete_id=<?php echo $row['id']; ?>&csrf_token=<?php echo urlencode($csrf_token); ?>" class="btn btn-sm btn-light border ms-1" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash text-danger"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-center p-5 text-muted'>No food items found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="foodModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h5 class="fw-bold" id="modalTitle">Add New Dish</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="food_id" id="food_id">
                <input type="hidden" name="current_image" id="current_image">
                
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-7">
                            <label class="form-label small fw-bold">Dish Title</label>
                            <input type="text" name="title" id="food_title" class="form-control rounded-3" required>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label small fw-bold">Category</label>
                            <select name="cat_id" id="food_cat" class="form-select rounded-3" required>
                                <option value="">Select Category</option>
                                <?php 
                                $cat_res = mysqli_query($conn, "SELECT id, name FROM categories WHERE is_active='Yes'");
                                while($cat = mysqli_fetch_assoc($cat_res)) {
                                    echo "<option value='{$cat['id']}'>{$cat['name']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Price (₹)</label>
                            <input type="number" name="price" id="food_price" class="form-control rounded-3" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Availability</label>
                            <select name="is_available" id="food_avail" class="form-select rounded-3">
                                <option value="Yes">Available</option>
                                <option value="No">Sold Out</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-bold">Image</label>
                            <input type="file" name="image" class="form-control rounded-3" accept="image/*">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label small fw-bold">Short Description</label>
                            <textarea name="description" id="food_desc" class="form-control rounded-3" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-light rounded-3 px-4" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="save_food" class="btn btn-danger rounded-3 px-4">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function openFoodModal() {
        $('#modalTitle').text('Add New Dish');
        $('#food_id').val('');
        $('#current_image').val('');
        $('#food_title').val('');
        $('#food_cat').val('');
        $('#food_price').val('');
        $('#food_desc').val('');
        $('#food_avail').val('Yes');
        $('#foodModal').modal('show');
    }

    $(document).ready(function(){
        $('.edit-btn').on('click', function(){
            $('#modalTitle').text('Edit Dish Details');
            $('#food_id').val($(this).data('id'));
            $('#food_title').val($(this).data('title'));
            $('#food_cat').val($(this).data('cat'));
            $('#food_price').val($(this).data('price'));
            $('#food_desc').val($(this).data('desc'));
            $('#food_avail').val($(this).data('avail'));
            $('#current_image').val($(this).data('img'));
            $('#foodModal').modal('show');
        });
    });
</script>

<?php include_once('includes/footer.php'); ?>
