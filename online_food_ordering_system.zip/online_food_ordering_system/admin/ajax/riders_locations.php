<?php
/**
 * Admin - Live rider locations (read-only JSON)
 * File: admin/ajax/riders_locations.php
 */

require_once(__DIR__ . '/../../config/db.php');
require_once(__DIR__ . '/../includes/check-admin.php');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$rows = [];
$res = mysqli_query(
    $conn,
    "SELECT id, name, phone, lat, lng, is_online, last_seen
     FROM users
     WHERE role='delivery' AND status='Active'
     ORDER BY is_online DESC, id DESC
     LIMIT 200"
);

if ($res) {
    while ($r = mysqli_fetch_assoc($res)) {
        $rows[] = $r;
    }
}

echo json_encode($rows);
