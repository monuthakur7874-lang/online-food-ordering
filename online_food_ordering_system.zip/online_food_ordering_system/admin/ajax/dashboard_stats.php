<?php
/**
 * Admin dashboard live stats (read-only)
 * File: admin/ajax/dashboard_stats.php
 */

require_once(__DIR__ . '/../../config/db.php');
require_once(__DIR__ . '/../includes/check-admin.php');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$revenue_total = (float)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) AS t FROM orders WHERE order_status='Delivered'"))['t'] ?? 0);
$pending = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM orders WHERE order_status='Pending'"))['c'] ?? 0);
$on_way = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(id) AS c FROM orders WHERE order_status='On the Way'"))['c'] ?? 0);

echo json_encode([
    'ok' => true,
    'pending' => $pending,
    'on_way' => $on_way,
    'revenue_total' => $revenue_total,
    'ts' => time(),
]);
