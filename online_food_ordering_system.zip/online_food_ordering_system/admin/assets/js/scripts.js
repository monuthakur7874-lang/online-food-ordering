/**
 * QuickBite Admin Scripts
 * File: admin/assets/js/scripts.js
 */

document.addEventListener("DOMContentLoaded", function () {
    
    // 1. Sidebar Active Link Auto-Highlighter
    const currentPath = window.location.pathname.split("/").pop();
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });

    // 2. Delete Confirmation (Security for CRUD)
    // Use: <a href="delete.php?id=1" onclick="return confirmDelete(event)">Delete</a>
    window.confirmDelete = function(e) {
        if (!confirm("Are you sure you want to delete this record? This action cannot be undone!")) {
            e.preventDefault();
            return false;
        }
    };

    // 3. Image Preview Before Upload
    // Use: <input type="file" onchange="previewImage(this, 'previewID')">
    window.previewImage = function(input, previewID) {
        const preview = document.getElementById(previewID);
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    // 4. Auto-hide Alerts after 3 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 3000);
    });

});

// 5. Dashboard Charts Logic (Optional: Requires Chart.js in footer)
// Agar aap dashboard.php par <canvas id="salesChart"></canvas> banate hain
function renderSalesChart(labels, data) {
    const ctx = document.getElementById('salesChart');
    if (ctx) {
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Monthly Revenue (₹)',
                    data: data,
                    borderColor: '#ff4757',
                    backgroundColor: 'rgba(255, 71, 87, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });
    }
}