<?php 
/**
 * QuickBite Admin Header - Premium Version
 * File: admin/includes/header.php
 */

// 1. Precise Path Detection
$db_file = dirname(__DIR__, 2) . '/config/db.php'; 
$check_admin = __DIR__ . '/check-admin.php';

if (file_exists($db_file)) {
    include_once($db_file);
} else {
    $fallback = $_SERVER['DOCUMENT_ROOT'] . '/online_food_ordering_system/config/db.php';
    if(file_exists($fallback)) include_once($fallback);
}

if (file_exists($check_admin)) {
    include_once($check_admin);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Monu | Admin Control</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --sidebar-bg: #1e272e;
            --sidebar-hover: #2f3542;
            --primary-red: #ff4757;
            --primary-green: #2ed573;
            --text-muted: #a4b0be;
            --transition: all 0.3s cubic-bezier(.25,.8,.25,1);
        }
        body { font-family: 'Inter', sans-serif; background: #f4f7f6; overflow-x: hidden; }
        
        .sidebar {
            width: 260px; height: 100vh; position: fixed;
            background: var(--sidebar-bg); color: white;
            z-index: 1000; transition: var(--transition);
            box-shadow: 5px 0 15px rgba(0,0,0,0.1);
        }
        .sidebar-header {
            padding: 25px 20px; text-align: center;
            background: rgba(0,0,0,0.25); border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .nav-link {
            color: var(--text-muted); padding: 15px 25px;
            display: flex; align-items: center; text-decoration: none;
            transition: var(--transition); border-left: 4px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            color: #fff; background: var(--sidebar-hover);
            border-left-color: var(--primary-red);
        }
        .nav-link i { margin-right: 15px; width: 20px; text-align: center; font-size: 1.1rem; }
        
        .badge-pulse {
            height: 8px; width: 8px; background: var(--primary-red);
            border-radius: 50%; display: inline-block; margin-left: auto;
            box-shadow: 0 0 0 rgba(255, 71, 87, 0.4);
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(255, 71, 87, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(255, 71, 87, 0); }
            100% { box-shadow: 0 0 0 0 rgba(255, 71, 87, 0); }
        }

        .main-content { margin-left: 260px; padding: 25px; min-height: 100vh; }
        
        .top-navbar {
            background: #fff; padding: 12px 25px; border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.03); margin-bottom: 25px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .status-pill {
            background: rgba(46, 213, 115, 0.1); color: var(--primary-green);
            padding: 4px 12px; border-radius: 20px; font-size: 11px;
            font-weight: 700; text-transform: uppercase;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="fw-bold mb-0 text-white"><i class="fas fa-utensils text-danger me-2"></i>Food Monu</h4>
            <div class="status-pill mt-2 d-inline-block">System Online</div>
        </div>
        
        <div class="mt-4">
            <?php $current_page = basename($_SERVER['PHP_SELF']); ?>
            
            <a href="dashboard.php" class="nav-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="fas fa-th-large"></i> Overview
            </a>
            <a href="manage-categories.php" class="nav-link <?php echo ($current_page == 'manage-categories.php') ? 'active' : ''; ?>">
                <i class="fas fa-layer-group"></i> Categories
            </a>
            <a href="manage-food.php" class="nav-link <?php echo ($current_page == 'manage-food.php') ? 'active' : ''; ?>">
                <i class="fas fa-hamburger"></i> Food Menu
            </a>
            <a href="manage-orders.php" class="nav-link <?php echo ($current_page == 'manage-orders.php') ? 'active' : ''; ?>">
                <i class="fas fa-shopping-bag"></i> Active Orders 
                <span class="badge-pulse"></span>
            </a>
            
            <a href="manage-delivery.php" class="nav-link <?php echo ($current_page == 'manage-delivery.php') ? 'active' : ''; ?>">
                <i class="fas fa-truck-fast"></i> Delivery Status
            </a>

            <a href="manage-users.php" class="nav-link <?php echo ($current_page == 'manage-users.php') ? 'active' : ''; ?>">
                <i class="fas fa-users-cog"></i> Users & Riders
            </a>
            
            <div style="margin-top: 50px;" class="border-top border-secondary pt-3 mx-3">
                <p class="small text-muted mb-2 px-2">Account</p>
                <a href="logout.php" class="nav-link text-danger rounded">
                    <i class="fas fa-power-off"></i> Sign Out
                </a>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div class="top-navbar">
            <div class="d-flex align-items-center">
                <button class="btn btn-light d-lg-none me-3"><i class="fas fa-bars"></i></button>
                <h5 class="fw-bold text-dark mb-0">
                    <?php 
                        switch($current_page) {
                            case 'dashboard.php': echo "Dashboard Analytics"; break;
                            case 'manage-delivery.php': echo "Delivery Operations"; break;
                            case 'manage-orders.php': echo "Order Processing"; break;
                            case 'manage-food.php': echo "Menu Management"; break;
                            default: echo "Admin Control Panel";
                        }
                    ?>
                </h5>
            </div>

            <div class="d-flex align-items-center gap-4">
                <div class="d-none d-md-block text-end">
                    <p class="mb-0 small fw-bold text-dark"><?php echo $_SESSION['user_name'] ?? 'Super Admin'; ?></p>
                    <span class="text-muted" style="font-size: 10px;">Access: Full Permissions</span>
                </div>
                <div class="position-relative">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=ff4757&color=fff&bold=true&rounded=true" 
                         alt="Profile" style="width: 42px; height: 42px; border: 2px solid #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                </div>
            </div>
        </div>
