<?php
/**
 * QuickBite Admin Footer
 * File: admin/includes/footer.php
 */
?>
        </div>

    <footer class="text-center py-4 text-muted border-top bg-white mt-auto">
        <div class="container-fluid">
            <small>&copy; <?php echo date('Y'); ?> <b>Food Monu</b> | Admin Management System</small>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // URL se current file name nikaalna
            const currentPath = window.location.pathname.split("/").pop();
            
            // Saare nav-links ko select karna
            const navLinks = document.querySelectorAll('.nav-link');

            navLinks.forEach(link => {
                // Agar link ka href current path se match kare
                if (link.getAttribute('href') === currentPath) {
                    // Purane active class hatao
                    navLinks.forEach(l => l.classList.remove('active'));
                    // Is link ko active banao
                    link.classList.add('active');
                }
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>
</html>
