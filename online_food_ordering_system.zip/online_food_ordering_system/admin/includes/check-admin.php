<?php
/**
 * QuickBite Admin Security Guard - Redirection Fix
 * File: admin/includes/check-admin.php
 */

// 1. Session Start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 1B. CSRF token bootstrap (shared by all admin pages)
if (empty($_SESSION['csrf_token'])) {
    try {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } catch (Throwable $e) {
        // Fallback (still better than no token)
        $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
    }
}

if (!function_exists('qb_csrf_token')) {
    function qb_csrf_token(): string {
        return (string)($_SESSION['csrf_token'] ?? '');
    }
}

if (!function_exists('qb_verify_csrf_token')) {
    function qb_verify_csrf_token($token): bool {
        $sessionToken = (string)($_SESSION['csrf_token'] ?? '');
        if (!is_string($token) || $token === '' || $sessionToken === '') return false;
        return hash_equals($sessionToken, $token);
    }
}

if (!function_exists('qb_require_csrf')) {
    function qb_require_csrf(?string $token = null): void {
        $t = $token ?? ($_POST['csrf_token'] ?? ($_GET['csrf_token'] ?? ''));
        if (!qb_verify_csrf_token($t)) {
            http_response_code(403);
            die('Invalid CSRF token.');
        }
    }
}

// 2. Page Detection
$current_page = basename($_SERVER['PHP_SELF']);

/**
 * 3. LOGOUT LOGIC
 */
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}

/**
 * 4. DEBUGGING (Optional)
 * Agar aapka page baar-baar redirect ho raha hai, toh niche wali line ko uncomment karein
 * check karne ke liye ki session mein kya aa raha hai.
 */
// die(print_r($_SESSION, true)); 

/**
 * 5. STRICT SECURITY CHECK
 */
// Check karein ki user logged in hai aur uska role hamesha 'admin' ho
$is_admin = (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');

if (!$is_admin) {
    // Agar user admin nahi hai aur login page (index.php) par bhi nahi hai
    if ($current_page !== 'index.php') {
        
        // Error message for the login screen
        $_SESSION['login_error'] = "Admin access required. Please login again.";
        // Backward-compatible key used by the login page UI
        $_SESSION['login_msg'] = "<div class='alert alert-danger py-2 small text-center border-0'>Admin access required. Please login again.</div>";
        
        /**
         * REDIRECTION FIX:
         * Agar aapka admin panel hamesha admin folder ke andar hai, 
         * toh 'index.php' hi sahi path hai.
         */
        header("Location: index.php");
        exit();
    }
}

/**
 * 6. SMART REDIRECT
 * Agar admin pehle se logged in hai, toh login page skip karke dashboard pe bhej do
 */
if ($is_admin && $current_page === 'index.php') {
    header("Location: dashboard.php");
    exit();
}
?>
