<?php 
/**
 * Manage Categories - Professional CRUD (With Image)
 * File: admin/manage-categories.php
 */

include_once('includes/header.php'); 

// --- CONFIG: Folder Path ---
$upload_path = "../assets/img/food/";

// --- 1. DELETE LOGIC ---
if(isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    
    // Pehle image fetch karein delete karne ke liye
    $sql_img = "SELECT image FROM categories WHERE id=$id";
    $res_img = mysqli_query($conn, $sql_img);
    $row_img = mysqli_fetch_assoc($res_img);
    
    if($row_img['image'] != "" && file_exists($upload_path.$row_img['image'])) {
        unlink($upload_path.$row_img['image']);
    }

    $sql_del = "DELETE FROM categories WHERE id=$id";
    if(mysqli_query($conn, $sql_del)) {
        echo "<script>alert('Category Deleted Successfully!'); window.location='manage-categories.php';</script>";
    }
}

// --- 2. ADD & UPDATE LOGIC ---
if(isset($_POST['save_category'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $is_active = $_POST['is_active'];
    $cat_id = $_POST['cat_id'];
    $image_name = $_POST['current_image']; // Purani image default rakhein

    // Image Upload Handling
    if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != "") {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $image_name = "CAT_".time().".". $ext; // Unique Name
        $dest = $upload_path.$image_name;
        
        if(!is_dir($upload_path)) mkdir($upload_path, 0777, true);
        
        if(move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
            // Agar purani image hai toh delete karein
            if($_POST['current_image'] != "" && file_exists($upload_path.$_POST['current_image'])) {
                unlink($upload_path.$_POST['current_image']);
            }
        }
    }

    if($cat_id == "") {
        // Add New
        $sql = "INSERT INTO categories (name, image, is_active) VALUES ('$name', '$image_name', '$is_active')";
    } else {
        // Update Existing
        $sql = "UPDATE categories SET name='$name', image='$image_name', is_active='$is_active' WHERE id=$cat_id";
    }

    if(mysqli_query($conn, $sql)) {
        echo "<script>alert('Category Updated!'); window.location='manage-categories.php';</script>";
    }
}
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-0">Menu Categories</h3>
            <p class="text-muted small">Organize your food items by categories</p>
        </div>
        <button type="button" class="btn btn-danger rounded-3 px-4 shadow-sm" onclick="openCatModal()">
            <i class="fas fa-plus me-2"></i> Create New
        </button>
    </div>

    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-secondary">
                        <tr>
                            <th class="ps-4 py-3 border-0">Icon</th>
                            <th class="border-0">Category Name</th>
                            <th class="border-0">Visibility</th>
                            <th class="text-end pe-4 border-0">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sql = "SELECT * FROM categories ORDER BY id DESC";
                        $res = mysqli_query($conn, $sql);
                        if(mysqli_num_rows($res) > 0) {
                            while($row = mysqli_fetch_assoc($res)) {
                                $img_src = ($row['image'] != "" && file_exists($upload_path.$row['image'])) 
                                           ? $upload_path.$row['image'] 
                                           : "https://via.placeholder.com/50?text=No+Img";
                                ?>
                                <tr>
                                    <td class="ps-4">
                                        <img src="<?php echo $img_src; ?>" class="rounded-circle" width="45" height="45" style="object-fit: cover; border: 1px solid #eee;">
                                    </td>
                                    <td><span class="fw-bold text-dark"><?php echo $row['name']; ?></span></td>
                                    <td>
                                        <?php if($row['is_active'] == 'Yes'): ?>
                                            <span class="badge bg-success-subtle text-success border border-success-subtle px-3">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-3">Hidden</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <button class="btn btn-sm btn-light border editBtn" 
                                                data-id="<?php echo $row['id']; ?>" 
                                                data-name="<?php echo $row['name']; ?>" 
                                                data-img="<?php echo $row['image']; ?>" 
                                                data-status="<?php echo $row['is_active']; ?>">
                                            <i class="fas fa-edit text-primary"></i>
                                        </button>
                                        <a href="?delete_id=<?php echo $row['id']; ?>" class="btn btn-sm btn-light border ms-1" onclick="return confirm('Delete this category?')">
                                            <i class="fas fa-trash text-danger"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='4' class='text-center p-5 text-muted'>No categories found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="categoryModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-header border-0 pb-0">
                <h5 class="fw-bold m-0" id="modalTitle">Create Category</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="cat_id" id="cat_id">
                <input type="hidden" name="current_image" id="current_image">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Category Name</label>
                        <input type="text" name="name" id="cat_name" class="form-control rounded-3" placeholder="e.g. Chinese" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Category Image</label>
                        <input type="file" name="image" class="form-control rounded-3" accept="image/*">
                    </div>
                    <div class="mb-2">
                        <label class="form-label small fw-bold text-secondary">Display Status</label>
                        <div class="d-flex gap-3">
                            <div class="form-check border rounded-3 p-2 px-4 flex-grow-1">
                                <input class="form-check-input" type="radio" name="is_active" id="statusYes" value="Yes" checked>
                                <label class="form-check-label small fw-bold" for="statusYes">Show</label>
                            </div>
                            <div class="form-check border rounded-3 p-2 px-4 flex-grow-1">
                                <input class="form-check-input" type="radio" name="is_active" id="statusNo" value="No">
                                <label class="form-check-label small fw-bold" for="statusNo">Hide</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="save_category" class="btn btn-danger w-100 py-2 rounded-3 fw-bold">SAVE CATEGORY</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    function openCatModal() {
        $('#modalTitle').text('Create Category');
        $('#cat_id').val('');
        $('#cat_name').val('');
        $('#current_image').val('');
        $('#statusYes').prop('checked', true);
        $('#categoryModal').modal('show');
    }

    $(document).ready(function(){
        $('.editBtn').on('click', function(){
            $('#modalTitle').text('Update Category');
            $('#cat_id').val($(this).data('id'));
            $('#cat_name').val($(this).data('name'));
            $('#current_image').val($(this).data('img'));
            
            if($(this).data('status') == 'Yes') {
                $('#statusYes').prop('checked', true);
            } else {
                $('#statusNo').prop('checked', true);
            }
            $('#categoryModal').modal('show');
        });
    });
</script>

<?php include_once('includes/footer.php'); ?>