<?php 
/**
 * Professional Order Management - Live Tracking UI
 * File: admin/manage-orders.php
 */

include_once('includes/header.php'); 

$csrf_token = function_exists('qb_csrf_token') ? qb_csrf_token() : ($_SESSION['csrf_token'] ?? '');

// --- 1. UPDATE ORDER STATUS LOGIC ---
if(isset($_POST['update_status'])) {
    qb_require_csrf();
    $order_id = intval($_POST['order_id']);
    $new_status = (string)($_POST['status'] ?? '');
    $allowed_status = ['Pending', 'Confirmed', 'On the Way', 'Delivered', 'Cancelled'];
    if (!in_array($new_status, $allowed_status, true)) {
        echo "<script>alert('Invalid status selected.'); window.location='manage-orders.php';</script>";
        exit();
    }
    $new_status_safe = mysqli_real_escape_string($conn, $new_status);
    
    $sql_update = "UPDATE orders SET order_status = '$new_status_safe' WHERE id = $order_id";
    if(mysqli_query($conn, $sql_update)) {
        $display_order_id = qb_order_display_id($order_id);
        echo "<script>alert('Order #$display_order_id updated to $new_status'); window.location='manage-orders.php';</script>";
    }
}
?>

<style>
    .order-card { transition: all 0.3s; border-radius: 15px; }
    .table thead th { background-color: #f8f9fa; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.5px; border: none; }
    .status-select { border-radius: 8px 0 0 8px; border-right: none; }
    .status-btn { border-radius: 0 8px 8px 0; }
    .filter-badge { cursor: pointer; transition: 0.2s; }
    .filter-badge:hover { transform: scale(1.05); }
    .bg-soft-pending { background: #fff4e5; color: #ff9800; }
    .bg-soft-delivered { background: #e8f5e9; color: #2e7d32; }
    .bg-soft-way { background: #e3f2fd; color: #1976d2; }
</style>

<div class="container-fluid px-4 py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark mb-1">Orders Dashboard</h3>
            <p class="text-muted small mb-0">Manage incoming requests and delivery logistics.</p>
        </div>
        <div class="d-flex gap-2">
            <button class="btn btn-outline-secondary btn-sm rounded-pill px-3" onclick="window.location.reload()">
                <i class="fas fa-sync-alt me-1"></i> Refresh
            </button>
        </div>
    </div>

    <div class="row g-3 mb-4 text-center">
        <?php
        $stats = [
            'Pending' => ['icon' => 'clock', 'class' => 'warning'],
            'Confirmed' => ['icon' => 'check-circle', 'class' => 'primary'],
            'On the Way' => ['icon' => 'motorcycle', 'class' => 'info'],
            'Delivered' => ['icon' => 'house-user', 'class' => 'success']
        ];
        foreach($stats as $status => $data):
            $count_res = mysqli_query($conn, "SELECT id FROM orders WHERE order_status='$status'");
            $count = mysqli_num_rows($count_res);
        ?>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm rounded-4 p-2 filter-badge">
                <div class="d-flex align-items-center px-2">
                    <div class="p-3 rounded-3 bg-light-<?php echo $data['class']; ?> text-<?php echo $data['class']; ?> me-3">
                        <i class="fas fa-<?php echo $data['icon']; ?> fa-lg"></i>
                    </div>
                    <div class="text-start">
                        <h5 class="fw-bold mb-0"><?php echo $count; ?></h5>
                        <small class="text-muted"><?php echo $status; ?></small>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="card border-0 shadow-sm order-card">
        <div class="card-header bg-white py-3 border-0">
            <div class="row align-items-center">
                <div class="col">
                    <h6 class="fw-bold mb-0">Recent Transactions</h6>
                </div>
                <div class="col-auto">
                    <input type="text" id="orderSearch" class="form-control form-control-sm rounded-pill px-3" placeholder="Search orders...">
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="ordersTable">
                    <thead>
                        <tr>
                            <th class="ps-4">ID</th>
                            <th>Customer & Payment</th>
                            <th>Amount</th>
                            <th>Order Status</th>
                            <th>Date & Time</th>
                            <th class="text-center pe-4">Quick Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sql = "SELECT o.*, u.name as customer_name, u.phone as customer_phone FROM orders o 
                                JOIN users u ON o.user_id = u.id 
                                ORDER BY o.id DESC";
                        $res = mysqli_query($conn, $sql);
                        
                        if(mysqli_num_rows($res) > 0) {
                            while($row = mysqli_fetch_assoc($res)) {
                                // Status styling logic
                                $status_ui = [
                                    'Pending' => 'bg-soft-pending',
                                    'Confirmed' => 'bg-primary text-white',
                                    'On the Way' => 'bg-soft-way',
                                    'Delivered' => 'bg-soft-delivered',
                                    'Cancelled' => 'bg-danger text-white'
                                ];
                                $current_status = $row['order_status'];
                                $badge_class = $status_ui[$current_status] ?? 'bg-secondary text-white';
                                ?>
                                <tr>
                                    <td class="ps-4">
                                        <span class="text-dark fw-bold">#<?php echo qb_order_display_id((int)$row['id']); ?></span>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><?php echo $row['customer_name']; ?></div>
                                        <div class="d-flex align-items-center gap-2">
                                            <small class="text-muted small"><?php echo $row['payment_mode']; ?></small>
                                            <span class="badge bg-light text-dark border-0 fw-normal" style="font-size: 10px;">
                                                <?php echo strtoupper($row['payment_status']); ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="fw-bold text-dark">₹<?php echo number_format($row['total_amount'], 2); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $badge_class; ?> px-3 py-2 rounded-pill shadow-sm" style="min-width: 100px;">
                                            <?php echo $current_status; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="small fw-semibold text-dark"><?php echo date('d M, Y', strtotime($row['order_date'])); ?></div>
                                        <div class="small text-muted" style="font-size: 11px;"><?php echo date('h:i A', strtotime($row['order_date'])); ?></div>
                                    </td>
                                    <td class="pe-4">
                                        <form action="" method="POST" class="d-flex justify-content-center">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                                            <select name="status" class="form-select form-select-sm status-select" style="width: 120px;">
                                                <?php foreach(['Pending', 'Confirmed', 'On the Way', 'Delivered', 'Cancelled'] as $opt): ?>
                                                    <option value="<?php echo $opt; ?>" <?php echo ($current_status == $opt) ? 'selected' : ''; ?>>
                                                        <?php echo $opt; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" name="update_status" class="btn btn-sm btn-primary status-btn">
                                                <i class="fas fa-save"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='6' class='text-center p-5 text-muted'>
                                    <i class='fas fa-box-open fa-3x mb-3 d-block opacity-25'></i>
                                    No orders found yet.
                                  </td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// Simple Live Search for Orders
document.getElementById('orderSearch').addEventListener('keyup', function() {
    let filter = this.value.toUpperCase();
    let rows = document.querySelector("#ordersTable tbody").rows;
    for (let i = 0; i < rows.length; i++) {
        let firstCol = rows[i].cells[0].textContent.toUpperCase();
        let secondCol = rows[i].cells[1].textContent.toUpperCase();
        if (firstCol.indexOf(filter) > -1 || secondCol.indexOf(filter) > -1) {
            rows[i].style.display = "";
        } else {
            rows[i].style.display = "none";
        }      
    }
});
</script>

<?php include_once('includes/footer.php'); ?>
